# Floor Master Solutions - Replit Setup Guide

## 🚀 Quick Start on Replit

### Step 1: Create a New Repl

1. Go to [Replit.com](https://replit.com)
2. Click "Create Repl"
3. Choose **"React (Vite)"** template
4. Name it: `floor-master-solutions`
5. Click "Create Repl"

### Step 2: Upload Files

You have two options:

#### Option A: Upload via Replit UI (Easiest)
1. Delete the default files in the new Repl
2. Drag and drop all files from this project
3. Make sure the folder structure is maintained

#### Option B: Import from GitHub
1. Push this project to a GitHub repository
2. In Replit, click "Create Repl" → "Import from GitHub"
3. Paste your repository URL
4. Click "Import from GitHub"

### Step 3: Install Dependencies

Replit will automatically detect `package.json` and install dependencies. If it doesn't:

1. Open the Shell tab
2. Run: `npm install`

### Step 4: Configure Replit

Create a `.replit` file in the root (this tells Replit how to run your app):

```toml
run = "npm run dev"
entrypoint = "src/app/App.tsx"
hidden = [".config", "package-lock.json"]

[languages.typescript]
pattern = "**/{*.ts,*.tsx}"
syntax = "typescript"

[languages.typescript.languageServer]
start = "typescript-language-server --stdio"

[packager]
language = "nodejs"

[packager.features]
packageSearch = true
guessImports = true

[env]
PATH = "/home/runner/$REPL_SLUG/.config/npm/node_global/bin:/home/runner/$REPL_SLUG/node_modules/.bin"
npm_config_prefix = "/home/runner/$REPL_SLUG/.config/npm/node_global"

[nix]
channel = "stable-22_11"

[deployment]
build = ["npm", "run", "build"]
run = ["sh", "-c", "npm run dev"]

[languages.javascript]
pattern = "**/{*.js,*.jsx,*.ts,*.tsx}"

[languages.javascript.languageServer]
start = "typescript-language-server --stdio"
```

### Step 5: Update package.json Scripts

Make sure your `package.json` has these scripts:

```json
{
  "scripts": {
    "dev": "vite --host 0.0.0.0 --port 5173",
    "build": "vite build",
    "preview": "vite preview --host 0.0.0.0 --port 5173"
  }
}
```

The `--host 0.0.0.0` is important for Replit to expose the dev server.

### Step 6: Run the Application

1. Click the green "Run" button at the top
2. Wait for dependencies to install
3. The app will open in the Replit webview
4. If it doesn't auto-open, look for the URL in the "Webview" panel (usually something like `https://floor-master-solutions.username.repl.co`)

---

## 📁 Required Files for Replit

Make sure these files are present:

### Root Files
- `.replit` (configuration for Replit)
- `package.json` (dependencies)
- `vite.config.ts` (Vite configuration)
- `tsconfig.json` (TypeScript configuration)
- `postcss.config.mjs` (PostCSS for Tailwind)
- `index.html` (root HTML)

### Source Files
- `src/main.tsx` (entry point)
- `src/app/App.tsx` (main app)
- `src/app/components/...` (all components)
- `src/app/data/...` (mock data)
- `src/styles/...` (CSS files)

---

## 🔧 Troubleshooting

### Issue: "Module not found" errors

**Solution:** Make sure all dependencies are installed
```bash
npm install
```

### Issue: Blank screen or white page

**Solution:** Check the browser console for errors. Common issues:
1. Missing `index.html` file
2. Incorrect import paths
3. TypeScript errors

### Issue: "Port already in use"

**Solution:** Replit sometimes caches the port. Stop and restart the Repl.

### Issue: Tailwind styles not loading

**Solution:** 
1. Check that `@tailwindcss/vite` is in devDependencies
2. Make sure `postcss.config.mjs` exists
3. Verify `vite.config.ts` includes Tailwind plugin

### Issue: Build fails

**Solution:** Check TypeScript errors:
```bash
npm run build
```

---

## 🌐 Deploying from Replit

### Option 1: Use Replit Hosting
1. Click "Deploy" in the top right
2. Choose "Production"
3. Replit will build and deploy your app
4. You'll get a public URL

### Option 2: Export to Other Platforms
1. Download your Repl as a ZIP
2. Upload to Netlify/Vercel/AWS
3. Or push to GitHub and deploy from there

---

## ⚙️ Replit-Specific Configuration

### Environment Variables

If you add environment variables later:
1. Click "Secrets" in Replit sidebar (lock icon)
2. Add your secrets (API keys, etc.)
3. They'll be available as `process.env.VARIABLE_NAME`

### Storage

Replit provides some persistent storage, but for production:
- Use Supabase for database
- Use Supabase Storage or AWS S3 for images
- Don't store critical data in Replit's file system

---

## 📝 Replit Run Command

The `.replit` file tells Replit to run:
```bash
npm run dev
```

This starts Vite dev server on port 5173 with host 0.0.0.0 (so Replit can proxy it).

---

## 🎯 Next Steps After Replit Setup

1. ✅ App running on Replit
2. ✅ Test all features (homeowner & contractor flows)
3. ✅ Set up Supabase for database
4. ✅ Replace mock data with real API calls
5. ✅ Add Stripe for payments
6. ✅ Deploy to production hosting

---

## 💡 Tips for Replit Development

1. **Auto-save is on** - Replit saves automatically
2. **Collaborative** - Share your Repl URL to code together
3. **Shell access** - Use the Shell tab for npm commands
4. **File explorer** - Left sidebar shows all files
5. **Console** - Bottom panel shows logs and errors
6. **Secrets** - Use Replit Secrets for API keys (never commit them)

---

## 🔗 Useful Replit Resources

- [Replit Docs](https://docs.replit.com/)
- [Vite on Replit](https://docs.replit.com/tutorials/vite)
- [React on Replit](https://docs.replit.com/tutorials/react)
- [Deploying from Replit](https://docs.replit.com/hosting/deployments)

---

## 📦 What You Get on Replit

✅ **Instant Dev Environment** - No local setup needed  
✅ **Automatic Package Installation** - Detects package.json  
✅ **Live Reload** - Changes update instantly  
✅ **Shareable URL** - Share with team or clients  
✅ **Version Control** - Built-in Git support  
✅ **Deployment** - One-click deploy to production  

---

**Ready to code!** 🎉

Once you follow these steps, your Floor Master Solutions app will be running on Replit!
