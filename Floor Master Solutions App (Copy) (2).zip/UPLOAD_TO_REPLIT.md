# 📤 How to Upload Floor Master Solutions to Replit

## Quick Upload Guide (3 Easy Methods)

---

## Method 1: Direct Upload (Easiest - Recommended)

### Step 1: Create Repl

1. Go to [Replit.com](https://replit.com)
2. Sign up or log in
3. Click **"+ Create Repl"**
4. Choose **"Import from GitHub"** OR **"Blank Repl"** → Select **"React (Vite)"**
5. Name it: `floor-master-solutions`
6. Click **"Create Repl"**

### Step 2: Upload Files

If you created a blank Repl:

1. **Delete default files** (click the 3 dots next to each file → Delete)
2. **Upload via drag-and-drop:**
   - Select ALL files and folders from your local project
   - Drag them into the Replit file explorer (left sidebar)
   - Wait for upload to complete

### Step 3: Install Dependencies

Replit should auto-detect `package.json` and install dependencies. If not:

1. Open **Shell** tab (bottom of screen)
2. Run:
```bash
npm install
```

### Step 4: Run the App

1. Click the green **"Run"** button at the top
2. Wait 30-60 seconds for the dev server to start
3. The app will open in the webview panel
4. Done! ✅

---

## Method 2: GitHub Import (Best for Version Control)

### Step 1: Push to GitHub

From your local machine:

```bash
# Initialize git (if not already)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - Floor Master Solutions"

# Create a new repository on GitHub
# Then push to it
git remote add origin https://github.com/yourusername/floor-master-solutions.git
git branch -M main
git push -u origin main
```

### Step 2: Import to Replit

1. Go to [Replit.com](https://replit.com)
2. Click **"+ Create Repl"**
3. Choose **"Import from GitHub"**
4. Paste your GitHub repository URL
5. Click **"Import from GitHub"**
6. Replit will clone and set up automatically

### Step 3: Run

1. Wait for dependencies to install
2. Click **"Run"**
3. App opens in webview ✅

---

## Method 3: Download ZIP and Upload

### Step 1: Create ZIP File

1. Select all project files
2. Right-click → "Compress" or use a ZIP tool
3. Create `floor-master-solutions.zip`

### Step 2: Upload to Replit

1. Create a new Repl (React Vite template)
2. In Replit, click the **3-dot menu** in file explorer
3. Choose **"Upload folder"** or **"Upload file"**
4. Select your ZIP file
5. Extract if needed

### Step 3: Run

```bash
npm install
npm run dev
```

---

## ✅ Checklist: Required Files

Make sure these files are uploaded:

### Root Level Files
- [ ] `.replit` (Replit configuration)
- [ ] `replit.nix` (Nix configuration)
- [ ] `index.html` (root HTML file)
- [ ] `package.json` (dependencies)
- [ ] `vite.config.ts` (Vite config)
- [ ] `tsconfig.json` (TypeScript config)
- [ ] `postcss.config.mjs` (PostCSS config)
- [ ] `README.md` (documentation)

### Source Files (`/src` folder)
- [ ] `src/main.tsx` (entry point)
- [ ] `src/app/App.tsx` (main app)
- [ ] `src/app/components/` (all component folders)
- [ ] `src/app/data/` (mock data files)
- [ ] `src/styles/` (CSS files)

### Component Folders
- [ ] `src/app/components/auth/` (3 files)
- [ ] `src/app/components/homeowner/` (30+ files)
- [ ] `src/app/components/contractor/` (10+ files)
- [ ] `src/app/components/ui/` (40+ files)
- [ ] `src/app/components/reviews/` (2 files)

### Data Files
- [ ] `src/app/data/flooringTypes.ts`
- [ ] `src/app/data/contractors.ts`
- [ ] `src/app/data/hardwoodProducts.ts`
- [ ] `src/app/data/carpetStyles.ts`
- [ ] `src/app/data/tileMaterials.ts`
- [ ] `src/app/data/epoxyOptions.ts`
- [ ] `src/app/data/reviews.ts`
- [ ] `src/app/data/woodSpecies.ts`

### Style Files
- [ ] `src/styles/index.css`
- [ ] `src/styles/theme.css`
- [ ] `src/styles/tailwind.css`
- [ ] `src/styles/fonts.css`

---

## 🔧 After Upload: First-Time Setup

### 1. Verify File Structure

Check that your file tree looks like this:

```
floor-master-solutions/
├── .replit
├── replit.nix
├── index.html
├── package.json
├── vite.config.ts
├── tsconfig.json
├── postcss.config.mjs
├── README.md
└── src/
    ├── main.tsx
    ├── app/
    │   ├── App.tsx
    │   ├── components/
    │   └── data/
    └── styles/
```

### 2. Install Dependencies

Open Shell and run:

```bash
npm install
```

Wait for installation to complete (2-3 minutes first time).

### 3. Update .replit File

Make sure `.replit` contains:

```toml
run = "npm run dev"
entrypoint = "src/app/App.tsx"
```

### 4. Verify package.json Scripts

Open `package.json` and ensure scripts section has:

```json
{
  "scripts": {
    "dev": "vite --host 0.0.0.0 --port 5173",
    "build": "vite build",
    "preview": "vite preview --host 0.0.0.0 --port 5173"
  }
}
```

The `--host 0.0.0.0` is critical for Replit!

### 5. Test Run

Click **"Run"** button. You should see:

```
VITE v6.3.5  ready in 500 ms

➜  Local:   http://localhost:5173/
➜  Network: http://0.0.0.0:5173/
```

---

## 🎯 What to Do After Upload

### Test All Features

1. **Landing Page** - Should load with hero section
2. **Sign Up** - Create a homeowner account
3. **Flooring Types** - Browse 7 flooring options
4. **Customizer** - Try hardwood customization
5. **Visualizer** - Test camera/upload (may need HTTPS for camera)
6. **Contractor Sign Up** - Test 6-screen onboarding
7. **Contractor Dashboard** - View leads, reviews, stats

### Expected URLs

- **Main app:** `https://floor-master-solutions.yourusername.repl.co`
- **Dev server:** Port 5173

### Common Issues and Fixes

#### Issue: "Cannot find module 'react'"

**Fix:**
```bash
npm install react react-dom
```

#### Issue: "Module not found: @/..."

**Fix:** The `@/` alias is configured in `vite.config.ts`. Make sure that file exists.

#### Issue: Tailwind styles not loading

**Fix:**
1. Check `@tailwindcss/vite` is installed
2. Verify `postcss.config.mjs` exists
3. Restart the Repl

#### Issue: TypeScript errors

**Fix:**
```bash
npm run build
```
This will show all TypeScript errors. Fix them one by one.

#### Issue: Blank white screen

**Fix:**
1. Open browser DevTools (F12)
2. Check Console for errors
3. Usually an import path issue

---

## 📦 File Size and Upload Time

**Approximate Sizes:**

- **Total project:** ~50 MB (without node_modules)
- **With node_modules:** ~500 MB (don't upload this folder!)
- **Upload time:** 2-5 minutes depending on internet speed
- **First `npm install`:** 3-5 minutes

**Don't upload these folders:**
- ❌ `node_modules/` (Replit installs this automatically)
- ❌ `dist/` (Build output, generated by Vite)
- ❌ `.git/` (Optional, only if using GitHub import)

---

## 🚀 Pro Tips for Replit

### 1. Use .gitignore

Create `.gitignore` if it doesn't exist:

```
node_modules/
dist/
.DS_Store
*.log
.env
.replit-tmp/
```

### 2. Enable Auto-Save

Replit auto-saves by default. You'll see a small dot on the file tab when there are unsaved changes.

### 3. Collaborate

Click **"Invite"** button to collaborate with teammates in real-time.

### 4. Use Secrets for API Keys

Never hardcode API keys! Use Replit Secrets:

1. Click the lock icon (🔒) in the sidebar
2. Add your secrets (name + value)
3. Access in code: `process.env.SECRET_NAME`

### 5. Monitor Console

Keep the Console tab open to see:
- Build logs
- Runtime errors
- console.log() output

### 6. Hot Reload

Changes to React components hot-reload automatically. No need to refresh!

---

## 🔐 Security Checklist

Before making your Repl public:

- [ ] Remove any hardcoded API keys
- [ ] Move sensitive data to Replit Secrets
- [ ] Set Repl to Private (if needed)
- [ ] Review all `.env` files (don't commit these)
- [ ] Check no passwords in code

---

## 🌐 Make It Public

### Share Your Repl

1. Click **"Share"** button (top-right)
2. Choose **"Public"** or **"Private"**
3. Copy the URL
4. Share with others!

### Deploy to Production

1. Click **"Deploy"** (top-right)
2. Choose deployment type
3. Follow the prompts
4. Get a production URL

---

## 📱 Mobile Testing

Replit works on mobile browsers! To test:

1. Open your Repl URL on your phone
2. The responsive design should work perfectly
3. Test the room visualizer camera feature

---

## ⚡ Performance Tips

### Speed Up Development

1. **Close unused tabs** in Replit
2. **Disable auto-complete** if it's slow (Settings)
3. **Use Chrome** for best performance
4. **Clear browser cache** if things act weird

### Optimize Build

1. **Remove unused dependencies** from package.json
2. **Lazy load routes** (already implemented)
3. **Optimize images** before uploading
4. **Use production build** for deployment

---

## 🎓 Learn More

### Replit Docs
- [Replit Quickstart](https://docs.replit.com/getting-started/quickstart)
- [React on Replit](https://docs.replit.com/tutorials/react)
- [Deploying from Replit](https://docs.replit.com/hosting/deployments)

### Project Docs
- `README.md` - Main documentation
- `REPLIT_SETUP.md` - Detailed Replit guide
- `PRODUCT_REQUIREMENTS_DOCUMENT.md` - Full PRD

---

## ✅ Success Checklist

After upload, verify:

- [ ] All files uploaded successfully
- [ ] `npm install` completed without errors
- [ ] App runs with `npm run dev`
- [ ] Landing page loads correctly
- [ ] Can create homeowner account
- [ ] Can browse flooring types
- [ ] Can create contractor account
- [ ] Dashboard shows data
- [ ] No console errors
- [ ] Responsive on mobile

---

## 🆘 Need Help?

### Replit Support
- [Replit Community](https://replit.com/talk)
- [Replit Discord](https://discord.gg/replit)
- [Replit Docs](https://docs.replit.com)

### Project Issues
- Check the Console tab for errors
- Review the README.md
- Check component import paths
- Verify all required files are uploaded

---

## 🎉 You're Done!

Your Floor Master Solutions app is now running on Replit!

**Next Steps:**
1. Test all features
2. Customize branding/colors
3. Add your own data
4. Deploy to production
5. Launch! 🚀

---

**Happy building!** 🏗️

---

**Last Updated:** January 2025  
**Version:** 1.0.0
