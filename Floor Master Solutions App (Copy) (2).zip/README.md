# 🏠 Floor Master Solutions

A comprehensive two-sided marketplace platform connecting homeowners with professional flooring contractors.

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![React](https://img.shields.io/badge/react-18.3.1-blue.svg)
![TypeScript](https://img.shields.io/badge/typescript-5.0+-blue.svg)
![Tailwind](https://img.shields.io/badge/tailwind-4.0-blue.svg)

---

## 🚀 Quick Start on Replit

### Running the App

1. **Click the green "Run" button** at the top of Replit
2. Wait for dependencies to install (first time only, takes 2-3 minutes)
3. The app will open in the webview panel
4. Done! The app is now running.

**Replit URL:** Your app will be available at `https://floor-master-solutions.yourusername.repl.co`

### Manual Start (if needed)

Open the Shell and run:
```bash
npm install
npm run dev
```

---

## 📋 What Is This App?

**Floor Master Solutions** is a complete flooring marketplace with:

### For Homeowners:
- 📚 **Education Hub** - Learn about 7 flooring types
- 🎨 **Product Customizer** - Choose species, colors, finishes
- 📸 **Room Visualizer** - Camera/upload + AR floor overlay
- 💬 **AI Chat Assistant** - Ask flooring questions
- 👷 **Contractor Directory** - Find verified contractors
- 📊 **Project Management** - Save and share designs

### For Contractors:
- ✅ **6-Screen Onboarding** - Complete verification flow
- 📊 **Enhanced Dashboard** - Leads, stats, analytics
- 📬 **Lead Inbox** - Search, filter, manage leads
- ⭐ **Reviews Management** - Reply to customer reviews
- 💰 **Pricing Plans** - $0, $25, $49, $99/month options

---

## 🛠️ Tech Stack

- **Frontend:** React 18.3.1 + TypeScript
- **Build Tool:** Vite
- **Styling:** Tailwind CSS v4
- **Icons:** Lucide React
- **Animation:** Motion (Framer Motion)
- **Charts:** Recharts
- **UI Components:** Radix UI (40+ components)
- **Forms:** React Hook Form
- **Images:** Unsplash API

---

## 📁 Project Structure

```
floor-master-solutions/
├── .replit                         # Replit configuration
├── index.html                      # Root HTML
├── package.json                    # Dependencies
├── vite.config.ts                  # Vite config
├── tsconfig.json                   # TypeScript config
├── src/
│   ├── main.tsx                    # Entry point
│   ├── app/
│   │   ├── App.tsx                 # Main app component
│   │   ├── components/
│   │   │   ├── auth/               # Authentication
│   │   │   │   ├── Welcome.tsx
│   │   │   │   ├── LoginSignup.tsx
│   │   │   │   └── UserTypeSelection.tsx
│   │   │   ├── homeowner/          # Homeowner features
│   │   │   │   ├── HomeownerHome.tsx
│   │   │   │   ├── FlooringList.tsx
│   │   │   │   ├── FlooringDetail.tsx
│   │   │   │   ├── FloorVisualizer.tsx
│   │   │   │   ├── ProductCustomizer.tsx
│   │   │   │   ├── ContractorsList.tsx
│   │   │   │   └── ... (20+ components)
│   │   │   ├── contractor/         # Contractor features
│   │   │   │   ├── ContractorMVPOnboarding.tsx
│   │   │   │   ├── ContractorMVPDashboard.tsx
│   │   │   │   ├── ContractorVerificationInfo.tsx
│   │   │   │   └── ... (10+ components)
│   │   │   └── ui/                 # Reusable UI (40+ components)
│   │   └── data/                   # Mock data
│   │       ├── flooringTypes.ts
│   │       ├── contractors.ts
│   │       ├── hardwoodProducts.ts
│   │       └── ... (8 data files)
│   └── styles/                     # CSS
│       ├── index.css
│       ├── theme.css
│       ├── tailwind.css
│       └── fonts.css
├── PRODUCT_REQUIREMENTS_DOCUMENT.md # Complete PRD
├── REPLIT_SETUP.md                 # Replit setup guide
└── README.md                       # This file
```

---

## 🎯 Key Features

### 1. Homeowner Flow

**Landing Page** → **Create Account** → **Explore Flooring** → **Customize Product** → **Visualize in Room** → **Share with Contractors** → **Get Quotes**

**Features:**
- 7 flooring types with complete information
- Hardwood: 10 species, 8 colors, 6 finishes, 5 widths
- Carpet: 8 styles, 50+ colors, 5 fiber types
- Tile: 7 materials, patterns, grout colors
- LVP: 3 core types, 30+ colors, wear layers
- Epoxy: 50+ colors, metallic/flake finishes
- Camera/upload room photos
- Real-time floor overlay visualization
- AI chat assistant for flooring questions

### 2. Contractor Flow

**Sign Up** → **6-Screen Onboarding** → **Verification** → **Dashboard** → **Receive Leads** → **Manage Reviews**

**Features:**
- Company information setup
- License and insurance upload
- Portfolio photo gallery
- Plan selection ($0-$99/month)
- Lead inbox with filters
- One-click call/text/email
- Reviews management with replies
- Performance analytics

---

## 🔧 Development Commands

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Lint code
npm run lint
```

---

## 🌐 Deployment

### From Replit

1. Click **"Deploy"** in the top-right corner
2. Choose **"Production"**
3. Replit builds and deploys
4. Get a public URL

### To Other Platforms

**Netlify:**
```bash
# Build
npm run build

# Deploy dist/ folder
netlify deploy --prod --dir=dist
```

**Vercel:**
```bash
npm i -g vercel
vercel
```

**AWS S3:**
```bash
npm run build
aws s3 sync dist/ s3://your-bucket-name
```

---

## 📊 Mock Data

Currently uses mock data for demonstration:

- **Homeowners:** Sample user accounts
- **Contractors:** 20+ contractor profiles
- **Flooring Types:** Complete data for 7 types
- **Reviews:** Customer reviews and ratings
- **Leads:** Sample lead data

**To make production-ready:** Replace mock data with Supabase database (see PRD).

---

## 🔐 Environment Variables

For production, create a `.env` file:

```env
# Supabase
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_key

# Stripe
VITE_STRIPE_PUBLIC_KEY=your_stripe_key

# Unsplash (optional)
VITE_UNSPLASH_ACCESS_KEY=your_unsplash_key
```

In Replit, use **Secrets** (lock icon) instead of `.env` file.

---

## 🎨 Customization

### Change Colors

Edit `/src/styles/theme.css`:

```css
:root {
  --color-primary: #d97706; /* Amber-600 - Change this! */
  --color-secondary: #78716c; /* Stone-500 */
  --color-accent: #059669; /* Emerald-600 */
}
```

### Change Fonts

Edit `/src/styles/fonts.css`:

```css
@import url('https://fonts.googleapis.com/css2?family=Your+Font&display=swap');

body {
  font-family: 'Your Font', sans-serif;
}
```

### Modify Components

All components are in `/src/app/components/`. They're React + TypeScript with Tailwind CSS styling.

---

## 📚 Documentation

- **[PRODUCT_REQUIREMENTS_DOCUMENT.md](PRODUCT_REQUIREMENTS_DOCUMENT.md)** - Complete PRD (100+ pages)
- **[REPLIT_SETUP.md](REPLIT_SETUP.md)** - Replit-specific setup guide
- **[COMPLETE_SOURCE_CODE.md](COMPLETE_SOURCE_CODE.md)** - Technical documentation
- **[CONTRACTOR_MVP_CHECKLIST.md](CONTRACTOR_MVP_CHECKLIST.md)** - Contractor feature checklist

---

## 🐛 Troubleshooting

### App won't start

1. Check the Console for errors
2. Try: `npm install` then `npm run dev`
3. Restart the Repl

### Blank screen

1. Open browser DevTools (F12)
2. Check Console for errors
3. Verify all imports are correct

### TypeScript errors

1. Run: `npm run build` to see all errors
2. Fix type errors in components
3. Restart dev server

### Tailwind styles not showing

1. Verify `@tailwindcss/vite` is installed
2. Check `vite.config.ts` includes Tailwind plugin
3. Ensure `postcss.config.mjs` exists
4. Restart dev server

---

## 🚀 Next Steps for Production

### Phase 1: Backend (Week 1-2)
- [ ] Set up Supabase project
- [ ] Create database tables
- [ ] Implement authentication
- [ ] Set up file storage
- [ ] Replace mock data with API calls

### Phase 2: Payments (Week 3)
- [ ] Create Stripe account
- [ ] Set up subscription products
- [ ] Implement payment forms
- [ ] Handle webhooks
- [ ] Test payment flows

### Phase 3: Verification (Week 4)
- [ ] Background check integration
- [ ] License verification
- [ ] Insurance validation
- [ ] Email notifications

### Phase 4: Launch (Week 5-6)
- [ ] Deploy to production
- [ ] Set up monitoring (Sentry)
- [ ] Configure analytics (GA4)
- [ ] SEO optimization
- [ ] Marketing launch

---

## 📈 Success Metrics

| Metric | Target |
|--------|--------|
| Homeowner Signup Conversion | >5% |
| Projects Shared | >60% |
| Contractor Hired Rate | >30% |
| Contractor Free→Paid | >40% |
| Lead Response Rate | >90% |
| Average Rating | >4.5/5 |

---

## 🤝 Contributing

This is a proprietary project. For questions or suggestions:
- Open an issue in Replit
- Contact the development team

---

## 📄 License

Proprietary - All rights reserved.

---

## 💡 Tips for Replit

1. **Auto-save is enabled** - Changes save automatically
2. **Share your Repl** - Click "Share" to collaborate
3. **Use Secrets** - For API keys (lock icon in sidebar)
4. **Console logging** - Check Console tab for logs
5. **Shell commands** - Use Shell tab for npm commands
6. **Version history** - Replit tracks all changes

---

## 🎉 You're Ready!

Click the **Run** button and start exploring Floor Master Solutions!

**Happy coding!** 🚀

---

**Questions?** Check the documentation files or the Replit community.
