import { useState } from 'react';

interface OnboardingWizardProps {
  userType: 'homeowner' | 'contractor';
  onComplete: () => void;
}

export function OnboardingWizard({ userType, onComplete }: OnboardingWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const homeownerSteps = [
    {
      title: 'Welcome to Floor Master Solutions! 🏠',
      description: 'Your complete flooring journey starts here',
      content: 'We make finding and installing the perfect floor simple and stress-free. Let us show you how!',
      image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',
      icon: '👋',
      color: 'from-blue-500 to-blue-600'
    },
    {
      title: 'Explore & Compare Flooring 🔍',
      description: 'Browse 7 flooring types with detailed information',
      content: 'Compare hardwood, carpet, tile, LVP, epoxy, and more. Each option includes pros, cons, pricing, durability ratings, and real photos.',
      image: 'https://images.unsplash.com/photo-1631669394390-baf737ef47de?w=800&q=80',
      icon: '🎨',
      color: 'from-purple-500 to-purple-600',
      features: [
        'Detailed specifications',
        'Real pricing ranges',
        'Durability ratings',
        'Best use cases'
      ]
    },
    {
      title: 'Customize Your Perfect Floor 🛠️',
      description: 'Design exactly what you want',
      content: 'Use our step-by-step customization tools to select colors, finishes, materials, and more. See instant price estimates as you design.',
      image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&q=80',
      icon: '⚙️',
      color: 'from-amber-500 to-amber-600',
      features: [
        'Interactive customization',
        'Real-time pricing',
        'Visual previews',
        'Save your designs'
      ]
    },
    {
      title: 'Visualize in Your Space 📸',
      description: 'See before you buy',
      content: 'Upload a photo of your room and visualize different flooring options. Share designs with contractors for accurate quotes.',
      image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=800&q=80',
      icon: '🖼️',
      color: 'from-green-500 to-green-600',
      features: [
        'Room visualizer',
        'Photo upload',
        'Share with pros',
        'Save projects'
      ]
    },
    {
      title: 'Connect with Verified Contractors 👷',
      description: 'Get professional installation',
      content: 'Browse verified contractors, read reviews, compare quotes, and message them directly in the app. All contractors are background-checked.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80',
      icon: '✅',
      color: 'from-teal-500 to-teal-600',
      features: [
        'Verified professionals',
        'Real customer reviews',
        'Direct messaging',
        'Multiple quotes'
      ]
    },
    {
      title: 'Get 24/7 AI Support 💬',
      description: 'Never feel stuck',
      content: 'Our AI assistant is always available to answer questions about flooring types, maintenance, installation, and more.',
      image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=800&q=80',
      icon: '🤖',
      color: 'from-pink-500 to-pink-600',
      features: [
        'Instant answers',
        'Product recommendations',
        'Maintenance tips',
        'Installation guidance'
      ]
    },
    {
      title: 'You\'re All Set! 🎉',
      description: 'Ready to find your perfect floor?',
      content: 'You now know everything you need to get started. Let\'s transform your space!',
      image: 'https://images.unsplash.com/photo-1615876234886-fd9a39fda97f?w=800&q=80',
      icon: '🚀',
      color: 'from-indigo-500 to-indigo-600',
      cta: 'Start Exploring Floors'
    }
  ];

  const contractorSteps = [
    {
      title: 'Welcome to Floor Master Pro! 💼',
      description: 'Grow your flooring business',
      content: 'Connect with qualified homeowners, manage leads, and grow your business with our professional platform.',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=800&q=80',
      icon: '👋',
      color: 'from-blue-500 to-blue-600'
    },
    {
      title: 'Receive Quality Leads 📋',
      description: 'Homeowners come to you',
      content: 'Get notifications when homeowners in your area request quotes. See their designs and specifications before responding.',
      image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=800&q=80',
      icon: '📬',
      color: 'from-purple-500 to-purple-600',
      features: [
        'Pre-qualified leads',
        'Detailed project info',
        'Location-based',
        'Design specifications'
      ]
    },
    {
      title: 'Quick Estimate Tools 🧮',
      description: 'Create professional quotes fast',
      content: 'Use our built-in calculator to generate accurate estimates in minutes. Include materials, labor, and timeline.',
      image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=800&q=80',
      icon: '💰',
      color: 'from-amber-500 to-amber-600',
      features: [
        'Fast calculations',
        'Professional templates',
        'Material pricing',
        'Send directly to clients'
      ]
    },
    {
      title: 'Manage Your Calendar 📅',
      description: 'Stay organized',
      content: 'Schedule consultations, installations, and follow-ups. Set reminders and sync with your team.',
      image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&q=80',
      icon: '📆',
      color: 'from-green-500 to-green-600',
      features: [
        'Appointment scheduling',
        'Team coordination',
        'Automatic reminders',
        'Client notifications'
      ]
    },
    {
      title: 'Build Your Reputation ⭐',
      description: 'Showcase your work',
      content: 'Collect reviews, display your portfolio, and build trust with potential customers. Great reviews mean more business.',
      image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=800&q=80',
      icon: '🌟',
      color: 'from-teal-500 to-teal-600',
      features: [
        'Customer reviews',
        'Photo gallery',
        'Rating system',
        'Verified projects'
      ]
    },
    {
      title: 'Direct Client Communication 💬',
      description: 'Message homeowners instantly',
      content: 'Chat with clients, share floor designs, answer questions, and close more deals. All in one place.',
      image: 'https://images.unsplash.com/photo-1615876234886-fd9a39fda97f?w=800&q=80',
      icon: '💬',
      color: 'from-pink-500 to-pink-600',
      features: [
        'In-app messaging',
        'Share designs',
        'Quick responses',
        'Professional image'
      ]
    },
    {
      title: 'Ready to Grow! 🚀',
      description: 'Start getting more leads',
      content: 'You\'re ready to take your flooring business to the next level. Let\'s get started!',
      image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',
      icon: '🎯',
      color: 'from-indigo-500 to-indigo-600',
      cta: 'Go to Dashboard'
    }
  ];

  const steps = userType === 'homeowner' ? homeownerSteps : contractorSteps;
  const step = steps[currentStep];
  const isLastStep = currentStep === steps.length - 1;

  const handleNext = () => {
    if (isLastStep) {
      onComplete();
    } else {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl">
        {/* Progress Bar */}
        <div className="bg-neutral-100 h-2">
          <div
            className={`h-full bg-gradient-to-r ${step.color} transition-all duration-500`}
            style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
          />
        </div>

        <div className="p-8 md:p-12 overflow-y-auto max-h-[calc(90vh-8rem)]">
          {/* Step Counter */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    index === currentStep
                      ? 'w-8 bg-blue-600'
                      : index < currentStep
                      ? 'w-2 bg-blue-600'
                      : 'w-2 bg-neutral-300'
                  }`}
                />
              ))}
            </div>
            <button
              onClick={handleSkip}
              className="text-neutral-500 hover:text-neutral-700 text-sm transition-colors"
            >
              Skip Tutorial
            </button>
          </div>

          {/* Content */}
          <div className="grid md:grid-cols-2 gap-8 items-center">
            {/* Left Side - Text Content */}
            <div className="order-2 md:order-1">
              <div className="text-6xl mb-4">{step.icon}</div>
              <h1 className="text-neutral-900 text-3xl mb-3">{step.title}</h1>
              <p className={`bg-gradient-to-r ${step.color} bg-clip-text text-transparent text-xl mb-4`}>
                {step.description}
              </p>
              <p className="text-neutral-600 text-lg mb-6 leading-relaxed">
                {step.content}
              </p>

              {/* Features List */}
              {step.features && (
                <div className="bg-neutral-50 rounded-xl p-6 mb-6">
                  <h3 className="text-neutral-900 mb-3 flex items-center gap-2">
                    <svg className="w-5 h-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    Key Features:
                  </h3>
                  <ul className="space-y-2">
                    {step.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3 text-neutral-700">
                        <svg className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* CTA for last step */}
              {isLastStep && (
                <div className="bg-gradient-to-r from-green-50 to-blue-50 border-2 border-green-200 rounded-xl p-6 mb-6">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
                      <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <h3 className="text-neutral-900 text-xl">You're Ready!</h3>
                  </div>
                  <p className="text-neutral-600">
                    You can always access help through the AI chat or tooltips throughout the app.
                  </p>
                </div>
              )}
            </div>

            {/* Right Side - Image */}
            <div className="order-1 md:order-2">
              <div className="relative rounded-2xl overflow-hidden shadow-xl">
                <img
                  src={step.image}
                  alt={step.title}
                  className="w-full h-80 object-cover"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${step.color} opacity-20`} />
              </div>
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between mt-8 pt-6 border-t border-neutral-200">
            <button
              onClick={handlePrev}
              disabled={currentStep === 0}
              className="flex items-center gap-2 px-6 py-3 text-neutral-600 hover:text-neutral-900 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              <span>Previous</span>
            </button>

            <div className="text-neutral-500 text-sm">
              Step {currentStep + 1} of {steps.length}
            </div>

            <button
              onClick={handleNext}
              className={`flex items-center gap-2 px-8 py-3 bg-gradient-to-r ${step.color} text-white rounded-lg hover:shadow-lg transition-all`}
            >
              <span>{isLastStep ? (step.cta || 'Get Started') : 'Next'}</span>
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
