import { useState, useEffect } from 'react';

interface WelcomeProps {
  onGetStarted: () => void;
}

export function Welcome({ onGetStarted }: WelcomeProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [activeFeature, setActiveFeature] = useState(0);

  const heroImages = [
    'https://images.unsplash.com/photo-1631669394390-baf737ef47de?w=1200&q=80',
    'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=1200&q=80',
    'https://images.unsplash.com/photo-1719782758766-f0a4a3808afe?w=1200&q=80'
  ];

  const stats = [
    { value: '7+', label: 'Flooring Types', icon: '🏠' },
    { value: '500+', label: 'Verified Contractors', icon: '👷' },
    { value: '1,000+', label: 'Happy Customers', icon: '⭐' },
    { value: '24/7', label: 'AI Support', icon: '💬' }
  ];

  const features = [
    {
      title: 'Browse & Compare Flooring',
      description: 'Explore 7 flooring types with detailed specs, real pricing, durability ratings, and expert recommendations. Compare side-by-side to make the best choice.',
      icon: '🔍',
      image: 'https://images.unsplash.com/photo-1631669394390-baf737ef47de?w=600&q=80',
      color: 'from-blue-500 to-blue-600',
      highlights: ['Hardwood', 'LVP', 'Tile', 'Carpet', 'Epoxy', 'Laminate', 'Engineered Wood']
    },
    {
      title: 'Design Your Perfect Floor',
      description: 'Use our interactive customization tools to select colors, finishes, materials, and patterns. See instant price estimates as you design.',
      icon: '🎨',
      image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=600&q=80',
      color: 'from-purple-500 to-purple-600',
      highlights: ['Custom Colors', 'Finishes', 'Patterns', 'Materials', 'Real-time Pricing']
    },
    {
      title: 'Visualize in Your Space',
      description: 'Upload a photo of your room and see different flooring options in real-time. Share designs with contractors for accurate quotes.',
      icon: '📸',
      image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=600&q=80',
      color: 'from-green-500 to-green-600',
      highlights: ['Photo Upload', 'Live Preview', 'Share Designs', 'Save Projects']
    },
    {
      title: 'Connect with Pros',
      description: 'Browse verified contractors, read real reviews, compare quotes, and message them directly. All contractors are background-checked.',
      icon: '✅',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=80',
      color: 'from-amber-500 to-amber-600',
      highlights: ['Verified Pros', 'Real Reviews', 'Direct Messaging', 'Multiple Quotes']
    }
  ];

  const benefits = [
    {
      icon: '💰',
      title: 'Save Money',
      description: 'Compare prices instantly and get competitive quotes from multiple contractors'
    },
    {
      icon: '⏱️',
      title: 'Save Time',
      description: 'Everything in one place - no more calling around or visiting multiple stores'
    },
    {
      icon: '🎯',
      title: 'Make Better Decisions',
      description: 'Access expert guides, comparison tools, and AI assistance to choose wisely'
    },
    {
      icon: '🛡️',
      title: 'Trust & Safety',
      description: 'All contractors are verified, background-checked, and rated by real customers'
    }
  ];

  const testimonials = [
    {
      name: 'Sarah M.',
      role: 'Homeowner',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80',
      text: 'Floor Master made choosing flooring so easy! I compared options, visualized them in my space, and got quotes from 3 contractors in one day.',
      rating: 5
    },
    {
      name: 'Mike R.',
      role: 'Contractor',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&q=80',
      text: 'Best lead generation platform for flooring contractors. The quality of leads is excellent and the tools make quoting fast and professional.',
      rating: 5
    },
    {
      name: 'Jennifer L.',
      role: 'Homeowner',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80',
      text: 'The AI assistant answered all my questions about durability and maintenance. I felt confident making my choice. Love my new LVP floors!',
      rating: 5
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveFeature((prev) => (prev + 1) % features.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Sticky Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-neutral-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-amber-600 to-amber-700 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white text-xl">🏠</span>
              </div>
              <div>
                <div className="text-neutral-900">Floor Master Solutions</div>
                <div className="text-xs text-neutral-600">Your Complete Flooring Platform</div>
              </div>
            </div>
            <button
              onClick={onGetStarted}
              className="px-6 py-2.5 bg-gradient-to-r from-amber-600 to-amber-700 text-white rounded-lg hover:shadow-lg transition-all"
            >
              Get Started Free
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section with Animated Background */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
        {/* Animated Background Images */}
        <div className="absolute inset-0">
          {heroImages.map((image, index) => (
            <div
              key={index}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                index === currentSlide ? 'opacity-20' : 'opacity-0'
              }`}
            >
              <img src={image} alt="" className="w-full h-full object-cover" />
            </div>
          ))}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600/30 via-purple-600/30 to-pink-600/30" />
        </div>

        {/* Hero Content */}
        <div className="relative max-w-7xl mx-auto px-6 py-20 md:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-block mb-6 px-4 py-2 bg-white/90 backdrop-blur-sm rounded-full text-sm text-amber-600 shadow-lg">
              ✨ Trusted by 1,000+ Happy Homeowners & 500+ Contractors
            </div>
            <h1 className="text-4xl md:text-6xl lg:text-7xl mb-6 text-neutral-900">
              Find Your Perfect Floor
              <span className="block mt-2 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 bg-clip-text text-transparent">
                In Minutes, Not Weeks
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-neutral-700 mb-10 max-w-3xl mx-auto leading-relaxed">
              Compare flooring options, visualize designs in your space, and connect with verified contractors — all in one beautiful platform
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
              <button
                onClick={onGetStarted}
                className="group px-8 py-4 bg-gradient-to-r from-amber-600 to-amber-700 text-white rounded-xl hover:shadow-2xl transition-all text-lg flex items-center gap-2"
              >
                <span>Start Your Project Free</span>
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </button>
              <button className="px-8 py-4 bg-white text-neutral-900 rounded-xl hover:shadow-xl transition-all text-lg border-2 border-neutral-200">
                Watch Demo (2 min)
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 shadow-xl">
                  <div className="text-4xl mb-2">{stat.icon}</div>
                  <div className="text-3xl text-neutral-900 mb-1">{stat.value}</div>
                  <div className="text-sm text-neutral-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Decorative Wave */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 0L60 10C120 20 240 40 360 46.7C480 53 600 47 720 43.3C840 40 960 40 1080 46.7C1200 53 1320 67 1380 73.3L1440 80V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0V0Z" fill="white"/>
          </svg>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl text-neutral-900 mb-4">
              How It Works
            </h2>
            <p className="text-xl text-neutral-600 max-w-2xl mx-auto">
              From browsing to installation — we've made every step simple and stress-free
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative">
            {/* Connection Line */}
            <div className="hidden md:block absolute top-24 left-0 right-0 h-1 bg-gradient-to-r from-blue-200 via-purple-200 to-amber-200 mx-32" />

            {[
              {
                step: '1',
                title: 'Browse & Compare',
                description: 'Explore 7+ flooring types with detailed specs and real pricing',
                icon: '🔍',
                color: 'from-blue-500 to-blue-600'
              },
              {
                step: '2',
                title: 'Customize & Design',
                description: 'Use our tools to create your perfect floor with live pricing',
                icon: '🎨',
                color: 'from-purple-500 to-purple-600'
              },
              {
                step: '3',
                title: 'Visualize & Share',
                description: 'See it in your space and share designs with contractors',
                icon: '📸',
                color: 'from-green-500 to-green-600'
              },
              {
                step: '4',
                title: 'Get It Installed',
                description: 'Connect with verified pros and schedule your installation',
                icon: '✅',
                color: 'from-amber-500 to-amber-600'
              }
            ].map((item, index) => (
              <div key={index} className="relative">
                <div className="bg-white rounded-2xl p-8 text-center shadow-lg hover:shadow-2xl transition-all border-2 border-neutral-100 hover:border-blue-200">
                  <div className={`w-20 h-20 bg-gradient-to-br ${item.color} rounded-2xl flex items-center justify-center text-4xl mx-auto mb-4 shadow-lg relative z-10`}>
                    {item.icon}
                  </div>
                  <div className="absolute top-6 right-6 w-10 h-10 bg-gradient-to-br from-neutral-100 to-neutral-200 rounded-full flex items-center justify-center text-neutral-600">
                    {item.step}
                  </div>
                  <h3 className="text-neutral-900 text-xl mb-3">{item.title}</h3>
                  <p className="text-neutral-600">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Interactive Features Showcase */}
      <section className="py-20 bg-gradient-to-br from-neutral-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl text-neutral-900 mb-4">
              Everything You Need in One Place
            </h2>
            <p className="text-xl text-neutral-600">
              Powerful tools that make flooring selection simple and fun
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Feature Tabs */}
            <div className="space-y-4">
              {features.map((feature, index) => (
                <button
                  key={index}
                  onClick={() => setActiveFeature(index)}
                  className={`w-full text-left p-6 rounded-2xl transition-all ${
                    activeFeature === index
                      ? 'bg-white shadow-xl border-2 border-blue-200'
                      : 'bg-white/50 hover:bg-white border-2 border-transparent'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-14 h-14 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center text-2xl flex-shrink-0 shadow-lg`}>
                      {feature.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-neutral-900 text-xl mb-2">{feature.title}</h3>
                      <p className="text-neutral-600 mb-3">{feature.description}</p>
                      {activeFeature === index && (
                        <div className="flex flex-wrap gap-2">
                          {feature.highlights.map((highlight, i) => (
                            <span key={i} className="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
                              {highlight}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Feature Image */}
            <div className="relative">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                {features.map((feature, index) => (
                  <img
                    key={index}
                    src={feature.image}
                    alt={feature.title}
                    className={`w-full h-[500px] object-cover transition-opacity duration-500 ${
                      activeFeature === index ? 'opacity-100' : 'opacity-0 absolute inset-0'
                    }`}
                  />
                ))}
                <div className={`absolute inset-0 bg-gradient-to-t ${features[activeFeature].color} opacity-20`} />
              </div>
              {/* Floating Badge */}
              <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl p-6 shadow-2xl">
                <div className="text-4xl mb-2">🎉</div>
                <div className="text-2xl text-neutral-900">Free to Use</div>
                <div className="text-sm text-neutral-600">No credit card needed</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl text-neutral-900 mb-4">
              Why Choose Floor Master?
            </h2>
            <p className="text-xl text-neutral-600">
              Join thousands who've transformed their spaces the smart way
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="bg-gradient-to-br from-neutral-50 to-blue-50 rounded-2xl p-8 text-center hover:shadow-xl transition-all border-2 border-neutral-100 hover:border-blue-200">
                <div className="text-6xl mb-4">{benefit.icon}</div>
                <h3 className="text-neutral-900 text-xl mb-3">{benefit.title}</h3>
                <p className="text-neutral-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl text-neutral-900 mb-4">
              Loved by Homeowners & Contractors
            </h2>
            <p className="text-xl text-neutral-600">
              See what our community has to say
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all">
                <div className="flex items-center gap-4 mb-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div>
                    <div className="text-neutral-900">{testimonial.name}</div>
                    <div className="text-sm text-neutral-600">{testimonial.role}</div>
                  </div>
                </div>
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <svg key={i} className="w-5 h-5 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-neutral-700 italic">"{testimonial.text}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-br from-amber-600 to-amber-700 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-20" />
        <div className="relative max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl text-white mb-6">
            Ready to Transform Your Space?
          </h2>
          <p className="text-xl text-amber-100 mb-10 max-w-2xl mx-auto">
            Join 1,000+ happy homeowners who found their perfect floor with Floor Master Solutions
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onGetStarted}
              className="px-10 py-5 bg-white text-amber-700 rounded-xl hover:shadow-2xl transition-all text-xl flex items-center gap-2"
            >
              <span>Start Your Free Project</span>
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </button>
          </div>
          <p className="text-amber-100 mt-6 text-sm">
            No credit card required • Free forever • Get started in 60 seconds
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-neutral-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-amber-600 rounded-lg flex items-center justify-center">
                  <span className="text-white">🏠</span>
                </div>
                <span className="text-white">Floor Master</span>
              </div>
              <p className="text-neutral-400 text-sm">
                Your complete flooring platform - from learning to installation.
              </p>
            </div>
            <div>
              <h4 className="text-white mb-4">For Homeowners</h4>
              <ul className="space-y-2 text-sm text-neutral-400">
                <li>Browse Flooring</li>
                <li>Compare Options</li>
                <li>Visualize Designs</li>
                <li>Find Contractors</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white mb-4">For Contractors</h4>
              <ul className="space-y-2 text-sm text-neutral-400">
                <li>Get Leads</li>
                <li>Manage Calendar</li>
                <li>Create Estimates</li>
                <li>Build Reputation</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-neutral-400">
                <li>About Us</li>
                <li>Contact</li>
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-neutral-800 pt-8 text-center text-sm text-neutral-400">
            <p>© 2024 Floor Master Solutions. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
