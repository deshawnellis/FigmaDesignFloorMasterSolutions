import { ReactNode } from 'react';

export interface Breadcrumb {
  label: string;
  icon?: ReactNode;
  onClick?: () => void;
}

interface BreadcrumbsProps {
  items: Breadcrumb[];
  className?: string;
}

export function Breadcrumbs({ items, className = '' }: BreadcrumbsProps) {
  return (
    <nav className={`flex items-center gap-2 ${className}`} aria-label="Breadcrumb">
      <div className="flex items-center gap-2 flex-wrap">
        {items.map((item, index) => {
          const isLast = index === items.length - 1;
          const isClickable = item.onClick && !isLast;

          return (
            <div key={index} className="flex items-center gap-2">
              {isClickable ? (
                <button
                  onClick={item.onClick}
                  className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 transition-colors group"
                >
                  {item.icon && (
                    <span className="text-neutral-500 group-hover:text-neutral-700 transition-colors">
                      {item.icon}
                    </span>
                  )}
                  <span className="text-sm hover:underline">{item.label}</span>
                </button>
              ) : (
                <div className={`flex items-center gap-2 ${isLast ? 'text-neutral-900' : 'text-neutral-600'}`}>
                  {item.icon && <span>{item.icon}</span>}
                  <span className={`text-sm ${isLast ? '' : ''}`}>{item.label}</span>
                </div>
              )}

              {!isLast && (
                <svg
                  className="w-4 h-4 text-neutral-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              )}
            </div>
          );
        })}
      </div>
    </nav>
  );
}

interface PageHeaderProps {
  title: string;
  description?: string;
  breadcrumbs?: Breadcrumb[];
  actions?: ReactNode;
  icon?: ReactNode;
  badge?: string;
}

export function PageHeader({ title, description, breadcrumbs, actions, icon, badge }: PageHeaderProps) {
  return (
    <div className="bg-white border-b border-neutral-200 sticky top-0 z-20 shadow-sm">
      <div className="max-w-7xl mx-auto px-6 py-6">
        {/* Breadcrumbs */}
        {breadcrumbs && breadcrumbs.length > 0 && (
          <div className="mb-4">
            <Breadcrumbs items={breadcrumbs} />
          </div>
        )}

        {/* Title and Actions */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              {icon && (
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600 flex-shrink-0">
                  {icon}
                </div>
              )}
              <div>
                <div className="flex items-center gap-3">
                  <h1 className="text-neutral-900 text-2xl md:text-3xl">{title}</h1>
                  {badge && (
                    <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                      {badge}
                    </span>
                  )}
                </div>
                {description && (
                  <p className="text-neutral-600 mt-1">{description}</p>
                )}
              </div>
            </div>
          </div>
          {actions && <div className="flex-shrink-0">{actions}</div>}
        </div>
      </div>
    </div>
  );
}

interface ProgressTrackerProps {
  currentStep: number;
  totalSteps: number;
  stepLabel?: string;
  showPercentage?: boolean;
}

export function ProgressTracker({ currentStep, totalSteps, stepLabel, showPercentage = true }: ProgressTrackerProps) {
  const percentage = Math.round((currentStep / totalSteps) * 100);

  return (
    <div className="bg-blue-50 border-b border-blue-100 py-3 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm">
              {currentStep}
            </div>
            {stepLabel && (
              <span className="text-neutral-900">{stepLabel}</span>
            )}
          </div>
          {showPercentage && (
            <span className="text-neutral-600 text-sm">
              {percentage}% Complete
            </span>
          )}
        </div>
        <div className="h-2 bg-blue-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-blue-600 transition-all duration-500 rounded-full"
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
    </div>
  );
}

interface NavigationHistoryProps {
  history: string[];
  onNavigate: (index: number) => void;
  maxItems?: number;
}

export function NavigationHistory({ history, onNavigate, maxItems = 5 }: NavigationHistoryProps) {
  const displayHistory = history.slice(-maxItems);

  return (
    <div className="bg-neutral-50 border-b border-neutral-200 py-2 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-2 text-sm">
          <svg className="w-4 h-4 text-neutral-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span className="text-neutral-600">Recent:</span>
          <div className="flex items-center gap-1 overflow-x-auto">
            {displayHistory.map((item, index) => (
              <button
                key={index}
                onClick={() => onNavigate(history.length - displayHistory.length + index)}
                className="px-2 py-1 text-neutral-700 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors whitespace-nowrap"
              >
                {item}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
