import { useState, useRef, useEffect } from 'react';

interface Message {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  timestamp: string;
  floorDesign?: {
    id: string;
    name: string;
    image: string;
    details: string;
  };
}

interface Conversation {
  id: string;
  participantId: string;
  participantName: string;
  participantAvatar: string;
  participantRole: 'contractor' | 'homeowner';
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  messages: Message[];
}

interface MessagingSystemProps {
  userType: 'homeowner' | 'contractor';
  userId: string;
  userName: string;
  userAvatar: string;
  onClose: () => void;
}

export function MessagingSystem({ userType, userId, userName, userAvatar, onClose }: MessagingSystemProps) {
  const [conversations, setConversations] = useState<Conversation[]>(
    userType === 'homeowner' ? homeownerConversations : contractorConversations
  );
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(
    conversations[0] || null
  );
  const [messageText, setMessageText] = useState('');
  const [showFloorPicker, setShowFloorPicker] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [selectedConversation?.messages]);

  const sendMessage = (floorDesign?: Message['floorDesign']) => {
    if (!messageText.trim() && !floorDesign) return;
    if (!selectedConversation) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      senderId: userId,
      senderName: userName,
      senderAvatar: userAvatar,
      text: messageText,
      timestamp: new Date().toISOString(),
      floorDesign
    };

    const updatedConversations = conversations.map(conv => {
      if (conv.id === selectedConversation.id) {
        return {
          ...conv,
          messages: [...conv.messages, newMessage],
          lastMessage: floorDesign ? '📷 Shared a floor design' : messageText,
          lastMessageTime: new Date().toISOString()
        };
      }
      return conv;
    });

    setConversations(updatedConversations);
    setSelectedConversation(updatedConversations.find(c => c.id === selectedConversation.id) || null);
    setMessageText('');
    setShowFloorPicker(false);
  };

  const formatMessageTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };

  const formatConversationTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-6xl h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <h2 className="text-white text-xl">Messages</h2>
          </div>
          <button
            onClick={onClose}
            className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* Conversations List */}
          <div className="w-80 border-r border-neutral-200 flex flex-col bg-neutral-50">
            <div className="p-4 border-b border-neutral-200">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search conversations..."
                  className="w-full pl-10 pr-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <svg className="w-5 h-5 text-neutral-400 absolute left-3 top-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              {conversations.map((conversation) => (
                <button
                  key={conversation.id}
                  onClick={() => setSelectedConversation(conversation)}
                  className={`w-full p-4 flex items-start gap-3 hover:bg-white transition-colors text-left border-b border-neutral-100 ${
                    selectedConversation?.id === conversation.id ? 'bg-white' : ''
                  }`}
                >
                  <div className="relative flex-shrink-0">
                    <img
                      src={conversation.participantAvatar}
                      alt={conversation.participantName}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    {conversation.unreadCount > 0 && (
                      <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                        {conversation.unreadCount}
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1">
                      <h4 className="text-neutral-900 truncate">{conversation.participantName}</h4>
                      <span className="text-xs text-neutral-500 flex-shrink-0 ml-2">
                        {formatConversationTime(conversation.lastMessageTime)}
                      </span>
                    </div>
                    <p className="text-sm text-neutral-600 truncate">{conversation.lastMessage}</p>
                    <span className="text-xs text-neutral-500 capitalize">{conversation.participantRole}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Chat Area */}
          {selectedConversation ? (
            <div className="flex-1 flex flex-col">
              {/* Chat Header */}
              <div className="p-4 border-b border-neutral-200 bg-white">
                <div className="flex items-center gap-3">
                  <img
                    src={selectedConversation.participantAvatar}
                    alt={selectedConversation.participantName}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="text-neutral-900">{selectedConversation.participantName}</h3>
                    <p className="text-sm text-neutral-600 capitalize">{selectedConversation.participantRole}</p>
                  </div>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-neutral-50">
                {selectedConversation.messages.map((message) => {
                  const isOwnMessage = message.senderId === userId;
                  return (
                    <div
                      key={message.id}
                      className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`flex gap-2 max-w-[70%] ${isOwnMessage ? 'flex-row-reverse' : 'flex-row'}`}>
                        <img
                          src={message.senderAvatar}
                          alt={message.senderName}
                          className="w-8 h-8 rounded-full object-cover flex-shrink-0"
                        />
                        <div>
                          <div
                            className={`rounded-2xl p-3 ${
                              isOwnMessage
                                ? 'bg-blue-600 text-white'
                                : 'bg-white text-neutral-900 border border-neutral-200'
                            }`}
                          >
                            {message.floorDesign && (
                              <div className="mb-2">
                                <div className="rounded-lg overflow-hidden mb-2">
                                  <img
                                    src={message.floorDesign.image}
                                    alt={message.floorDesign.name}
                                    className="w-full h-48 object-cover"
                                  />
                                </div>
                                <div className={`text-sm ${isOwnMessage ? 'text-blue-100' : 'text-neutral-600'}`}>
                                  <p className="mb-1">
                                    <strong className={isOwnMessage ? 'text-white' : 'text-neutral-900'}>
                                      {message.floorDesign.name}
                                    </strong>
                                  </p>
                                  <p>{message.floorDesign.details}</p>
                                </div>
                              </div>
                            )}
                            {message.text && <p>{message.text}</p>}
                          </div>
                          <p className={`text-xs text-neutral-500 mt-1 ${isOwnMessage ? 'text-right' : 'text-left'}`}>
                            {formatMessageTime(message.timestamp)}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Floor Design Picker */}
              {showFloorPicker && (
                <div className="p-4 bg-white border-t border-neutral-200">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-neutral-900">Share a Floor Design</h4>
                    <button
                      onClick={() => setShowFloorPicker(false)}
                      className="text-neutral-400 hover:text-neutral-600"
                    >
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    {mockFloorDesigns.map((design) => (
                      <button
                        key={design.id}
                        onClick={() => {
                          sendMessage(design);
                        }}
                        className="group relative rounded-lg overflow-hidden border-2 border-neutral-200 hover:border-blue-600 transition-colors"
                      >
                        <img
                          src={design.image}
                          alt={design.name}
                          className="w-full h-32 object-cover"
                        />
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <span className="text-white text-sm">Share</span>
                        </div>
                        <div className="p-2 bg-white">
                          <p className="text-xs text-neutral-900 truncate">{design.name}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Message Input */}
              <div className="p-4 bg-white border-t border-neutral-200">
                <div className="flex items-end gap-2">
                  <button
                    onClick={() => setShowFloorPicker(!showFloorPicker)}
                    className={`p-2 rounded-lg transition-colors flex-shrink-0 ${
                      showFloorPicker
                        ? 'bg-blue-600 text-white'
                        : 'text-neutral-600 hover:bg-neutral-100'
                    }`}
                    title="Share floor design"
                  >
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </button>
                  <div className="flex-1 relative">
                    <textarea
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          sendMessage();
                        }
                      }}
                      placeholder="Type a message..."
                      rows={1}
                      className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 resize-none"
                    />
                  </div>
                  <button
                    onClick={() => sendMessage()}
                    disabled={!messageText.trim()}
                    className="p-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 disabled:bg-neutral-300 disabled:cursor-not-allowed transition-colors flex-shrink-0"
                  >
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                    </svg>
                  </button>
                </div>
                <p className="text-xs text-neutral-500 mt-2">Press Enter to send, Shift+Enter for new line</p>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center bg-neutral-50">
              <div className="text-center">
                <svg className="w-20 h-20 text-neutral-300 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
                <h3 className="text-neutral-900 mb-2">No Conversation Selected</h3>
                <p className="text-neutral-600">Select a conversation to start messaging</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Mock floor designs that can be shared
const mockFloorDesigns = [
  {
    id: 'design1',
    name: 'White Oak Hardwood - Living Room',
    image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=600&q=80',
    details: 'Prefinished White Oak, Natural finish, 5" planks'
  },
  {
    id: 'design2',
    name: 'Walnut Engineered - Bedroom',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&q=80',
    details: 'Engineered Walnut, Matte finish, 7" wide planks'
  },
  {
    id: 'design3',
    name: 'Gray LVP - Kitchen',
    image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=600&q=80',
    details: 'Wood-look LVP, 20mil wear layer, Waterproof'
  },
  {
    id: 'design4',
    name: 'Maple Light - Open Floor Plan',
    image: 'https://images.unsplash.com/photo-1615876234886-fd9a39fda97f?w=600&q=80',
    details: 'Hard Maple, Natural finish, 3.25" strips'
  },
  {
    id: 'design5',
    name: 'Hickory Rustic - Den',
    image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=600&q=80',
    details: 'Hickory with color variation, Hand-scraped'
  },
  {
    id: 'design6',
    name: 'Cherry Traditional - Dining Room',
    image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=600&q=80',
    details: 'American Cherry, Satin finish, 3" planks'
  }
];

// Mock conversations for homeowners
const homeownerConversations: Conversation[] = [
  {
    id: 'conv1',
    participantId: 'contractor1',
    participantName: 'Mike\'s Flooring',
    participantAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&q=80',
    participantRole: 'contractor',
    lastMessage: 'I\'ve prepared a quote for your hardwood selection.',
    lastMessageTime: new Date(Date.now() - 300000).toISOString(),
    unreadCount: 2,
    messages: [
      {
        id: 'msg1',
        senderId: 'homeowner1',
        senderName: 'You',
        senderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80',
        text: 'Hi! I\'m interested in getting a quote for white oak hardwood floors in my living room.',
        timestamp: new Date(Date.now() - 7200000).toISOString()
      },
      {
        id: 'msg2',
        senderId: 'contractor1',
        senderName: 'Mike\'s Flooring',
        senderAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&q=80',
        text: 'Great choice! White oak is beautiful and durable. How many square feet are we working with?',
        timestamp: new Date(Date.now() - 7000000).toISOString()
      },
      {
        id: 'msg3',
        senderId: 'homeowner1',
        senderName: 'You',
        senderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80',
        text: 'About 400 square feet. Here\'s the design I was looking at:',
        timestamp: new Date(Date.now() - 6800000).toISOString(),
        floorDesign: mockFloorDesigns[0]
      },
      {
        id: 'msg4',
        senderId: 'contractor1',
        senderName: 'Mike\'s Flooring',
        senderAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&q=80',
        text: 'Perfect! That\'s a beautiful choice. I\'ve prepared a quote for your hardwood selection. Total cost including materials and installation: $4,850. This includes premium white oak with natural finish.',
        timestamp: new Date(Date.now() - 300000).toISOString()
      }
    ]
  },
  {
    id: 'conv2',
    participantId: 'contractor2',
    participantName: 'Premium Floors Co.',
    participantAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&q=80',
    participantRole: 'contractor',
    lastMessage: 'Your samples are on the way!',
    lastMessageTime: new Date(Date.now() - 86400000).toISOString(),
    unreadCount: 0,
    messages: [
      {
        id: 'msg5',
        senderId: 'homeowner1',
        senderName: 'You',
        senderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80',
        text: 'Can I get samples of your LVP options?',
        timestamp: new Date(Date.now() - 172800000).toISOString()
      },
      {
        id: 'msg6',
        senderId: 'contractor2',
        senderName: 'Premium Floors Co.',
        senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&q=80',
        text: 'Absolutely! I\'ll send you samples of our top 5 LVP styles. Your samples are on the way!',
        timestamp: new Date(Date.now() - 86400000).toISOString()
      }
    ]
  }
];

// Mock conversations for contractors
const contractorConversations: Conversation[] = [
  {
    id: 'conv3',
    participantId: 'homeowner2',
    participantName: 'Sarah Johnson',
    participantAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80',
    participantRole: 'homeowner',
    lastMessage: 'When can you start the installation?',
    lastMessageTime: new Date(Date.now() - 600000).toISOString(),
    unreadCount: 1,
    messages: [
      {
        id: 'msg7',
        senderId: 'contractor1',
        senderName: 'You',
        senderAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&q=80',
        text: 'Hi Sarah! Thanks for accepting the quote. I have availability starting next week.',
        timestamp: new Date(Date.now() - 3600000).toISOString()
      },
      {
        id: 'msg8',
        senderId: 'homeowner2',
        senderName: 'Sarah Johnson',
        senderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80',
        text: 'That works for me! When can you start the installation?',
        timestamp: new Date(Date.now() - 600000).toISOString()
      }
    ]
  },
  {
    id: 'conv4',
    participantId: 'homeowner3',
    participantName: 'Emily Rodriguez',
    participantAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&q=80',
    participantRole: 'homeowner',
    lastMessage: 'Can you create a visualization for my room?',
    lastMessageTime: new Date(Date.now() - 1800000).toISOString(),
    unreadCount: 1,
    messages: [
      {
        id: 'msg9',
        senderId: 'homeowner3',
        senderName: 'Emily Rodriguez',
        senderAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&q=80',
        text: 'I\'m deciding between these two options:',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        floorDesign: mockFloorDesigns[1]
      },
      {
        id: 'msg10',
        senderId: 'homeowner3',
        senderName: 'Emily Rodriguez',
        senderAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&q=80',
        text: 'Can you create a visualization for my room?',
        timestamp: new Date(Date.now() - 1800000).toISOString()
      }
    ]
  }
];
