import { ReactNode } from 'react';

export interface WizardStep {
  id: string;
  label: string;
  icon: ReactNode;
  description?: string;
}

interface ProgressWizardProps {
  steps: WizardStep[];
  currentStep: number;
  onStepClick?: (stepIndex: number) => void;
  allowSkipAhead?: boolean;
}

export function ProgressWizard({ steps, currentStep, onStepClick, allowSkipAhead = false }: ProgressWizardProps) {
  const handleStepClick = (index: number) => {
    if (!onStepClick) return;
    if (allowSkipAhead || index <= currentStep) {
      onStepClick(index);
    }
  };

  return (
    <div className="w-full bg-white border-b border-neutral-200 sticky top-0 z-10 shadow-sm">
      {/* Desktop View */}
      <div className="hidden md:block max-w-7xl mx-auto px-6 py-6">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => {
            const isActive = index === currentStep;
            const isCompleted = index < currentStep;
            const isClickable = allowSkipAhead || index <= currentStep;

            return (
              <div key={step.id} className="flex items-center flex-1">
                {/* Step Circle */}
                <button
                  onClick={() => handleStepClick(index)}
                  disabled={!isClickable}
                  className={`relative group ${isClickable ? 'cursor-pointer' : 'cursor-not-allowed'}`}
                >
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
                      isActive
                        ? 'bg-blue-600 text-white ring-4 ring-blue-100 scale-110'
                        : isCompleted
                        ? 'bg-green-600 text-white'
                        : 'bg-neutral-200 text-neutral-500'
                    } ${isClickable && !isActive ? 'hover:scale-105' : ''}`}
                  >
                    {isCompleted ? (
                      <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    ) : (
                      <div className="text-lg">{step.icon}</div>
                    )}
                  </div>

                  {/* Step Label */}
                  <div className="absolute top-full mt-2 left-1/2 transform -translate-x-1/2 text-center min-w-max">
                    <p
                      className={`text-sm transition-all ${
                        isActive
                          ? 'text-blue-600'
                          : isCompleted
                          ? 'text-green-600'
                          : 'text-neutral-500'
                      }`}
                    >
                      {step.label}
                    </p>
                    {step.description && isActive && (
                      <p className="text-xs text-neutral-500 mt-1">{step.description}</p>
                    )}
                  </div>
                </button>

                {/* Connector Line */}
                {index < steps.length - 1 && (
                  <div className="flex-1 px-4">
                    <div className="relative h-1 bg-neutral-200 rounded-full overflow-hidden">
                      <div
                        className={`absolute inset-y-0 left-0 rounded-full transition-all duration-500 ${
                          index < currentStep ? 'bg-green-600 w-full' : 'w-0 bg-blue-600'
                        }`}
                      />
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Mobile View */}
      <div className="md:hidden px-4 py-4">
        {/* Progress Bar */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-neutral-600">
              Step {currentStep + 1} of {steps.length}
            </span>
            <span className="text-sm text-neutral-600">
              {Math.round(((currentStep + 1) / steps.length) * 100)}%
            </span>
          </div>
          <div className="h-2 bg-neutral-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-600 transition-all duration-500 rounded-full"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Current Step Info */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white flex-shrink-0">
            {steps[currentStep].icon}
          </div>
          <div className="flex-1">
            <h3 className="text-neutral-900">{steps[currentStep].label}</h3>
            {steps[currentStep].description && (
              <p className="text-sm text-neutral-600">{steps[currentStep].description}</p>
            )}
          </div>
        </div>

        {/* Step Indicators */}
        <div className="flex items-center gap-2 mt-4 overflow-x-auto pb-2">
          {steps.map((step, index) => (
            <button
              key={step.id}
              onClick={() => handleStepClick(index)}
              disabled={!allowSkipAhead && index > currentStep}
              className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs transition-all ${
                index === currentStep
                  ? 'bg-blue-600 text-white ring-2 ring-blue-200'
                  : index < currentStep
                  ? 'bg-green-600 text-white'
                  : 'bg-neutral-200 text-neutral-500'
              } ${allowSkipAhead || index <= currentStep ? 'cursor-pointer' : 'cursor-not-allowed'}`}
            >
              {index < currentStep ? (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              ) : (
                index + 1
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

interface WizardNavigationProps {
  onPrevious?: () => void;
  onNext?: () => void;
  onComplete?: () => void;
  previousLabel?: string;
  nextLabel?: string;
  completeLabel?: string;
  isFirstStep?: boolean;
  isLastStep?: boolean;
  canProceed?: boolean;
  showProgress?: boolean;
  currentStep?: number;
  totalSteps?: number;
}

export function WizardNavigation({
  onPrevious,
  onNext,
  onComplete,
  previousLabel = 'Previous',
  nextLabel = 'Next',
  completeLabel = 'Complete',
  isFirstStep = false,
  isLastStep = false,
  canProceed = true,
  showProgress = false,
  currentStep = 0,
  totalSteps = 0
}: WizardNavigationProps) {
  return (
    <div className="sticky bottom-0 bg-white border-t border-neutral-200 p-4 md:p-6 shadow-lg z-10">
      <div className="max-w-7xl mx-auto">
        {showProgress && totalSteps > 0 && (
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-neutral-600">Progress</span>
              <span className="text-sm text-neutral-600">
                {Math.round(((currentStep + 1) / totalSteps) * 100)}% Complete
              </span>
            </div>
            <div className="h-1.5 bg-neutral-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-600 to-blue-500 transition-all duration-500"
                style={{ width: `${((currentStep + 1) / totalSteps) * 100}%` }}
              />
            </div>
          </div>
        )}

        <div className="flex items-center justify-between gap-4">
          <button
            onClick={onPrevious}
            disabled={isFirstStep || !onPrevious}
            className="flex items-center gap-2 px-6 py-3 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span className="hidden sm:inline">{previousLabel}</span>
          </button>

          <div className="flex items-center gap-3">
            {!canProceed && (
              <div className="hidden md:flex items-center gap-2 text-amber-600 text-sm bg-amber-50 px-4 py-2 rounded-lg">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                <span>Complete required fields</span>
              </div>
            )}

            <button
              onClick={isLastStep ? onComplete : onNext}
              disabled={!canProceed || (!isLastStep && !onNext) || (isLastStep && !onComplete)}
              className="flex items-center gap-2 px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-blue-600 shadow-lg hover:shadow-xl"
            >
              <span>{isLastStep ? completeLabel : nextLabel}</span>
              {isLastStep ? (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              ) : (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
