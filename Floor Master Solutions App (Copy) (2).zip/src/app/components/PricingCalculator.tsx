import { useState } from 'react';
import { flooringTypes } from '../data/flooringTypes';

interface PricingCalculatorProps {
  flooringType?: string;
  onClose?: () => void;
}

export function PricingCalculator({ flooringType, onClose }: PricingCalculatorProps) {
  const [selectedType, setSelectedType] = useState(flooringType || 'hardwood');
  const [squareFootage, setSquareFootage] = useState(500);
  const [quality, setQuality] = useState<'budget' | 'mid-range' | 'premium'>('mid-range');
  const [includeInstallation, setIncludeInstallation] = useState(true);
  const [includeRemoval, setIncludeRemoval] = useState(false);
  const [includeSubfloor, setIncludeSubfloor] = useState(false);

  const flooring = flooringTypes.find(f => f.id === selectedType);

  const calculatePrice = () => {
    if (!flooring) return { low: 0, mid: 0, high: 0 };

    // Extract price range from string (e.g., "$8-$15 per sq ft")
    const priceMatch = flooring.priceRange.match(/\$(\d+)-\$(\d+)/);
    if (!priceMatch) return { low: 0, mid: 0, high: 0 };

    let lowPrice = parseFloat(priceMatch[1]);
    let highPrice = parseFloat(priceMatch[2]);

    // Adjust for quality
    if (quality === 'budget') {
      lowPrice = lowPrice * 0.8;
      highPrice = lowPrice * 1.2;
    } else if (quality === 'premium') {
      lowPrice = highPrice * 0.9;
      highPrice = highPrice * 1.3;
    }

    // Material cost
    let materialLow = lowPrice * squareFootage;
    let materialHigh = highPrice * squareFootage;

    // Installation cost (typically $2-5 per sq ft)
    let installLow = 0;
    let installHigh = 0;
    if (includeInstallation) {
      installLow = 2 * squareFootage;
      installHigh = 5 * squareFootage;
    }

    // Removal cost (typically $1-3 per sq ft)
    let removalLow = 0;
    let removalHigh = 0;
    if (includeRemoval) {
      removalLow = 1 * squareFootage;
      removalHigh = 3 * squareFootage;
    }

    // Subfloor prep (typically $1-4 per sq ft)
    let subfloorLow = 0;
    let subfloorHigh = 0;
    if (includeSubfloor) {
      subfloorLow = 1 * squareFootage;
      subfloorHigh = 4 * squareFootage;
    }

    const totalLow = materialLow + installLow + removalLow + subfloorLow;
    const totalHigh = materialHigh + installHigh + removalHigh + subfloorHigh;
    const totalMid = (totalLow + totalHigh) / 2;

    return {
      low: Math.round(totalLow),
      mid: Math.round(totalMid),
      high: Math.round(totalHigh),
      breakdown: {
        material: { low: Math.round(materialLow), high: Math.round(materialHigh) },
        installation: { low: Math.round(installLow), high: Math.round(installHigh) },
        removal: { low: Math.round(removalLow), high: Math.round(removalHigh) },
        subfloor: { low: Math.round(subfloorLow), high: Math.round(subfloorHigh) }
      }
    };
  };

  const estimate = calculatePrice();

  const getQualityDescription = () => {
    switch (quality) {
      case 'budget':
        return 'Good value, basic quality materials';
      case 'mid-range':
        return 'Best balance of quality and price';
      case 'premium':
        return 'High-end materials and finishes';
      default:
        return '';
    }
  };

  return (
    <div className={`${onClose ? 'fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4' : ''}`}>
      <div className={`bg-white rounded-2xl ${onClose ? 'max-w-5xl w-full max-h-[90vh] overflow-y-auto' : 'w-full'} shadow-2xl`}>
        {/* Header */}
        {onClose && (
          <div className="bg-gradient-to-r from-green-600 to-green-700 text-white p-6 rounded-t-2xl sticky top-0 z-10">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-white text-2xl mb-2">💰 Pricing Calculator</h2>
                <p className="text-green-100">Get instant cost estimates for your flooring project</p>
              </div>
              <button
                onClick={onClose}
                className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
              >
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>
        )}

        <div className="p-6 md:p-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Configuration Panel */}
            <div className="space-y-6">
              {/* Flooring Type */}
              <div>
                <label className="block text-neutral-900 mb-3 flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                  </svg>
                  Flooring Type
                </label>
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                >
                  {flooringTypes.map(type => (
                    <option key={type.id} value={type.id}>{type.name}</option>
                  ))}
                </select>
              </div>

              {/* Square Footage Slider */}
              <div>
                <label className="block text-neutral-900 mb-3 flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <svg className="w-5 h-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                    </svg>
                    Square Footage
                  </span>
                  <span className="text-blue-600 text-xl">{squareFootage.toLocaleString()} sq ft</span>
                </label>
                <input
                  type="range"
                  min="100"
                  max="5000"
                  step="50"
                  value={squareFootage}
                  onChange={(e) => setSquareFootage(parseInt(e.target.value))}
                  className="w-full h-3 bg-neutral-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <div className="flex justify-between text-sm text-neutral-600 mt-2">
                  <span>100 sq ft</span>
                  <span>5,000 sq ft</span>
                </div>
              </div>

              {/* Quality Level */}
              <div>
                <label className="block text-neutral-900 mb-3 flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                  </svg>
                  Quality Level
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {(['budget', 'mid-range', 'premium'] as const).map((level) => (
                    <button
                      key={level}
                      onClick={() => setQuality(level)}
                      className={`p-4 rounded-xl border-2 transition-all text-center ${
                        quality === level
                          ? 'border-blue-600 bg-blue-50'
                          : 'border-neutral-300 hover:border-blue-400'
                      }`}
                    >
                      <div className="text-2xl mb-1">
                        {level === 'budget' && '💰'}
                        {level === 'mid-range' && '⭐'}
                        {level === 'premium' && '💎'}
                      </div>
                      <div className="text-sm text-neutral-900 capitalize">{level.replace('-', ' ')}</div>
                    </button>
                  ))}
                </div>
                <p className="text-sm text-neutral-600 mt-2 text-center">
                  {getQualityDescription()}
                </p>
              </div>

              {/* Additional Services */}
              <div>
                <label className="block text-neutral-900 mb-3 flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                  </svg>
                  Additional Services
                </label>
                <div className="space-y-3">
                  <label className="flex items-center gap-3 p-4 bg-neutral-50 rounded-xl cursor-pointer hover:bg-neutral-100 transition-colors">
                    <input
                      type="checkbox"
                      checked={includeInstallation}
                      onChange={(e) => setIncludeInstallation(e.target.checked)}
                      className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-600"
                    />
                    <div className="flex-1">
                      <div className="text-neutral-900">Professional Installation</div>
                      <div className="text-sm text-neutral-600">$2-5 per sq ft</div>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-4 bg-neutral-50 rounded-xl cursor-pointer hover:bg-neutral-100 transition-colors">
                    <input
                      type="checkbox"
                      checked={includeRemoval}
                      onChange={(e) => setIncludeRemoval(e.target.checked)}
                      className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-600"
                    />
                    <div className="flex-1">
                      <div className="text-neutral-900">Old Floor Removal</div>
                      <div className="text-sm text-neutral-600">$1-3 per sq ft</div>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-4 bg-neutral-50 rounded-xl cursor-pointer hover:bg-neutral-100 transition-colors">
                    <input
                      type="checkbox"
                      checked={includeSubfloor}
                      onChange={(e) => setIncludeSubfloor(e.target.checked)}
                      className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-600"
                    />
                    <div className="flex-1">
                      <div className="text-neutral-900">Subfloor Preparation</div>
                      <div className="text-sm text-neutral-600">$1-4 per sq ft</div>
                    </div>
                  </label>
                </div>
              </div>
            </div>

            {/* Results Panel */}
            <div className="space-y-6">
              {/* Total Estimate */}
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-8 text-white shadow-xl">
                <h3 className="text-white mb-4 flex items-center gap-2">
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Estimated Total Cost
                </h3>
                <div className="space-y-4">
                  <div>
                    <div className="text-blue-100 text-sm mb-1">Estimated Range</div>
                    <div className="text-4xl md:text-5xl">
                      ${estimate.low.toLocaleString()} - ${estimate.high.toLocaleString()}
                    </div>
                  </div>
                  <div className="border-t border-blue-400 pt-4">
                    <div className="text-blue-100 text-sm mb-1">Most Likely Cost</div>
                    <div className="text-3xl">${estimate.mid.toLocaleString()}</div>
                  </div>
                  <div className="bg-blue-500/30 rounded-lg p-3 text-sm">
                    <div className="flex items-start gap-2">
                      <svg className="w-5 h-5 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span className="text-blue-100">
                        This is an estimate. Actual costs may vary based on your location, specific materials, and contractor rates.
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Cost Breakdown */}
              <div className="bg-white border-2 border-neutral-200 rounded-2xl p-6">
                <h3 className="text-neutral-900 mb-4 flex items-center gap-2">
                  <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                  Cost Breakdown
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between py-3 border-b border-neutral-100">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                      <span className="text-neutral-700">Materials</span>
                    </div>
                    <span className="text-neutral-900">
                      ${estimate.breakdown.material.low.toLocaleString()} - ${estimate.breakdown.material.high.toLocaleString()}
                    </span>
                  </div>

                  {includeInstallation && (
                    <div className="flex items-center justify-between py-3 border-b border-neutral-100">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-green-600 rounded-full"></div>
                        <span className="text-neutral-700">Installation</span>
                      </div>
                      <span className="text-neutral-900">
                        ${estimate.breakdown.installation.low.toLocaleString()} - ${estimate.breakdown.installation.high.toLocaleString()}
                      </span>
                    </div>
                  )}

                  {includeRemoval && (
                    <div className="flex items-center justify-between py-3 border-b border-neutral-100">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-amber-600 rounded-full"></div>
                        <span className="text-neutral-700">Old Floor Removal</span>
                      </div>
                      <span className="text-neutral-900">
                        ${estimate.breakdown.removal.low.toLocaleString()} - ${estimate.breakdown.removal.high.toLocaleString()}
                      </span>
                    </div>
                  )}

                  {includeSubfloor && (
                    <div className="flex items-center justify-between py-3 border-b border-neutral-100">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-purple-600 rounded-full"></div>
                        <span className="text-neutral-700">Subfloor Prep</span>
                      </div>
                      <span className="text-neutral-900">
                        ${estimate.breakdown.subfloor.low.toLocaleString()} - ${estimate.breakdown.subfloor.high.toLocaleString()}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Per Square Foot */}
              <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-6">
                <h4 className="text-green-900 mb-2 flex items-center gap-2">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                  Cost Per Square Foot
                </h4>
                <div className="text-3xl text-green-900 mb-2">
                  ${(estimate.low / squareFootage).toFixed(2)} - ${(estimate.high / squareFootage).toFixed(2)}
                </div>
                <p className="text-sm text-green-700">Per sq ft including selected services</p>
              </div>

              {/* Action Button */}
              {onClose && (
                <button className="w-full py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl hover:shadow-xl transition-all text-lg">
                  Get Accurate Quotes from Pros
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
