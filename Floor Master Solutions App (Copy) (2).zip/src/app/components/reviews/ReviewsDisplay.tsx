import { Review, getAverageRating, getRatingDistribution, getCategoryAverages } from '../../data/reviews';

interface ReviewsDisplayProps {
  reviews: Review[];
  contractorId: string;
  showAllReviews?: boolean;
}

export function ReviewsDisplay({ reviews, contractorId, showAllReviews = false }: ReviewsDisplayProps) {
  const averageRating = getAverageRating(contractorId);
  const distribution = getRatingDistribution(contractorId);
  const categoryAverages = getCategoryAverages(contractorId);
  const totalReviews = reviews.length;
  
  const displayedReviews = showAllReviews ? reviews : reviews.slice(0, 6);

  const StarDisplay = ({ rating, size = 'small' }: { rating: number; size?: 'small' | 'large' }) => {
    const starSize = size === 'large' ? 'w-6 h-6' : 'w-4 h-4';
    
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <svg
            key={star}
            className={`${starSize} ${
              star <= Math.round(rating)
                ? 'text-amber-400 fill-amber-400'
                : 'text-neutral-300'
            }`}
            viewBox="0 0 24 24"
          >
            <path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
          </svg>
        ))}
      </div>
    );
  };

  return (
    <div>
      {/* Overall Rating Summary */}
      <div className="bg-white rounded-2xl shadow-sm p-8 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left: Average Rating */}
          <div className="text-center md:text-left">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div>
                <div className="text-6xl text-neutral-900 mb-2">
                  {averageRating.toFixed(1)}
                </div>
                <StarDisplay rating={averageRating} size="large" />
                <p className="text-neutral-600 mt-2">{totalReviews} reviews</p>
              </div>
            </div>
          </div>

          {/* Right: Rating Distribution */}
          <div className="space-y-2">
            {[5, 4, 3, 2, 1].map((stars) => {
              const count = distribution[stars as keyof typeof distribution];
              const percentage = totalReviews > 0 ? (count / totalReviews) * 100 : 0;
              
              return (
                <div key={stars} className="flex items-center gap-3">
                  <span className="text-sm text-neutral-600 w-8">{stars} ⭐</span>
                  <div className="flex-1 bg-neutral-200 rounded-full h-2">
                    <div
                      className="bg-amber-400 h-2 rounded-full transition-all"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                  <span className="text-sm text-neutral-600 w-12 text-right">{count}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Category Breakdown */}
      <div className="bg-white rounded-2xl shadow-sm p-8 mb-6">
        <h3 className="text-neutral-900 mb-6">Rating Breakdown</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
          {[
            { key: 'quality', label: 'Quality', icon: '⭐' },
            { key: 'punctuality', label: 'Punctuality', icon: '⏰' },
            { key: 'professionalism', label: 'Professional', icon: '👔' },
            { key: 'cleanliness', label: 'Cleanliness', icon: '✨' },
            { key: 'value', label: 'Value', icon: '💰' }
          ].map((category) => (
            <div key={category.key} className="text-center">
              <div className="text-3xl mb-2">{category.icon}</div>
              <div className="text-2xl text-neutral-900 mb-1">
                {categoryAverages[category.key as keyof typeof categoryAverages].toFixed(1)}
              </div>
              <div className="text-sm text-neutral-600">{category.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Individual Reviews */}
      <div className="space-y-6">
        {displayedReviews.map((review) => (
          <div key={review.id} className="bg-white rounded-2xl shadow-sm p-6">
            <div className="flex items-start gap-4">
              {/* Customer Avatar */}
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-amber-600">{review.customerInitials}</span>
              </div>

              <div className="flex-1">
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <h4 className="text-neutral-900">{review.customerName}</h4>
                      {review.verified && (
                        <span className="flex items-center gap-1 text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                          </svg>
                          Verified
                        </span>
                      )}
                      {review.postedToGoogle && (
                        <span className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded-full">
                          Posted to Google
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-neutral-600">{review.jobTitle}</p>
                  </div>
                  <p className="text-sm text-neutral-500">
                    {new Date(review.date).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric'
                    })}
                  </p>
                </div>

                {/* Rating */}
                <div className="mb-3">
                  <StarDisplay rating={review.rating} />
                </div>

                {/* Comment */}
                <p className="text-neutral-700 mb-4">{review.comment}</p>

                {/* Response */}
                {review.response && (
                  <div className="bg-neutral-50 rounded-xl p-4 border-l-4 border-amber-600">
                    <div className="flex items-center gap-2 mb-2">
                      <svg className="w-4 h-4 text-neutral-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
                      </svg>
                      <span className="text-sm text-neutral-900">Response from contractor</span>
                      <span className="text-xs text-neutral-500">
                        {new Date(review.response.date).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric'
                        })}
                      </span>
                    </div>
                    <p className="text-neutral-700 text-sm">{review.response.text}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Show More Button */}
      {!showAllReviews && reviews.length > 6 && (
        <div className="text-center mt-6">
          <button className="px-6 py-3 border border-neutral-200 rounded-xl hover:bg-neutral-50 transition-colors">
            View All {reviews.length} Reviews
          </button>
        </div>
      )}
    </div>
  );
}
