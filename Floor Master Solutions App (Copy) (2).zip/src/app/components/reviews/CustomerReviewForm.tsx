import { useState } from 'react';

interface CustomerReviewFormProps {
  jobTitle: string;
  contractorName: string;
  onSubmit: (reviewData: ReviewSubmission) => void;
}

export interface ReviewSubmission {
  rating: number;
  comment: string;
  categories: {
    quality: number;
    punctuality: number;
    professionalism: number;
    cleanliness: number;
    value: number;
  };
  postToGoogle: boolean;
}

export function CustomerReviewForm({ jobTitle, contractorName, onSubmit }: CustomerReviewFormProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [overallRating, setOverallRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState('');
  const [categories, setCategories] = useState({
    quality: 0,
    punctuality: 0,
    professionalism: 0,
    cleanliness: 0,
    value: 0
  });
  const [postToGoogle, setPostToGoogle] = useState(true);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    onSubmit({
      rating: overallRating,
      comment,
      categories,
      postToGoogle
    });
    setSubmitted(true);
  };

  const StarRating = ({ 
    rating, 
    onRate, 
    size = 'large' 
  }: { 
    rating: number; 
    onRate: (rating: number) => void;
    size?: 'small' | 'large';
  }) => {
    const [hovered, setHovered] = useState(0);
    const starSize = size === 'large' ? 'w-12 h-12' : 'w-8 h-8';

    return (
      <div className="flex gap-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onRate(star)}
            onMouseEnter={() => setHovered(star)}
            onMouseLeave={() => setHovered(0)}
            className="transition-transform hover:scale-110"
          >
            <svg
              className={`${starSize} ${
                star <= (hovered || rating)
                  ? 'text-amber-400 fill-amber-400'
                  : 'text-neutral-300'
              }`}
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={1}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
              />
            </svg>
          </button>
        ))}
      </div>
    );
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center p-6">
        <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-neutral-900 mb-3">Thank You!</h2>
          <p className="text-neutral-600 mb-6">
            Your review has been submitted successfully. It will help other homeowners find great contractors!
          </p>
          {postToGoogle && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
              <div className="flex items-start gap-3">
                <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-sm text-blue-900">
                  Your review will also be posted to Google to help {contractorName}'s public profile.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50 py-12 px-6">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-sm p-8 mb-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 bg-amber-600 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">FM</span>
            </div>
            <div>
              <h1 className="text-neutral-900 mb-1">Rate Your Experience</h1>
              <p className="text-neutral-600">{contractorName}</p>
            </div>
          </div>

          {/* Progress Indicator */}
          <div className="flex items-center gap-2 mb-8">
            <div className={`flex-1 h-2 rounded-full ${currentStep >= 1 ? 'bg-amber-600' : 'bg-neutral-200'}`} />
            <div className={`flex-1 h-2 rounded-full ${currentStep >= 2 ? 'bg-amber-600' : 'bg-neutral-200'}`} />
            <div className={`flex-1 h-2 rounded-full ${currentStep >= 3 ? 'bg-amber-600' : 'bg-neutral-200'}`} />
          </div>

          <div className="bg-neutral-50 rounded-xl p-4">
            <p className="text-neutral-600 text-sm mb-1">Completed Job</p>
            <p className="text-neutral-900">{jobTitle}</p>
          </div>
        </div>

        {/* Step 1: Overall Rating */}
        {currentStep === 1 && (
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <h2 className="text-neutral-900 mb-2 text-center">How was your overall experience?</h2>
            <p className="text-neutral-600 text-center mb-8">
              Your feedback helps other homeowners make informed decisions
            </p>

            <div className="flex flex-col items-center mb-8">
              <StarRating rating={overallRating} onRate={setOverallRating} />
              {overallRating > 0 && (
                <p className="mt-4 text-lg text-amber-600">
                  {overallRating === 5 && 'Excellent!'}
                  {overallRating === 4 && 'Great!'}
                  {overallRating === 3 && 'Good'}
                  {overallRating === 2 && 'Fair'}
                  {overallRating === 1 && 'Poor'}
                </p>
              )}
            </div>

            <button
              onClick={() => setCurrentStep(2)}
              disabled={overallRating === 0}
              className="w-full bg-amber-600 text-white py-4 rounded-xl hover:bg-amber-700 transition-colors disabled:bg-neutral-300 disabled:cursor-not-allowed"
            >
              Continue
            </button>
          </div>
        )}

        {/* Step 2: Detailed Ratings */}
        {currentStep === 2 && (
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <h2 className="text-neutral-900 mb-2 text-center">Rate specific aspects</h2>
            <p className="text-neutral-600 text-center mb-8">
              Help us understand what they did well
            </p>

            <div className="space-y-6 mb-8">
              {[
                { key: 'quality', label: 'Work Quality', icon: '⭐' },
                { key: 'punctuality', label: 'Punctuality', icon: '⏰' },
                { key: 'professionalism', label: 'Professionalism', icon: '👔' },
                { key: 'cleanliness', label: 'Cleanliness', icon: '✨' },
                { key: 'value', label: 'Value for Money', icon: '💰' }
              ].map((category) => (
                <div key={category.key} className="border-b border-neutral-100 pb-6 last:border-0">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{category.icon}</span>
                      <span className="text-neutral-900">{category.label}</span>
                    </div>
                    <span className="text-amber-600">
                      {categories[category.key as keyof typeof categories] || 0}/5
                    </span>
                  </div>
                  <StarRating
                    rating={categories[category.key as keyof typeof categories]}
                    onRate={(rating) => setCategories({ ...categories, [category.key]: rating })}
                    size="small"
                  />
                </div>
              ))}
            </div>

            <div className="flex gap-4">
              <button
                onClick={() => setCurrentStep(1)}
                className="flex-1 border border-neutral-200 py-4 rounded-xl hover:bg-neutral-50 transition-colors"
              >
                Back
              </button>
              <button
                onClick={() => setCurrentStep(3)}
                disabled={Object.values(categories).some(v => v === 0)}
                className="flex-1 bg-amber-600 text-white py-4 rounded-xl hover:bg-amber-700 transition-colors disabled:bg-neutral-300 disabled:cursor-not-allowed"
              >
                Continue
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Written Review */}
        {currentStep === 3 && (
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <h2 className="text-neutral-900 mb-2 text-center">Share your experience</h2>
            <p className="text-neutral-600 text-center mb-8">
              Write a few words about your experience (optional but helpful)
            </p>

            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="w-full border border-neutral-200 rounded-xl p-4 min-h-[150px] focus:outline-none focus:ring-2 focus:ring-amber-600 mb-6"
              placeholder="What did you like most about working with this contractor? Any details that would help other homeowners?"
            />

            <div className="bg-neutral-50 rounded-xl p-4 mb-6">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={postToGoogle}
                  onChange={(e) => setPostToGoogle(e.target.checked)}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div>
                  <p className="text-neutral-900 mb-1">Also post to Google</p>
                  <p className="text-neutral-600 text-sm">
                    Help {contractorName} build their public reputation and assist more homeowners in finding quality contractors
                  </p>
                </div>
              </label>
            </div>

            <div className="flex gap-4">
              <button
                onClick={() => setCurrentStep(2)}
                className="flex-1 border border-neutral-200 py-4 rounded-xl hover:bg-neutral-50 transition-colors"
              >
                Back
              </button>
              <button
                onClick={handleSubmit}
                className="flex-1 bg-amber-600 text-white py-4 rounded-xl hover:bg-amber-700 transition-colors"
              >
                Submit Review
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
