import { useState } from 'react';
import { Upload, CheckCircle, AlertCircle, Shield, FileText, Award, Users, Camera } from 'lucide-react';

interface OnboardingStep {
  id: number;
  title: string;
  description: string;
  completed: boolean;
}

export function ContractorOnboarding({ onComplete }: { onComplete: () => void }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [verificationStatus, setVerificationStatus] = useState<'pending' | 'reviewing' | 'approved' | 'rejected'>('pending');
  
  // Form data states
  const [businessInfo, setBusinessInfo] = useState({
    businessName: '',
    businessType: 'llc',
    yearsInBusiness: '',
    ein: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    phone: '',
    website: '',
  });

  const [credentials, setCredentials] = useState({
    licenseNumber: '',
    licenseState: '',
    licenseExpiration: '',
    insuranceProvider: '',
    insurancePolicyNumber: '',
    insuranceExpiration: '',
    bondAmount: '',
    bondProvider: '',
  });

  const [certifications, setCertifications] = useState({
    nwfa: false, // National Wood Flooring Association
    cfI: false, // Certified Floorcovering Installers
    osha: false, // OSHA Safety Certification
    epa: false, // EPA Lead-Safe Certification
    other: [] as string[],
  });

  const [specialties, setSpecialties] = useState<string[]>([]);
  const [references, setReferences] = useState([
    { name: '', company: '', phone: '', email: '', relationship: '' },
    { name: '', company: '', phone: '', email: '', relationship: '' },
    { name: '', company: '', phone: '', email: '', relationship: '' },
  ]);

  const [documents, setDocuments] = useState({
    license: null as File | null,
    insurance: null as File | null,
    bond: null as File | null,
    certifications: [] as File[],
    workExamples: [] as File[],
  });

  const [backgroundCheck, setBackgroundCheck] = useState({
    agreedToCheck: false,
    noCriminalRecord: false,
    noFraud: false,
    validDriversLicense: false,
  });

  const [safetyCompliance, setSafetyCompliance] = useState({
    oshaCompliant: false,
    workersCompInsurance: false,
    safetyTraining: false,
    equipmentMaintenance: false,
    emergencyProcedures: false,
  });

  const steps: OnboardingStep[] = [
    {
      id: 1,
      title: 'Business Information',
      description: 'Tell us about your company',
      completed: false,
    },
    {
      id: 2,
      title: 'Credentials & Licensing',
      description: 'Verify your professional licenses',
      completed: false,
    },
    {
      id: 3,
      title: 'Certifications',
      description: 'Show your industry certifications',
      completed: false,
    },
    {
      id: 4,
      title: 'Insurance & Bonding',
      description: 'Prove your insurance coverage',
      completed: false,
    },
    {
      id: 5,
      title: 'Safety & Compliance',
      description: 'Confirm safety standards',
      completed: false,
    },
    {
      id: 6,
      title: 'References',
      description: 'Provide professional references',
      completed: false,
    },
    {
      id: 7,
      title: 'Background Check',
      description: 'Complete verification process',
      completed: false,
    },
    {
      id: 8,
      title: 'Portfolio & Examples',
      description: 'Upload your best work',
      completed: false,
    },
  ];

  const allSpecialties = [
    'Hardwood Installation',
    'Hardwood Refinishing',
    'Engineered Wood',
    'Luxury Vinyl Plank (LVP)',
    'Carpet Installation',
    'Tile Installation',
    'Laminate Flooring',
    'Epoxy Flooring',
    'Floor Repair',
    'Subfloor Work',
    'Commercial Projects',
    'Residential Projects',
  ];

  const toggleSpecialty = (specialty: string) => {
    if (specialties.includes(specialty)) {
      setSpecialties(specialties.filter(s => s !== specialty));
    } else {
      setSpecialties([...specialties, specialty]);
    }
  };

  const handleFileUpload = (category: keyof typeof documents, file: File) => {
    if (category === 'certifications' || category === 'workExamples') {
      setDocuments({
        ...documents,
        [category]: [...documents[category], file],
      });
    } else {
      setDocuments({
        ...documents,
        [category]: file,
      });
    }
  };

  const handleSubmitForReview = () => {
    setVerificationStatus('reviewing');
    // Simulate verification process
    setTimeout(() => {
      setVerificationStatus('approved');
    }, 3000);
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-blue-900">
                  <p className="mb-2">We verify all contractor information to ensure homeowner safety. All fields are required unless marked optional.</p>
                  <p>Your information is secure and will only be shared with homeowners you choose to work with.</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="text-sm text-neutral-700 mb-2 block">Business Name *</label>
                <input
                  type="text"
                  value={businessInfo.businessName}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, businessName: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  placeholder="ABC Flooring Solutions LLC"
                />
              </div>

              <div>
                <label className="text-sm text-neutral-700 mb-2 block">Business Type *</label>
                <select
                  value={businessInfo.businessType}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, businessType: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                >
                  <option value="llc">LLC</option>
                  <option value="corporation">Corporation</option>
                  <option value="sole-proprietor">Sole Proprietor</option>
                  <option value="partnership">Partnership</option>
                </select>
              </div>

              <div>
                <label className="text-sm text-neutral-700 mb-2 block">Years in Business *</label>
                <input
                  type="number"
                  value={businessInfo.yearsInBusiness}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, yearsInBusiness: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  placeholder="10"
                />
              </div>

              <div>
                <label className="text-sm text-neutral-700 mb-2 block">EIN (Tax ID) *</label>
                <input
                  type="text"
                  value={businessInfo.ein}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, ein: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  placeholder="XX-XXXXXXX"
                />
              </div>

              <div>
                <label className="text-sm text-neutral-700 mb-2 block">Phone Number *</label>
                <input
                  type="tel"
                  value={businessInfo.phone}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, phone: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  placeholder="(555) 123-4567"
                />
              </div>

              <div className="md:col-span-2">
                <label className="text-sm text-neutral-700 mb-2 block">Business Address *</label>
                <input
                  type="text"
                  value={businessInfo.address}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, address: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  placeholder="123 Main Street"
                />
              </div>

              <div>
                <label className="text-sm text-neutral-700 mb-2 block">City *</label>
                <input
                  type="text"
                  value={businessInfo.city}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, city: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  placeholder="New York"
                />
              </div>

              <div>
                <label className="text-sm text-neutral-700 mb-2 block">State *</label>
                <input
                  type="text"
                  value={businessInfo.state}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, state: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  placeholder="NY"
                />
              </div>

              <div>
                <label className="text-sm text-neutral-700 mb-2 block">ZIP Code *</label>
                <input
                  type="text"
                  value={businessInfo.zipCode}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, zipCode: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  placeholder="10001"
                />
              </div>

              <div>
                <label className="text-sm text-neutral-700 mb-2 block">Website (Optional)</label>
                <input
                  type="url"
                  value={businessInfo.website}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, website: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  placeholder="www.yourcompany.com"
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-amber-900">
                  <p className="mb-2">Professional licensing is required to work on the Floor Master Solutions platform.</p>
                  <p>We verify all licenses with state licensing boards to ensure compliance and homeowner protection.</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-neutral-700 mb-2 block">Contractor License Number *</label>
                <input
                  type="text"
                  value={credentials.licenseNumber}
                  onChange={(e) => setCredentials({ ...credentials, licenseNumber: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  placeholder="License #"
                />
              </div>

              <div>
                <label className="text-sm text-neutral-700 mb-2 block">License State *</label>
                <input
                  type="text"
                  value={credentials.licenseState}
                  onChange={(e) => setCredentials({ ...credentials, licenseState: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  placeholder="NY"
                />
              </div>

              <div>
                <label className="text-sm text-neutral-700 mb-2 block">License Expiration Date *</label>
                <input
                  type="date"
                  value={credentials.licenseExpiration}
                  onChange={(e) => setCredentials({ ...credentials, licenseExpiration: e.target.value })}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                />
              </div>

              <div>
                <label className="text-sm text-neutral-700 mb-2 block">Upload License Copy *</label>
                <label className="w-full border-2 border-dashed border-neutral-300 rounded-lg p-4 flex flex-col items-center justify-center cursor-pointer hover:border-amber-600 transition-colors">
                  <Upload className="w-8 h-8 text-neutral-400 mb-2" />
                  <span className="text-sm text-neutral-600">
                    {documents.license ? documents.license.name : 'Click to upload'}
                  </span>
                  <input
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png"
                    onChange={(e) => e.target.files?.[0] && handleFileUpload('license', e.target.files[0])}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div className="bg-neutral-50 rounded-xl p-4 mt-6">
              <h4 className="text-neutral-900 mb-3 flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-600" />
                Specialties & Expertise
              </h4>
              <p className="text-sm text-neutral-600 mb-4">Select all flooring types you're licensed and experienced to install:</p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {allSpecialties.map((specialty) => (
                  <label
                    key={specialty}
                    className={`flex items-center gap-2 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                      specialties.includes(specialty)
                        ? 'border-amber-600 bg-amber-50'
                        : 'border-neutral-200 hover:border-neutral-300'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={specialties.includes(specialty)}
                      onChange={() => toggleSpecialty(specialty)}
                      className="w-4 h-4 text-amber-600 rounded"
                    />
                    <span className="text-sm text-neutral-900">{specialty}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="bg-green-50 border border-green-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Award className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-green-900">
                  <p className="mb-2">Industry certifications demonstrate your commitment to quality and professionalism.</p>
                  <p>While not all certifications are required, they help you stand out to potential clients.</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-neutral-900">Select Your Certifications</h4>
              
              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={certifications.nwfa}
                  onChange={(e) => setCertifications({ ...certifications, nwfa: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">NWFA Certified Installer</p>
                  <p className="text-sm text-neutral-600">National Wood Flooring Association certification for hardwood installation</p>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={certifications.cfI}
                  onChange={(e) => setCertifications({ ...certifications, cfI: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">CFI Certified</p>
                  <p className="text-sm text-neutral-600">Certified Floorcovering Installers Association certification</p>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={certifications.osha}
                  onChange={(e) => setCertifications({ ...certifications, osha: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">OSHA Safety Certified *</p>
                  <p className="text-sm text-neutral-600">OSHA 10 or 30-hour construction safety certification (Required)</p>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={certifications.epa}
                  onChange={(e) => setCertifications({ ...certifications, epa: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">EPA Lead-Safe Certified *</p>
                  <p className="text-sm text-neutral-600">EPA RRP (Renovation, Repair, and Painting) certification (Required for pre-1978 homes)</p>
                </div>
              </label>

              <div className="mt-4">
                <label className="text-sm text-neutral-700 mb-2 block">Upload Certification Documents</label>
                <label className="w-full border-2 border-dashed border-neutral-300 rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:border-amber-600 transition-colors">
                  <Upload className="w-10 h-10 text-neutral-400 mb-2" />
                  <span className="text-sm text-neutral-600 text-center">
                    {documents.certifications.length > 0
                      ? `${documents.certifications.length} file(s) uploaded`
                      : 'Click to upload certification documents'}
                  </span>
                  <span className="text-xs text-neutral-500 mt-1">PDF, JPG, or PNG (max 10MB each)</span>
                  <input
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png"
                    multiple
                    onChange={(e) => {
                      Array.from(e.target.files || []).forEach(file => handleFileUpload('certifications', file));
                    }}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="bg-red-50 border border-red-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-red-900">
                  <p className="mb-2"><strong>Insurance is mandatory</strong> to protect both you and homeowners.</p>
                  <p>We verify all insurance policies directly with providers. Expired or insufficient coverage will result in account suspension.</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-neutral-900">General Liability Insurance *</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-neutral-700 mb-2 block">Insurance Provider</label>
                  <input
                    type="text"
                    value={credentials.insuranceProvider}
                    onChange={(e) => setCredentials({ ...credentials, insuranceProvider: e.target.value })}
                    className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                    placeholder="State Farm, Allstate, etc."
                  />
                </div>

                <div>
                  <label className="text-sm text-neutral-700 mb-2 block">Policy Number</label>
                  <input
                    type="text"
                    value={credentials.insurancePolicyNumber}
                    onChange={(e) => setCredentials({ ...credentials, insurancePolicyNumber: e.target.value })}
                    className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                    placeholder="Policy #"
                  />
                </div>

                <div>
                  <label className="text-sm text-neutral-700 mb-2 block">Expiration Date</label>
                  <input
                    type="date"
                    value={credentials.insuranceExpiration}
                    onChange={(e) => setCredentials({ ...credentials, insuranceExpiration: e.target.value })}
                    className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  />
                </div>

                <div>
                  <label className="text-sm text-neutral-700 mb-2 block">Coverage Amount (Minimum $1M)</label>
                  <input
                    type="text"
                    className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                    placeholder="$1,000,000"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="text-sm text-neutral-700 mb-2 block">Upload Insurance Certificate *</label>
                  <label className="w-full border-2 border-dashed border-neutral-300 rounded-lg p-4 flex flex-col items-center justify-center cursor-pointer hover:border-amber-600 transition-colors">
                    <Upload className="w-8 h-8 text-neutral-400 mb-2" />
                    <span className="text-sm text-neutral-600">
                      {documents.insurance ? documents.insurance.name : 'Click to upload insurance certificate'}
                    </span>
                    <input
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) => e.target.files?.[0] && handleFileUpload('insurance', e.target.files[0])}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-neutral-200">
              <h4 className="text-neutral-900">Surety Bond (Optional but Recommended)</h4>
              <p className="text-sm text-neutral-600">A surety bond provides additional financial protection for homeowners.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-neutral-700 mb-2 block">Bond Provider</label>
                  <input
                    type="text"
                    value={credentials.bondProvider}
                    onChange={(e) => setCredentials({ ...credentials, bondProvider: e.target.value })}
                    className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                    placeholder="Bond Company Name"
                  />
                </div>

                <div>
                  <label className="text-sm text-neutral-700 mb-2 block">Bond Amount</label>
                  <input
                    type="text"
                    value={credentials.bondAmount}
                    onChange={(e) => setCredentials({ ...credentials, bondAmount: e.target.value })}
                    className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                    placeholder="$50,000"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="text-sm text-neutral-700 mb-2 block">Upload Bond Certificate (Optional)</label>
                  <label className="w-full border-2 border-dashed border-neutral-300 rounded-lg p-4 flex flex-col items-center justify-center cursor-pointer hover:border-amber-600 transition-colors">
                    <Upload className="w-8 h-8 text-neutral-400 mb-2" />
                    <span className="text-sm text-neutral-600">
                      {documents.bond ? documents.bond.name : 'Click to upload bond certificate'}
                    </span>
                    <input
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) => e.target.files?.[0] && handleFileUpload('bond', e.target.files[0])}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <div className="bg-orange-50 border border-orange-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-orange-900">
                  <p className="mb-2">Safety is our top priority. All contractors must meet safety standards to protect workers and homeowners.</p>
                  <p>We conduct periodic safety audits and require updated documentation annually.</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-neutral-900">Safety & Compliance Requirements</h4>

              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={safetyCompliance.oshaCompliant}
                  onChange={(e) => setSafetyCompliance({ ...safetyCompliance, oshaCompliant: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">OSHA Compliance *</p>
                  <p className="text-sm text-neutral-600">I confirm my company follows all OSHA safety regulations and maintains required safety equipment.</p>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={safetyCompliance.workersCompInsurance}
                  onChange={(e) => setSafetyCompliance({ ...safetyCompliance, workersCompInsurance: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">Workers' Compensation Insurance *</p>
                  <p className="text-sm text-neutral-600">I maintain current workers' compensation insurance for all employees (or provide proof of exemption if sole proprietor).</p>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={safetyCompliance.safetyTraining}
                  onChange={(e) => setSafetyCompliance({ ...safetyCompliance, safetyTraining: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">Safety Training Program *</p>
                  <p className="text-sm text-neutral-600">All employees receive regular safety training including proper equipment use, hazard identification, and emergency procedures.</p>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={safetyCompliance.equipmentMaintenance}
                  onChange={(e) => setSafetyCompliance({ ...safetyCompliance, equipmentMaintenance: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">Equipment Maintenance *</p>
                  <p className="text-sm text-neutral-600">All tools and equipment are regularly inspected and maintained in safe working condition.</p>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={safetyCompliance.emergencyProcedures}
                  onChange={(e) => setSafetyCompliance({ ...safetyCompliance, emergencyProcedures: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">Emergency Procedures *</p>
                  <p className="text-sm text-neutral-600">My team is trained in emergency response procedures and carries first aid supplies on all job sites.</p>
                </div>
              </label>
            </div>

            <div className="bg-neutral-50 rounded-xl p-4">
              <h4 className="text-neutral-900 mb-3">COVID-19 & Health Safety</h4>
              <div className="space-y-2 text-sm text-neutral-700">
                <p>✓ Follow current CDC guidelines for construction sites</p>
                <p>✓ Provide personal protective equipment (PPE) for all workers</p>
                <p>✓ Maintain clean and sanitized work areas</p>
                <p>✓ Respect homeowner health and safety preferences</p>
              </div>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="space-y-6">
            <div className="bg-purple-50 border border-purple-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Users className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-purple-900">
                  <p className="mb-2">Professional references help us verify your work quality and reliability.</p>
                  <p>Provide at least 3 references from recent clients or industry professionals who can vouch for your work.</p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <h4 className="text-neutral-900">Professional References (Minimum 3 Required)</h4>
              
              {references.map((ref, index) => (
                <div key={index} className="bg-neutral-50 rounded-xl p-4 space-y-3">
                  <h5 className="text-neutral-900">Reference {index + 1}</h5>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="text-sm text-neutral-700 mb-1 block">Full Name *</label>
                      <input
                        type="text"
                        value={ref.name}
                        onChange={(e) => {
                          const newRefs = [...references];
                          newRefs[index].name = e.target.value;
                          setReferences(newRefs);
                        }}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                        placeholder="John Smith"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-neutral-700 mb-1 block">Company/Organization</label>
                      <input
                        type="text"
                        value={ref.company}
                        onChange={(e) => {
                          const newRefs = [...references];
                          newRefs[index].company = e.target.value;
                          setReferences(newRefs);
                        }}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                        placeholder="ABC Company"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-neutral-700 mb-1 block">Phone Number *</label>
                      <input
                        type="tel"
                        value={ref.phone}
                        onChange={(e) => {
                          const newRefs = [...references];
                          newRefs[index].phone = e.target.value;
                          setReferences(newRefs);
                        }}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                        placeholder="(555) 123-4567"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-neutral-700 mb-1 block">Email *</label>
                      <input
                        type="email"
                        value={ref.email}
                        onChange={(e) => {
                          const newRefs = [...references];
                          newRefs[index].email = e.target.value;
                          setReferences(newRefs);
                        }}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                        placeholder="john@example.com"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="text-sm text-neutral-700 mb-1 block">Relationship *</label>
                      <select
                        value={ref.relationship}
                        onChange={(e) => {
                          const newRefs = [...references];
                          newRefs[index].relationship = e.target.value;
                          setReferences(newRefs);
                        }}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                      >
                        <option value="">Select relationship</option>
                        <option value="client">Past Client</option>
                        <option value="supplier">Supplier/Vendor</option>
                        <option value="contractor">Fellow Contractor</option>
                        <option value="architect">Architect/Designer</option>
                        <option value="other">Other Professional</option>
                      </select>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-neutral-50 rounded-xl p-4">
              <p className="text-sm text-neutral-700">
                <strong>Note:</strong> We will contact your references to verify your work quality, professionalism, and reliability. Please ensure your references are aware they may be contacted.
              </p>
            </div>
          </div>
        );

      case 7:
        return (
          <div className="space-y-6">
            <div className="bg-red-50 border border-red-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-red-900">
                  <p className="mb-2"><strong>Background verification is required</strong> for all contractors on Floor Master Solutions.</p>
                  <p>This protects homeowners and maintains the integrity of our platform. All information is kept confidential.</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-neutral-900">Background Check Consent & Verification</h4>

              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={backgroundCheck.agreedToCheck}
                  onChange={(e) => setBackgroundCheck({ ...backgroundCheck, agreedToCheck: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">Background Check Authorization *</p>
                  <p className="text-sm text-neutral-600">
                    I authorize Floor Master Solutions to conduct a comprehensive background check including criminal records, 
                    credit history, and verification of all information provided in this application.
                  </p>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={backgroundCheck.noCriminalRecord}
                  onChange={(e) => setBackgroundCheck({ ...backgroundCheck, noCriminalRecord: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">Criminal Record Disclosure *</p>
                  <p className="text-sm text-neutral-600">
                    I certify that I have no felony convictions or misdemeanors related to fraud, theft, 
                    or crimes against persons that would disqualify me from working in customers' homes.
                  </p>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={backgroundCheck.noFraud}
                  onChange={(e) => setBackgroundCheck({ ...backgroundCheck, noFraud: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">No Fraudulent Activity *</p>
                  <p className="text-sm text-neutral-600">
                    I have never been involved in fraudulent contracting activities, bankruptcy fraud, 
                    or had my contractor's license suspended or revoked.
                  </p>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 rounded-xl border-2 border-neutral-200 cursor-pointer hover:border-amber-600 transition-colors">
                <input
                  type="checkbox"
                  checked={backgroundCheck.validDriversLicense}
                  onChange={(e) => setBackgroundCheck({ ...backgroundCheck, validDriversLicense: e.target.checked })}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div className="flex-1">
                  <p className="text-neutral-900 mb-1">Valid Driver's License *</p>
                  <p className="text-sm text-neutral-600">
                    I possess a valid driver's license with no serious violations (DUI, reckless driving) in the past 5 years.
                  </p>
                </div>
              </label>
            </div>

            <div className="bg-neutral-50 rounded-xl p-4">
              <h4 className="text-neutral-900 mb-3">What We Verify</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-neutral-700">
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Criminal background check (7 years)</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Sex offender registry check</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>License verification with state boards</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Insurance verification</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Business registration verification</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Professional reference checks</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>BBB and complaint database review</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Court records and liens check</span>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
              <p className="text-sm text-blue-900">
                <strong>Processing Time:</strong> Background checks typically take 3-5 business days. 
                You'll receive an email notification once your verification is complete.
              </p>
            </div>
          </div>
        );

      case 8:
        return (
          <div className="space-y-6">
            <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Camera className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-indigo-900">
                  <p className="mb-2">Showcase your best work to attract more clients!</p>
                  <p>High-quality photos of completed projects help homeowners visualize what you can do for them.</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-neutral-900">Upload Your Portfolio</h4>
              <p className="text-sm text-neutral-600">Upload 5-15 photos of your best completed flooring projects. Include before/after shots when possible.</p>

              <label className="w-full border-2 border-dashed border-neutral-300 rounded-lg p-8 flex flex-col items-center justify-center cursor-pointer hover:border-amber-600 transition-colors">
                <Camera className="w-12 h-12 text-neutral-400 mb-3" />
                <span className="text-neutral-900 mb-1">
                  {documents.workExamples.length > 0
                    ? `${documents.workExamples.length} photo(s) uploaded`
                    : 'Click to upload project photos'}
                </span>
                <span className="text-sm text-neutral-600 text-center">
                  JPG or PNG (max 10MB each, minimum 5 photos)
                </span>
                <input
                  type="file"
                  accept=".jpg,.jpeg,.png"
                  multiple
                  onChange={(e) => {
                    Array.from(e.target.files || []).forEach(file => handleFileUpload('workExamples', file));
                  }}
                  className="hidden"
                />
              </label>

              {documents.workExamples.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {documents.workExamples.map((file, index) => (
                    <div key={index} className="aspect-square bg-neutral-100 rounded-lg flex items-center justify-center">
                      <div className="text-center p-3">
                        <Camera className="w-6 h-6 text-neutral-400 mx-auto mb-2" />
                        <p className="text-xs text-neutral-600 truncate">{file.name}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-neutral-50 rounded-xl p-4">
              <h4 className="text-neutral-900 mb-3">Photo Tips</h4>
              <ul className="space-y-2 text-sm text-neutral-700">
                <li className="flex items-start gap-2">
                  <span className="text-amber-600">•</span>
                  <span>Use good lighting - natural daylight works best</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-600">•</span>
                  <span>Show wide shots of entire rooms and close-ups of details</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-600">•</span>
                  <span>Include before/after comparisons when available</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-600">•</span>
                  <span>Ensure floors are clean and fully finished</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-600">•</span>
                  <span>Showcase different flooring types and styles you offer</span>
                </li>
              </ul>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  if (verificationStatus === 'reviewing') {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center p-6">
        <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8 text-center">
          <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
            <Shield className="w-10 h-10 text-amber-600" />
          </div>
          <h2 className="text-neutral-900 mb-3">Verifying Your Application</h2>
          <p className="text-neutral-600 mb-6">
            Please wait while we review your information and verify your credentials...
          </p>
          <div className="flex justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-600"></div>
          </div>
        </div>
      </div>
    );
  }

  if (verificationStatus === 'approved') {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center p-6">
        <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-neutral-900 mb-3">Welcome to Floor Master Solutions!</h2>
          <p className="text-neutral-600 mb-6">
            Your application has been approved. You can now start receiving project requests from homeowners.
          </p>
          <button
            onClick={onComplete}
            className="w-full bg-amber-600 text-white py-3 rounded-xl hover:bg-amber-700 transition-colors"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-neutral-900 mb-2">Contractor Verification & Onboarding</h1>
          <p className="text-neutral-600">
            Complete all steps to join Floor Master Solutions and start connecting with homeowners
          </p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4 overflow-x-auto pb-4">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center flex-shrink-0">
                <div className="flex flex-col items-center">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                      currentStep === step.id
                        ? 'bg-amber-600 text-white ring-4 ring-amber-100'
                        : currentStep > step.id
                        ? 'bg-green-600 text-white'
                        : 'bg-neutral-200 text-neutral-600'
                    }`}
                  >
                    {currentStep > step.id ? (
                      <CheckCircle className="w-5 h-5" />
                    ) : (
                      <span>{step.id}</span>
                    )}
                  </div>
                  <div className="mt-2 text-center hidden md:block">
                    <p className="text-xs text-neutral-900 max-w-[100px]">{step.title}</p>
                  </div>
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-12 h-1 mx-2 ${currentStep > step.id ? 'bg-green-600' : 'bg-neutral-200'}`} />
                )}
              </div>
            ))}
          </div>
          
          {/* Mobile step title */}
          <div className="md:hidden text-center">
            <p className="text-neutral-900">{steps[currentStep - 1].title}</p>
            <p className="text-sm text-neutral-600">{steps[currentStep - 1].description}</p>
          </div>
        </div>

        {/* Step Content */}
        <div className="bg-white rounded-2xl shadow-sm p-6 md:p-8 mb-6">
          <div className="hidden md:block mb-6">
            <h2 className="text-neutral-900 mb-2">{steps[currentStep - 1].title}</h2>
            <p className="text-neutral-600">{steps[currentStep - 1].description}</p>
          </div>
          {renderStepContent()}
        </div>

        {/* Navigation */}
        <div className="flex justify-between gap-4">
          <button
            onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
            disabled={currentStep === 1}
            className="px-6 py-3 bg-neutral-100 text-neutral-900 rounded-xl hover:bg-neutral-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>
          
          {currentStep < steps.length ? (
            <button
              onClick={() => setCurrentStep(Math.min(steps.length, currentStep + 1))}
              className="px-6 py-3 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors"
            >
              Next Step
            </button>
          ) : (
            <button
              onClick={handleSubmitForReview}
              className="px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors flex items-center gap-2"
            >
              <Shield className="w-5 h-5" />
              Submit for Verification
            </button>
          )}
        </div>

        {/* Help Section */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
          <h3 className="text-neutral-900 mb-3">Need Help?</h3>
          <p className="text-sm text-neutral-700 mb-4">
            If you have questions about the verification process or need assistance completing any step, 
            our support team is here to help.
          </p>
          <div className="flex flex-wrap gap-4">
            <a href="mailto:support@floormaster.com" className="text-sm text-amber-600 hover:text-amber-700">
              Email Support
            </a>
            <a href="tel:1-800-555-0123" className="text-sm text-amber-600 hover:text-amber-700">
              Call: 1-800-555-0123
            </a>
            <a href="#" className="text-sm text-amber-600 hover:text-amber-700">
              View FAQ
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
