import { useState } from 'react';
import { floorProjects, getProjectsSharedWithContractor, getProjectsLookingForContractors, FloorProject } from '../../data/floorProjects';

export function DesignRequests() {
  const [selectedTab, setSelectedTab] = useState<'sent-to-me' | 'marketplace'>('sent-to-me');
  const [selectedProject, setSelectedProject] = useState<FloorProject | null>(null);
  const [showQuoteModal, setShowQuoteModal] = useState(false);

  const contractorId = 'contractor-1';
  const sentToMe = getProjectsSharedWithContractor(contractorId);
  const marketplace = getProjectsLookingForContractors();

  const displayProjects = selectedTab === 'sent-to-me' ? sentToMe : marketplace;

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-neutral-900 mb-2">Design Requests</h1>
          <p className="text-neutral-600">
            View customer floor designs with photos and specifications
          </p>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-2xl shadow-sm mb-6">
          <div className="flex border-b border-neutral-200">
            <button
              onClick={() => setSelectedTab('sent-to-me')}
              className={`flex-1 py-4 px-6 transition-colors ${
                selectedTab === 'sent-to-me'
                  ? 'border-b-2 border-amber-600 text-amber-600'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <div className="flex items-center justify-center gap-2">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                <span>Sent to Me ({sentToMe.length})</span>
              </div>
            </button>
            <button
              onClick={() => setSelectedTab('marketplace')}
              className={`flex-1 py-4 px-6 transition-colors ${
                selectedTab === 'marketplace'
                  ? 'border-b-2 border-amber-600 text-amber-600'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <div className="flex items-center justify-center gap-2">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <span>Find Projects ({marketplace.length})</span>
              </div>
            </button>
          </div>
        </div>

        {/* Info Banner */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
          <div className="flex items-start gap-3">
            <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-sm text-blue-900">
              {selectedTab === 'sent-to-me' 
                ? 'These customers have specifically requested a quote from you. View their room photos and specifications to provide accurate estimates.'
                : 'These customers are looking for contractors. Send them a quote to get their business!'
              }
            </p>
          </div>
        </div>

        {/* Projects Grid */}
        {displayProjects.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-sm p-12 text-center">
            <div className="w-20 h-20 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-10 h-10 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
              </svg>
            </div>
            <h3 className="text-neutral-900 mb-2">No Design Requests Yet</h3>
            <p className="text-neutral-600">
              {selectedTab === 'sent-to-me' 
                ? 'When customers send you their designs, they\'ll appear here.'
                : 'Check back later for new project opportunities.'
              }
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayProjects.map((project) => (
              <div
                key={project.id}
                className="bg-white rounded-2xl shadow-sm overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => setSelectedProject(project)}
              >
                {/* Room Photo */}
                {project.roomPhoto && (
                  <div className="aspect-video bg-neutral-200 relative">
                    <img
                      src={project.roomPhoto}
                      alt={project.roomType}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-3 right-3">
                      <span className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm text-neutral-900">
                        {project.squareFootage} sq ft
                      </span>
                    </div>
                  </div>
                )}

                <div className="p-6">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="text-neutral-900 mb-1">{project.roomType}</h3>
                      <p className="text-sm text-neutral-600">{project.userName}</p>
                    </div>
                    {project.status === 'quoted' && (
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">
                        Quoted
                      </span>
                    )}
                  </div>

                  {/* Flooring Type */}
                  <div className="mb-4">
                    <div className="inline-flex items-center gap-2 bg-amber-50 text-amber-700 px-3 py-1 rounded-lg text-sm">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
                      </svg>
                      <span className="capitalize">{project.flooringType}</span>
                    </div>
                  </div>

                  {/* Specifications Preview */}
                  <div className="bg-neutral-50 rounded-lg p-3 mb-4 text-sm">
                    {project.hardwood && (
                      <div className="space-y-1">
                        <p className="text-neutral-700"><span className="text-neutral-500">Species:</span> {project.hardwood.species}</p>
                        <p className="text-neutral-700"><span className="text-neutral-500">Color:</span> {project.hardwood.color}</p>
                        <p className="text-neutral-700"><span className="text-neutral-500">Finish:</span> {project.hardwood.finish}</p>
                      </div>
                    )}
                    {project.carpet && (
                      <div className="space-y-1">
                        <p className="text-neutral-700"><span className="text-neutral-500">Style:</span> {project.carpet.style}</p>
                        <p className="text-neutral-700"><span className="text-neutral-500">Fiber:</span> {project.carpet.fiber}</p>
                        <p className="text-neutral-700"><span className="text-neutral-500">Color:</span> {project.carpet.color}</p>
                      </div>
                    )}
                    {project.tile && (
                      <div className="space-y-1">
                        <p className="text-neutral-700"><span className="text-neutral-500">Material:</span> {project.tile.material}</p>
                        <p className="text-neutral-700"><span className="text-neutral-500">Size:</span> {project.tile.size}</p>
                        <p className="text-neutral-700"><span className="text-neutral-500">Pattern:</span> {project.tile.pattern}</p>
                      </div>
                    )}
                  </div>

                  {/* Budget */}
                  {project.budget && (
                    <div className="flex items-center gap-2 text-sm text-neutral-600 mb-4">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span>Budget: ${project.budget.min.toLocaleString()} - ${project.budget.max.toLocaleString()}</span>
                    </div>
                  )}

                  {/* Action Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedProject(project);
                      setShowQuoteModal(true);
                    }}
                    className="w-full bg-amber-600 text-white py-2 rounded-lg hover:bg-amber-700 transition-colors"
                  >
                    Send Quote
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Project Detail Modal */}
      {selectedProject && !showQuoteModal && (
        <ProjectDetailModal
          project={selectedProject}
          onClose={() => setSelectedProject(null)}
          onSendQuote={() => setShowQuoteModal(true)}
        />
      )}

      {/* Quote Modal */}
      {showQuoteModal && selectedProject && (
        <QuoteModal
          project={selectedProject}
          onClose={() => {
            setShowQuoteModal(false);
            setSelectedProject(null);
          }}
        />
      )}
    </div>
  );
}

interface ProjectDetailModalProps {
  project: FloorProject;
  onClose: () => void;
  onSendQuote: () => void;
}

function ProjectDetailModal({ project, onClose, onSendQuote }: ProjectDetailModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full my-8">
        <div className="p-6 border-b border-neutral-200">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-neutral-900 mb-1">{project.roomType} - {project.userName}</h2>
              <p className="text-neutral-600">{project.squareFootage} sq ft • {new Date(project.createdDate).toLocaleDateString()}</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-neutral-100 rounded-lg transition-colors"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <div className="p-6 max-h-[70vh] overflow-y-auto">
          {/* Room Photo */}
          {project.roomPhoto && (
            <div className="mb-6">
              <h3 className="text-neutral-900 mb-3">Room Photo</h3>
              <div className="rounded-xl overflow-hidden">
                <img src={project.roomPhoto} alt={project.roomType} className="w-full" />
              </div>
            </div>
          )}

          {/* Complete Specifications */}
          <div className="mb-6">
            <h3 className="text-neutral-900 mb-3">Complete Specifications</h3>
            <div className="bg-neutral-50 rounded-xl p-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <p className="text-sm text-neutral-600 mb-1">Flooring Type</p>
                  <p className="text-neutral-900 capitalize">{project.flooringType}</p>
                </div>
                {project.hardwood && (
                  <>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Species</p>
                      <p className="text-neutral-900">{project.hardwood.species}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Grade</p>
                      <p className="text-neutral-900">{project.hardwood.grade}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Width</p>
                      <p className="text-neutral-900">{project.hardwood.width}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Finish</p>
                      <p className="text-neutral-900">{project.hardwood.finish}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Color</p>
                      <p className="text-neutral-900">{project.hardwood.color}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Installation Method</p>
                      <p className="text-neutral-900">{project.hardwood.installation}</p>
                    </div>
                  </>
                )}
                {project.carpet && (
                  <>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Style</p>
                      <p className="text-neutral-900">{project.carpet.style}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Fiber</p>
                      <p className="text-neutral-900">{project.carpet.fiber}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Color</p>
                      <p className="text-neutral-900">{project.carpet.color}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Padding</p>
                      <p className="text-neutral-900">{project.carpet.padding}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Texture</p>
                      <p className="text-neutral-900">{project.carpet.texture}</p>
                    </div>
                  </>
                )}
                {project.tile && (
                  <>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Material</p>
                      <p className="text-neutral-900">{project.tile.material}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Size</p>
                      <p className="text-neutral-900">{project.tile.size}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Color</p>
                      <p className="text-neutral-900">{project.tile.color}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Finish</p>
                      <p className="text-neutral-900">{project.tile.finish}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600 mb-1">Pattern</p>
                      <p className="text-neutral-900">{project.tile.pattern}</p>
                    </div>
                    {project.tile.groutColor && (
                      <div>
                        <p className="text-sm text-neutral-600 mb-1">Grout Color</p>
                        <p className="text-neutral-900">{project.tile.groutColor}</p>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Customer Notes */}
          {project.notes && (
            <div className="mb-6">
              <h3 className="text-neutral-900 mb-3">Customer Notes</h3>
              <div className="bg-neutral-50 rounded-xl p-4">
                <p className="text-neutral-700">{project.notes}</p>
              </div>
            </div>
          )}

          {/* Budget */}
          {project.budget && (
            <div>
              <h3 className="text-neutral-900 mb-3">Budget Range</h3>
              <div className="bg-green-50 rounded-xl p-4">
                <p className="text-green-900 text-lg">
                  ${project.budget.min.toLocaleString()} - ${project.budget.max.toLocaleString()}
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-neutral-200">
          <div className="flex gap-4">
            <button
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-neutral-200 rounded-xl hover:bg-neutral-50 transition-colors"
            >
              Close
            </button>
            <button
              onClick={onSendQuote}
              className="flex-1 px-6 py-3 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors"
            >
              Send Quote
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

interface QuoteModalProps {
  project: FloorProject;
  onClose: () => void;
}

function QuoteModal({ project, onClose }: QuoteModalProps) {
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  const handleSend = () => {
    setSent(true);
    setTimeout(() => {
      onClose();
    }, 2000);
  };

  if (sent) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-2xl max-w-md w-full p-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-neutral-900 mb-2">Quote Sent!</h2>
          <p className="text-neutral-600">
            {project.userName} will receive your quote and can contact you to move forward.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-neutral-200">
          <div className="flex items-center justify-between">
            <h2 className="text-neutral-900">Send Quote to {project.userName}</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-neutral-100 rounded-lg transition-colors"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Project Summary */}
          <div className="bg-neutral-50 rounded-xl p-4">
            <h3 className="text-neutral-900 mb-2">{project.roomType}</h3>
            <p className="text-sm text-neutral-600">{project.squareFootage} sq ft • {project.flooringType}</p>
          </div>

          {/* Quote Amount */}
          <div>
            <label className="text-neutral-900 mb-2 block">Quote Amount</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500">$</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full pl-8 pr-4 py-3 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600"
                placeholder="4,500"
                required
              />
            </div>
            {project.budget && (
              <p className="text-sm text-neutral-600 mt-1">
                Customer budget: ${project.budget.min.toLocaleString()} - ${project.budget.max.toLocaleString()}
              </p>
            )}
          </div>

          {/* Message */}
          <div>
            <label className="text-neutral-900 mb-2 block">Message to Customer</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full border border-neutral-200 rounded-xl p-4 min-h-[150px] focus:outline-none focus:ring-2 focus:ring-amber-600"
              placeholder="Hi! I'd be happy to help with your flooring project. This quote includes materials, professional installation, and cleanup. I can start as soon as next week..."
              required
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 pt-4">
            <button
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-neutral-200 rounded-xl hover:bg-neutral-50 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSend}
              disabled={!amount || !message}
              className="flex-1 px-6 py-3 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors disabled:bg-neutral-300 disabled:cursor-not-allowed"
            >
              Send Quote
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
