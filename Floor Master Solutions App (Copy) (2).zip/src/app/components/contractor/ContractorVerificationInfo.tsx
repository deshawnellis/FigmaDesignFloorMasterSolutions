import { Shield, CheckCircle, Clock, Award, FileText, Users, AlertTriangle, Lock } from 'lucide-react';

export function ContractorVerificationInfo({ onStartVerification }: { onStartVerification: () => void }) {
  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        {/* Hero Section */}
        <div className="bg-gradient-to-br from-amber-600 to-amber-700 rounded-2xl p-8 md:p-12 text-white mb-8">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white/20 rounded-full px-4 py-2 mb-6">
              <Shield className="w-5 h-5" />
              <span className="text-sm">Verified Contractor Program</span>
            </div>
            <h1 className="mb-4">Join Floor Master Solutions as a Verified Contractor</h1>
            <p className="text-xl text-white/90 mb-6">
              Connect with qualified homeowners looking for professional flooring installation services. 
              Our comprehensive verification process ensures quality and builds trust.
            </p>
            <div className="flex flex-wrap gap-4">
              <button
                onClick={onStartVerification}
                className="bg-white text-amber-700 px-6 py-3 rounded-xl hover:bg-neutral-100 transition-colors flex items-center gap-2"
              >
                Start Application
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </button>
              <button className="bg-amber-800 text-white px-6 py-3 rounded-xl hover:bg-amber-900 transition-colors">
                Learn More
              </button>
            </div>
          </div>
        </div>

        {/* Why Get Verified */}
        <div className="bg-white rounded-2xl p-8 mb-8">
          <h2 className="text-neutral-900 mb-6">Why Get Verified?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-neutral-900 mb-2">Quality Leads</h3>
              <p className="text-sm text-neutral-600">
                Connect with serious homeowners who have already designed their projects and are ready to hire.
              </p>
            </div>
            <div>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-neutral-900 mb-2">Build Trust</h3>
              <p className="text-sm text-neutral-600">
                Our verification badge shows homeowners you're licensed, insured, and background-checked.
              </p>
            </div>
            <div>
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-4">
                <Award className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-neutral-900 mb-2">Stand Out</h3>
              <p className="text-sm text-neutral-600">
                Showcase your certifications, portfolio, and customer reviews to win more projects.
              </p>
            </div>
          </div>
        </div>

        {/* Verification Process */}
        <div className="bg-white rounded-2xl p-8 mb-8">
          <h2 className="text-neutral-900 mb-2">Our Verification Process</h2>
          <p className="text-neutral-600 mb-8">
            We take contractor verification seriously to protect homeowners and maintain platform quality.
          </p>

          <div className="space-y-6">
            {/* Step 1 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center">
                  <span className="text-amber-600">1</span>
                </div>
              </div>
              <div className="flex-1">
                <h4 className="text-neutral-900 mb-2">Business Information Verification</h4>
                <p className="text-sm text-neutral-600 mb-3">
                  We verify your business registration, EIN, and confirm you're operating legally in your state.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Business License</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Tax ID (EIN)</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Business Address</span>
                </div>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center">
                  <span className="text-amber-600">2</span>
                </div>
              </div>
              <div className="flex-1">
                <h4 className="text-neutral-900 mb-2">License & Credentials Check</h4>
                <p className="text-sm text-neutral-600 mb-3">
                  We verify your contractor license with state licensing boards and confirm it's current and in good standing.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">State License Verification</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Expiration Check</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Disciplinary Records</span>
                </div>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center">
                  <span className="text-amber-600">3</span>
                </div>
              </div>
              <div className="flex-1">
                <h4 className="text-neutral-900 mb-2">Insurance Verification</h4>
                <p className="text-sm text-neutral-600 mb-3">
                  We contact your insurance provider to verify active general liability and workers' compensation coverage.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">$1M+ Liability Required</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Workers' Comp</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Direct Provider Verification</span>
                </div>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center">
                  <span className="text-amber-600">4</span>
                </div>
              </div>
              <div className="flex-1">
                <h4 className="text-neutral-900 mb-2">Background Check</h4>
                <p className="text-sm text-neutral-600 mb-3">
                  Comprehensive background screening to ensure homeowner safety and platform integrity.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Criminal Records (7 years)</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Sex Offender Registry</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Court Records</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">BBB Rating</span>
                </div>
              </div>
            </div>

            {/* Step 5 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center">
                  <span className="text-amber-600">5</span>
                </div>
              </div>
              <div className="flex-1">
                <h4 className="text-neutral-900 mb-2">Reference Verification</h4>
                <p className="text-sm text-neutral-600 mb-3">
                  We contact your professional references to verify work quality, reliability, and professionalism.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">3+ References Required</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Direct Contact</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Quality Assessment</span>
                </div>
              </div>
            </div>

            {/* Step 6 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center">
                  <span className="text-amber-600">6</span>
                </div>
              </div>
              <div className="flex-1">
                <h4 className="text-neutral-900 mb-2">Safety Compliance Review</h4>
                <p className="text-sm text-neutral-600 mb-3">
                  Confirmation of OSHA compliance and adherence to safety standards to protect workers and homeowners.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">OSHA Certification</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Safety Training</span>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full">Equipment Standards</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Requirements Checklist */}
        <div className="bg-white rounded-2xl p-8 mb-8">
          <h2 className="text-neutral-900 mb-2">Requirements Checklist</h2>
          <p className="text-neutral-600 mb-6">Make sure you have these before starting your application:</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-neutral-900 text-sm mb-1">Valid contractor license</p>
                <p className="text-xs text-neutral-600">Current and in good standing with your state</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-neutral-900 text-sm mb-1">General liability insurance ($1M minimum)</p>
                <p className="text-xs text-neutral-600">Certificate of insurance from provider</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-neutral-900 text-sm mb-1">Workers' compensation insurance</p>
                <p className="text-xs text-neutral-600">Or proof of exemption for sole proprietors</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-neutral-900 text-sm mb-1">Business registration documents</p>
                <p className="text-xs text-neutral-600">EIN and state business registration</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-neutral-900 text-sm mb-1">OSHA safety certification</p>
                <p className="text-xs text-neutral-600">OSHA 10 or 30-hour construction safety</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-neutral-900 text-sm mb-1">3+ professional references</p>
                <p className="text-xs text-neutral-600">Past clients or industry professionals</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-neutral-900 text-sm mb-1">Portfolio of completed work</p>
                <p className="text-xs text-neutral-600">5-15 high-quality project photos</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-neutral-900 text-sm mb-1">Clean background check</p>
                <p className="text-xs text-neutral-600">No disqualifying criminal history</p>
              </div>
            </div>
          </div>
        </div>

        {/* Timeline */}
        <div className="bg-white rounded-2xl p-8 mb-8">
          <h2 className="text-neutral-900 mb-6">Verification Timeline</h2>
          <div className="flex items-center gap-4 mb-6">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-5 h-5 text-amber-600" />
                <h4 className="text-neutral-900">Application Submission</h4>
              </div>
              <p className="text-sm text-neutral-600">30-45 minutes to complete all sections</p>
            </div>
            <div className="text-2xl text-neutral-300">→</div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-5 h-5 text-blue-600" />
                <h4 className="text-neutral-900">Verification Process</h4>
              </div>
              <p className="text-sm text-neutral-600">3-5 business days for complete review</p>
            </div>
            <div className="text-2xl text-neutral-300">→</div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <h4 className="text-neutral-900">Approval & Launch</h4>
              </div>
              <p className="text-sm text-neutral-600">Start receiving leads immediately</p>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-900">
              <strong>Expedited Review Available:</strong> Need faster approval? Contact our contractor support team about our expedited verification service (additional fee may apply).
            </p>
          </div>
        </div>

        {/* Safety & Security */}
        <div className="bg-gradient-to-br from-slate-700 to-slate-800 rounded-2xl p-8 text-white mb-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-white mb-2">Your Information is Secure</h2>
              <p className="text-white/80">
                We use bank-level encryption to protect your personal and business information. 
                Your data is never sold to third parties and is only shared with homeowners you choose to work with.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 flex-shrink-0" />
              <span>256-bit Encryption</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 flex-shrink-0" />
              <span>GDPR Compliant</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 flex-shrink-0" />
              <span>SOC 2 Certified</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 flex-shrink-0" />
              <span>Annual Audits</span>
            </div>
          </div>
        </div>

        {/* Ongoing Requirements */}
        <div className="bg-white rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <h2 className="text-neutral-900 mb-2">Ongoing Requirements</h2>
              <p className="text-neutral-600">
                To maintain your verified status, you must keep these current at all times:
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-neutral-200 rounded-lg p-4">
              <h4 className="text-neutral-900 mb-2">Annual Renewals</h4>
              <ul className="space-y-2 text-sm text-neutral-600">
                <li>• Insurance policy must remain active</li>
                <li>• License must be renewed before expiration</li>
                <li>• Background check updated annually</li>
                <li>• Safety certifications kept current</li>
              </ul>
            </div>

            <div className="border border-neutral-200 rounded-lg p-4">
              <h4 className="text-neutral-900 mb-2">Platform Standards</h4>
              <ul className="space-y-2 text-sm text-neutral-600">
                <li>• Maintain 4.0+ star rating</li>
                <li>• Respond to inquiries within 24 hours</li>
                <li>• No valid complaints or disputes</li>
                <li>• Follow community guidelines</li>
              </ul>
            </div>
          </div>

          <div className="mt-4 bg-orange-50 border border-orange-200 rounded-lg p-4">
            <p className="text-sm text-orange-900">
              <strong>Important:</strong> Failure to maintain these requirements will result in account suspension until documentation is updated. 
              We'll send reminders 30 days before any expirations.
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="bg-white rounded-2xl p-8 text-center">
          <h2 className="text-neutral-900 mb-4">Ready to Get Started?</h2>
          <p className="text-neutral-600 mb-6 max-w-2xl mx-auto">
            Join thousands of verified contractors connecting with quality leads on Floor Master Solutions. 
            The application takes 30-45 minutes and you'll hear back within 3-5 business days.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button
              onClick={onStartVerification}
              className="bg-amber-600 text-white px-8 py-4 rounded-xl hover:bg-amber-700 transition-colors flex items-center justify-center gap-2"
            >
              <FileText className="w-5 h-5" />
              Start Your Application
            </button>
            <button className="bg-neutral-100 text-neutral-900 px-8 py-4 rounded-xl hover:bg-neutral-200 transition-colors">
              Schedule a Call with Our Team
            </button>
          </div>

          <div className="mt-8 pt-6 border-t border-neutral-200">
            <p className="text-sm text-neutral-600">
              Questions? Email us at <a href="mailto:contractors@floormaster.com" className="text-amber-600 hover:text-amber-700">contractors@floormaster.com</a> or call <a href="tel:1-800-555-0123" className="text-amber-600 hover:text-amber-700">1-800-555-0123</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
