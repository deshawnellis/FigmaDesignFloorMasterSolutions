import { useState } from 'react';
import { ContractorMVPOnboarding } from './ContractorMVPOnboarding';
import { ContractorMVPDashboard } from './ContractorMVPDashboard';

export function ContractorAuthFlow() {
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'forgot' | 'onboarding' | 'dashboard'>('login');
  const [contractorProfile, setContractorProfile] = useState<any>(null);

  // Login state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Forgot password state
  const [resetEmail, setResetEmail] = useState('');
  const [resetSent, setResetSent] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock login - in real app, would authenticate with backend
    setAuthMode('dashboard');
    // Mock profile data
    setContractorProfile({
      companyName: 'Elite Flooring Solutions',
      ownerName: 'John Smith',
      email: loginEmail,
      phone: '(555) 123-4567',
      city: 'New York',
      serviceRadius: 50,
      flooringTypes: ['Hardwood', 'LVP', 'Tile', 'Epoxy'],
      epoxyOptions: ['Garage', 'Basement', 'Metallic'],
      yearsExperience: 15,
      hasInsurance: true,
      warrantyText: '1-year workmanship warranty on all installations',
      planType: 'pro',
    });
  };

  const handleSignupStart = () => {
    setAuthMode('onboarding');
  };

  const handleOnboardingComplete = (data: any) => {
    setContractorProfile(data);
    setAuthMode('dashboard');
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock password reset
    setResetSent(true);
  };

  if (authMode === 'onboarding') {
    return <ContractorMVPOnboarding onComplete={handleOnboardingComplete} />;
  }

  if (authMode === 'dashboard' && contractorProfile) {
    return <ContractorMVPDashboard profile={contractorProfile} />;
  }

  if (authMode === 'forgot') {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8">
          {!resetSent ? (
            <>
              <h2 className="text-neutral-900 mb-2">Reset Password</h2>
              <p className="text-neutral-600 mb-6">
                Enter your email address and we'll send you a link to reset your password.
              </p>

              <form onSubmit={handleForgotPassword} className="space-y-4">
                <div>
                  <label className="text-sm text-neutral-700 mb-2 block">Email Address</label>
                  <input
                    type="email"
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                    placeholder="you@company.com"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-amber-600 text-white py-3 rounded-xl hover:bg-amber-700 transition-colors"
                >
                  Send Reset Link
                </button>

                <button
                  type="button"
                  onClick={() => setAuthMode('login')}
                  className="w-full text-amber-600 hover:text-amber-700 text-sm"
                >
                  ← Back to Login
                </button>
              </form>
            </>
          ) : (
            <>
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-8 h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h2 className="text-neutral-900 mb-2 text-center">Check Your Email</h2>
              <p className="text-neutral-600 mb-6 text-center">
                We've sent a password reset link to {resetEmail}
              </p>
              <button
                onClick={() => {
                  setAuthMode('login');
                  setResetSent(false);
                  setResetEmail('');
                }}
                className="w-full bg-amber-600 text-white py-3 rounded-xl hover:bg-amber-700 transition-colors"
              >
                Back to Login
              </button>
            </>
          )}
        </div>
      </div>
    );
  }

  // Login Screen
  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="grid grid-cols-1 lg:grid-cols-2 min-h-screen">
        {/* Left Side - Branding */}
        <div className="bg-gradient-to-br from-amber-600 to-amber-700 p-8 lg:p-12 flex flex-col justify-center text-white">
          <div className="max-w-md">
            <h1 className="text-white mb-6">Floor Master Solutions</h1>
            <h2 className="text-white text-3xl mb-4">Contractor Portal</h2>
            <p className="text-xl text-white/90 mb-8">
              Connect with homeowners looking for professional flooring services. Grow your business with quality leads.
            </p>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <p className="mb-1">Quality Leads</p>
                  <p className="text-sm text-white/80">Homeowners ready to hire, not just browsing</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <p className="mb-1">No Contracts</p>
                  <p className="text-sm text-white/80">Cancel anytime, no long-term commitments</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <p className="mb-1">Affordable Pricing</p>
                  <p className="text-sm text-white/80">Plans starting at just $25/month</p>
                </div>
              </div>
            </div>

            <div className="mt-12 pt-8 border-t border-white/20">
              <p className="text-sm text-white/80">
                "We've closed over $150,000 in jobs from Floor Master leads in the past 6 months. Best investment we've made!"
              </p>
              <p className="text-sm mt-2">— Mike Torres, Elite Flooring NYC</p>
            </div>
          </div>
        </div>

        {/* Right Side - Auth Forms */}
        <div className="flex items-center justify-center p-8 lg:p-12">
          <div className="w-full max-w-md">
            {authMode === 'login' ? (
              <>
                <h2 className="text-neutral-900 mb-2">Welcome Back</h2>
                <p className="text-neutral-600 mb-8">Sign in to your contractor account</p>

                <form onSubmit={handleLogin} className="space-y-4">
                  <div>
                    <label className="text-sm text-neutral-700 mb-2 block">Email Address</label>
                    <input
                      type="email"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                      placeholder="you@company.com"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-sm text-neutral-700 mb-2 block">Password</label>
                    <input
                      type="password"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                      placeholder="••••••••"
                      required
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="flex items-center gap-2">
                      <input type="checkbox" className="w-4 h-4 text-amber-600 rounded" />
                      <span className="text-sm text-neutral-700">Remember me</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setAuthMode('forgot')}
                      className="text-sm text-amber-600 hover:text-amber-700"
                    >
                      Forgot password?
                    </button>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-amber-600 text-white py-3 rounded-xl hover:bg-amber-700 transition-colors"
                  >
                    Sign In
                  </button>
                </form>

                <div className="mt-6 text-center">
                  <p className="text-neutral-600 mb-2">Don't have an account?</p>
                  <button
                    onClick={handleSignupStart}
                    className="text-amber-600 hover:text-amber-700"
                  >
                    Create a Contractor Account →
                  </button>
                </div>

                <div className="mt-8 pt-6 border-t border-neutral-200">
                  <p className="text-sm text-neutral-600 text-center">
                    Need help? Contact us at{' '}
                    <a href="mailto:contractors@floormaster.com" className="text-amber-600 hover:text-amber-700">
                      contractors@floormaster.com
                    </a>
                  </p>
                </div>
              </>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
