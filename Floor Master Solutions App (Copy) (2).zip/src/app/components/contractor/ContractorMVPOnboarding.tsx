import { useState } from 'react';
import { Upload, X, Check } from 'lucide-react';

interface ContractorMVPOnboardingProps {
  onComplete: (contractorData: any) => void;
}

export function ContractorMVPOnboarding({ onComplete }: ContractorMVPOnboardingProps) {
  const [currentScreen, setCurrentScreen] = useState(1);
  
  // Screen 1: Account
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Screen 2: Company Info
  const [companyName, setCompanyName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [serviceRadius, setServiceRadius] = useState('25');

  // Screen 3: Services
  const [flooringTypes, setFlooringTypes] = useState<string[]>([]);
  const [epoxyOptions, setEpoxyOptions] = useState<string[]>([]);

  // Screen 4: Experience & Trust
  const [yearsExperience, setYearsExperience] = useState('');
  const [hasInsurance, setHasInsurance] = useState(false);
  const [warrantyText, setWarrantyText] = useState('');

  // Screen 5: Uploads
  const [logo, setLogo] = useState<File | null>(null);
  const [jobPhotos, setJobPhotos] = useState<File[]>([]);

  // Screen 6: Plan
  const [selectedPlan, setSelectedPlan] = useState('pro');

  const allFlooringTypes = ['Carpet', 'Hardwood', 'LVP', 'Tile', 'Epoxy'];
  const allEpoxyOptions = ['Garage', 'Basement', 'Commercial', 'Flake', 'Metallic'];

  const toggleFlooringType = (type: string) => {
    if (flooringTypes.includes(type)) {
      setFlooringTypes(flooringTypes.filter(t => t !== type));
      if (type === 'Epoxy') {
        setEpoxyOptions([]);
      }
    } else {
      setFlooringTypes([...flooringTypes, type]);
    }
  };

  const toggleEpoxyOption = (option: string) => {
    if (epoxyOptions.includes(option)) {
      setEpoxyOptions(epoxyOptions.filter(o => o !== option));
    } else {
      setEpoxyOptions([...epoxyOptions, option]);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'logo' | 'photos') => {
    const files = e.target.files;
    if (!files) return;

    if (type === 'logo') {
      setLogo(files[0]);
    } else {
      setJobPhotos([...jobPhotos, ...Array.from(files)]);
    }
  };

  const removePhoto = (index: number) => {
    setJobPhotos(jobPhotos.filter((_, i) => i !== index));
  };

  const handleFinishSetup = () => {
    const contractorData = {
      email,
      password,
      companyName,
      ownerName,
      phone,
      city,
      serviceRadius: parseInt(serviceRadius),
      flooringTypes,
      epoxyOptions,
      yearsExperience: parseInt(yearsExperience),
      hasInsurance,
      warrantyText,
      logo,
      jobPhotos,
      planType: selectedPlan,
      createdAt: new Date().toISOString(),
    };
    onComplete(contractorData);
  };

  const canProceed = () => {
    switch (currentScreen) {
      case 1:
        return email && password && password.length >= 6;
      case 2:
        return companyName && ownerName && phone && city && serviceRadius;
      case 3:
        return flooringTypes.length > 0;
      case 4:
        return yearsExperience;
      case 5:
        return true; // Optional
      case 6:
        return selectedPlan;
      default:
        return true;
    }
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-neutral-900 mb-2">Create Your Account</h2>
              <p className="text-neutral-600">Start connecting with homeowners looking for flooring services</p>
            </div>

            <div>
              <label className="text-sm text-neutral-700 mb-2 block">Email Address *</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                placeholder="you@company.com"
              />
            </div>

            <div>
              <label className="text-sm text-neutral-700 mb-2 block">Password *</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                placeholder="Minimum 6 characters"
              />
              {password && password.length < 6 && (
                <p className="text-sm text-red-600 mt-1">Password must be at least 6 characters</p>
              )}
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-900">
                By creating an account, you agree to our Terms of Service and Privacy Policy
              </p>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-neutral-900 mb-2">Company Information</h2>
              <p className="text-neutral-600">Tell us about your flooring business</p>
            </div>

            <div>
              <label className="text-sm text-neutral-700 mb-2 block">Company Name *</label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                placeholder="ABC Flooring Solutions"
              />
            </div>

            <div>
              <label className="text-sm text-neutral-700 mb-2 block">Owner Name *</label>
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                placeholder="John Smith"
              />
            </div>

            <div>
              <label className="text-sm text-neutral-700 mb-2 block">Phone Number *</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                placeholder="(555) 123-4567"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-neutral-700 mb-2 block">City *</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                  placeholder="New York"
                />
              </div>

              <div>
                <label className="text-sm text-neutral-700 mb-2 block">Service Radius (miles) *</label>
                <select
                  value={serviceRadius}
                  onChange={(e) => setServiceRadius(e.target.value)}
                  className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                >
                  <option value="10">10 miles</option>
                  <option value="25">25 miles</option>
                  <option value="50">50 miles</option>
                  <option value="75">75 miles</option>
                  <option value="100">100 miles</option>
                </select>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-neutral-900 mb-2">Services Offered</h2>
              <p className="text-neutral-600">Select all flooring types you install</p>
            </div>

            <div className="space-y-3">
              {allFlooringTypes.map((type) => (
                <label
                  key={type}
                  className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                    flooringTypes.includes(type)
                      ? 'border-amber-600 bg-amber-50'
                      : 'border-neutral-200 hover:border-neutral-300'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={flooringTypes.includes(type)}
                    onChange={() => toggleFlooringType(type)}
                    className="w-5 h-5 text-amber-600 rounded"
                  />
                  <span className="text-neutral-900">{type}</span>
                  {flooringTypes.includes(type) && (
                    <Check className="w-5 h-5 text-amber-600 ml-auto" />
                  )}
                </label>
              ))}
            </div>

            {/* Epoxy Sub-Options */}
            {flooringTypes.includes('Epoxy') && (
              <div className="bg-neutral-50 rounded-xl p-4 space-y-3">
                <h4 className="text-neutral-900 mb-2">Epoxy Specializations</h4>
                <p className="text-sm text-neutral-600 mb-3">Select your epoxy flooring expertise:</p>
                
                <div className="grid grid-cols-2 gap-3">
                  {allEpoxyOptions.map((option) => (
                    <label
                      key={option}
                      className={`flex items-center gap-2 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                        epoxyOptions.includes(option)
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-neutral-300'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={epoxyOptions.includes(option)}
                        onChange={() => toggleEpoxyOption(option)}
                        className="w-4 h-4 text-amber-600 rounded"
                      />
                      <span className="text-sm text-neutral-900">{option}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-neutral-900 mb-2">Experience & Trust</h2>
              <p className="text-neutral-600">Build confidence with potential customers</p>
            </div>

            <div>
              <label className="text-sm text-neutral-700 mb-2 block">Years of Experience *</label>
              <input
                type="number"
                value={yearsExperience}
                onChange={(e) => setYearsExperience(e.target.value)}
                className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600"
                placeholder="10"
                min="0"
              />
            </div>

            <div className="bg-neutral-50 rounded-xl p-4">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasInsurance}
                  onChange={(e) => setHasInsurance(e.target.checked)}
                  className="w-5 h-5 text-amber-600 rounded mt-0.5"
                />
                <div>
                  <p className="text-neutral-900 mb-1">I have liability insurance</p>
                  <p className="text-sm text-neutral-600">
                    Customers prefer insured contractors. You'll get more leads with insurance.
                  </p>
                </div>
              </label>
            </div>

            <div>
              <label className="text-sm text-neutral-700 mb-2 block">Warranty Information (Optional)</label>
              <textarea
                value={warrantyText}
                onChange={(e) => setWarrantyText(e.target.value)}
                className="w-full border border-neutral-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-600 min-h-[100px]"
                placeholder="e.g., 1-year workmanship warranty, lifetime material warranty..."
              />
              <p className="text-xs text-neutral-500 mt-1">
                Describe any warranties you offer on your work
              </p>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-neutral-900 mb-2">Upload Your Work</h2>
              <p className="text-neutral-600">Show homeowners what you can do</p>
            </div>

            {/* Logo Upload */}
            <div>
              <label className="text-sm text-neutral-700 mb-2 block">Company Logo (Optional)</label>
              <label className="w-full border-2 border-dashed border-neutral-300 rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:border-amber-600 transition-colors">
                <Upload className="w-10 h-10 text-neutral-400 mb-2" />
                <span className="text-sm text-neutral-600">
                  {logo ? logo.name : 'Click to upload your logo'}
                </span>
                <span className="text-xs text-neutral-500 mt-1">PNG or JPG (max 5MB)</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileUpload(e, 'logo')}
                  className="hidden"
                />
              </label>
            </div>

            {/* Job Photos Upload */}
            <div>
              <label className="text-sm text-neutral-700 mb-2 block">Job Photos (Optional)</label>
              <label className="w-full border-2 border-dashed border-neutral-300 rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:border-amber-600 transition-colors">
                <Upload className="w-10 h-10 text-neutral-400 mb-2" />
                <span className="text-sm text-neutral-600">
                  {jobPhotos.length > 0
                    ? `${jobPhotos.length} photo(s) uploaded`
                    : 'Click to upload job photos'}
                </span>
                <span className="text-xs text-neutral-500 mt-1">Upload multiple photos of your completed work</span>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={(e) => handleFileUpload(e, 'photos')}
                  className="hidden"
                />
              </label>

              {jobPhotos.length > 0 && (
                <div className="grid grid-cols-3 gap-3 mt-4">
                  {jobPhotos.map((photo, index) => (
                    <div key={index} className="relative aspect-square bg-neutral-100 rounded-lg overflow-hidden group">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Upload className="w-8 h-8 text-neutral-400" />
                      </div>
                      <p className="absolute bottom-2 left-2 right-2 text-xs text-neutral-600 truncate bg-white/90 px-2 py-1 rounded">
                        {photo.name}
                      </p>
                      <button
                        onClick={() => removePhoto(index)}
                        className="absolute top-2 right-2 bg-red-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-900">
                <strong>Pro tip:</strong> Contractors with photos get 3x more leads! Upload at least 5 photos of your best work.
              </p>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-neutral-900 mb-2">Choose Your Plan</h2>
              <p className="text-neutral-600">Select the plan that works best for your business</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Free Plan */}
              <label
                className={`relative border-2 rounded-xl p-6 cursor-pointer transition-all ${
                  selectedPlan === 'free'
                    ? 'border-amber-600 bg-amber-50'
                    : 'border-neutral-200 hover:border-neutral-300'
                }`}
              >
                <input
                  type="radio"
                  name="plan"
                  value="free"
                  checked={selectedPlan === 'free'}
                  onChange={(e) => setSelectedPlan(e.target.value)}
                  className="hidden"
                />
                {selectedPlan === 'free' && (
                  <div className="absolute top-4 right-4">
                    <Check className="w-5 h-5 text-amber-600" />
                  </div>
                )}
                <div className="mb-4">
                  <h3 className="text-neutral-900 mb-1">Free</h3>
                  <p className="text-2xl text-neutral-900 mb-2">$0<span className="text-sm text-neutral-600">/mo</span></p>
                </div>
                <ul className="space-y-2 text-sm text-neutral-700">
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Profile listing only</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <X className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                    <span>No leads</span>
                  </li>
                </ul>
                <p className="text-xs text-neutral-600 mt-4">Test the platform before committing</p>
              </label>

              {/* Starter Plan */}
              <label
                className={`relative border-2 rounded-xl p-6 cursor-pointer transition-all ${
                  selectedPlan === 'starter'
                    ? 'border-amber-600 bg-amber-50'
                    : 'border-neutral-200 hover:border-neutral-300'
                }`}
              >
                <input
                  type="radio"
                  name="plan"
                  value="starter"
                  checked={selectedPlan === 'starter'}
                  onChange={(e) => setSelectedPlan(e.target.value)}
                  className="hidden"
                />
                {selectedPlan === 'starter' && (
                  <div className="absolute top-4 right-4">
                    <Check className="w-5 h-5 text-amber-600" />
                  </div>
                )}
                <div className="mb-4">
                  <h3 className="text-neutral-900 mb-1">Starter</h3>
                  <p className="text-2xl text-neutral-900 mb-2">$25<span className="text-sm text-neutral-600">/mo</span></p>
                </div>
                <ul className="space-y-2 text-sm text-neutral-700">
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Up to 10 leads/month</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Lead inbox</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Reviews</span>
                  </li>
                </ul>
                <p className="text-xs text-neutral-600 mt-4">Cheaper than ads, no contracts</p>
              </label>

              {/* Pro Plan */}
              <label
                className={`relative border-2 rounded-xl p-6 cursor-pointer transition-all ${
                  selectedPlan === 'pro'
                    ? 'border-amber-600 bg-amber-50'
                    : 'border-neutral-200 hover:border-neutral-300'
                }`}
              >
                <input
                  type="radio"
                  name="plan"
                  value="pro"
                  checked={selectedPlan === 'pro'}
                  onChange={(e) => setSelectedPlan(e.target.value)}
                  className="hidden"
                />
                <div className="absolute top-0 right-0 bg-green-600 text-white text-xs px-3 py-1 rounded-bl-lg rounded-tr-xl">
                  BEST SELLER
                </div>
                {selectedPlan === 'pro' && (
                  <div className="absolute top-4 left-4">
                    <Check className="w-5 h-5 text-amber-600" />
                  </div>
                )}
                <div className="mb-4 mt-4">
                  <h3 className="text-neutral-900 mb-1">Pro</h3>
                  <p className="text-2xl text-neutral-900 mb-2">$49<span className="text-sm text-neutral-600">/mo</span></p>
                </div>
                <ul className="space-y-2 text-sm text-neutral-700">
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Unlimited leads</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Lead inbox</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Reviews</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Lead filters</span>
                  </li>
                </ul>
                <p className="text-xs text-neutral-600 mt-4">1 job pays for the whole year</p>
              </label>

              {/* Elite Plan */}
              <label
                className={`relative border-2 rounded-xl p-6 cursor-pointer transition-all ${
                  selectedPlan === 'elite'
                    ? 'border-amber-600 bg-amber-50'
                    : 'border-neutral-200 hover:border-neutral-300'
                }`}
              >
                <input
                  type="radio"
                  name="plan"
                  value="elite"
                  checked={selectedPlan === 'elite'}
                  onChange={(e) => setSelectedPlan(e.target.value)}
                  className="hidden"
                />
                {selectedPlan === 'elite' && (
                  <div className="absolute top-4 right-4">
                    <Check className="w-5 h-5 text-amber-600" />
                  </div>
                )}
                <div className="mb-4">
                  <h3 className="text-neutral-900 mb-1">Elite</h3>
                  <p className="text-2xl text-neutral-900 mb-2">$99<span className="text-sm text-neutral-600">/mo</span></p>
                </div>
                <ul className="space-y-2 text-sm text-neutral-700">
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Everything in Pro</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Priority placement</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>City/ZIP boost</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Analytics</span>
                  </li>
                </ul>
                <p className="text-xs text-neutral-600 mt-4">Built for serious contractors</p>
              </label>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <p className="text-sm text-green-900">
                <strong>No commitment required!</strong> Cancel anytime. First month satisfaction guaranteed or your money back.
              </p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-neutral-600">Step {currentScreen} of 6</span>
            <span className="text-sm text-neutral-600">{Math.round((currentScreen / 6) * 100)}% complete</span>
          </div>
          <div className="w-full bg-neutral-200 rounded-full h-2">
            <div
              className="bg-amber-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentScreen / 6) * 100}%` }}
            />
          </div>
        </div>

        {/* Screen Content */}
        <div className="bg-white rounded-2xl shadow-sm p-6 sm:p-8 mb-6">
          {renderScreen()}
        </div>

        {/* Navigation */}
        <div className="flex justify-between gap-4">
          <button
            onClick={() => setCurrentScreen(Math.max(1, currentScreen - 1))}
            disabled={currentScreen === 1}
            className="px-6 py-3 bg-neutral-100 text-neutral-900 rounded-xl hover:bg-neutral-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>

          {currentScreen < 6 ? (
            <button
              onClick={() => setCurrentScreen(currentScreen + 1)}
              disabled={!canProceed()}
              className="px-6 py-3 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next
            </button>
          ) : (
            <button
              onClick={handleFinishSetup}
              disabled={!canProceed()}
              className="px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              Finish Setup
              <Check className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
