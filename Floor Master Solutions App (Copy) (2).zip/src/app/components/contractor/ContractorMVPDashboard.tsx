import { useState } from 'react';
import { Mail, Phone, MessageSquare, CheckCircle, Star, TrendingUp, Users, DollarSign, Calendar, MapPin, Clock, Search, Award, Activity, Target, Zap, ChevronRight } from 'lucide-react';

interface Lead {
  id: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  flooringType: string;
  sqFt: number;
  city: string;
  timeline: string;
  status: 'new' | 'contacted' | 'closed';
  createdAt: string;
  estimatedValue?: number;
  priority?: 'high' | 'medium' | 'low';
}

interface Review {
  id: string;
  customerName: string;
  rating: number;
  comment: string;
  createdAt: string;
  reply?: string;
  flooringType?: string;
}

interface ContractorProfile {
  companyName: string;
  ownerName: string;
  email: string;
  phone: string;
  city: string;
  serviceRadius: number;
  flooringTypes: string[];
  epoxyOptions: string[];
  yearsExperience: number;
  hasInsurance: boolean;
  warrantyText: string;
  planType: 'free' | 'starter' | 'pro' | 'elite';
}

// Enhanced mock data
const mockLeads: Lead[] = [
  {
    id: 'lead-1',
    customerName: 'Sarah Johnson',
    customerPhone: '(555) 123-4567',
    customerEmail: 'sarah.j@email.com',
    flooringType: 'Hardwood',
    sqFt: 850,
    city: 'Brooklyn',
    timeline: 'Within 2 weeks',
    status: 'new',
    createdAt: '2025-01-15',
    estimatedValue: 8500,
    priority: 'high',
  },
  {
    id: 'lead-2',
    customerName: 'Michael Chen',
    customerPhone: '(555) 234-5678',
    customerEmail: 'mchen@email.com',
    flooringType: 'Epoxy',
    sqFt: 600,
    city: 'Queens',
    timeline: 'Within 1 month',
    status: 'new',
    createdAt: '2025-01-14',
    estimatedValue: 4200,
    priority: 'medium',
  },
  {
    id: 'lead-3',
    customerName: 'Emily Rodriguez',
    customerPhone: '(555) 345-6789',
    customerEmail: 'emily.r@email.com',
    flooringType: 'LVP',
    sqFt: 1200,
    city: 'Manhattan',
    timeline: 'Flexible',
    status: 'contacted',
    createdAt: '2025-01-13',
    estimatedValue: 7200,
    priority: 'medium',
  },
  {
    id: 'lead-4',
    customerName: 'David Kim',
    customerPhone: '(555) 456-7890',
    customerEmail: 'david.k@email.com',
    flooringType: 'Tile',
    sqFt: 400,
    city: 'Brooklyn',
    timeline: 'ASAP',
    status: 'new',
    createdAt: '2025-01-15',
    estimatedValue: 5600,
    priority: 'high',
  },
  {
    id: 'lead-5',
    customerName: 'Lisa Anderson',
    customerPhone: '(555) 567-8901',
    customerEmail: 'lisa.a@email.com',
    flooringType: 'Carpet',
    sqFt: 950,
    city: 'Staten Island',
    timeline: 'Within 3 months',
    status: 'contacted',
    createdAt: '2025-01-12',
    estimatedValue: 3800,
    priority: 'low',
  },
];

const mockReviews: Review[] = [
  {
    id: 'review-1',
    customerName: 'David Martinez',
    rating: 5,
    comment: 'Excellent work! The hardwood installation in my living room looks absolutely stunning. The team was professional, on time, and cleaned up everything perfectly. Highly recommend!',
    createdAt: '2025-01-10',
    flooringType: 'Hardwood',
  },
  {
    id: 'review-2',
    customerName: 'Jessica Park',
    rating: 5,
    comment: 'Outstanding service from start to finish. They helped me choose the perfect LVP for my kitchen and the installation was flawless. Very happy with the results!',
    createdAt: '2025-01-05',
    reply: 'Thank you Jessica! We loved working on your kitchen. Enjoy your new floors!',
    flooringType: 'LVP',
  },
  {
    id: 'review-3',
    customerName: 'Robert Wilson',
    rating: 4,
    comment: 'Great quality work on our epoxy garage floor. Took a bit longer than expected but the end result is worth it. Very durable and looks amazing.',
    createdAt: '2024-12-28',
    flooringType: 'Epoxy',
  },
  {
    id: 'review-4',
    customerName: 'Amanda Foster',
    rating: 5,
    comment: 'Best contractor we\'ve ever worked with! Professional, communicative, and the tile work is perfect. Worth every penny.',
    createdAt: '2024-12-20',
    flooringType: 'Tile',
  },
];

export function ContractorMVPDashboard({ profile }: { profile: ContractorProfile }) {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'leads' | 'reviews'>('dashboard');
  const [leads, setLeads] = useState<Lead[]>(mockLeads);
  const [reviews, setReviews] = useState<Review[]>(mockReviews);
  const [replyText, setReplyText] = useState<{ [key: string]: string }>({});
  const [leadFilter, setLeadFilter] = useState<'all' | 'new' | 'contacted' | 'closed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const newLeadsCount = leads.filter(l => l.status === 'new').length;
  const contactedLeadsCount = leads.filter(l => l.status === 'contacted').length;
  const averageRating = reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length;
  const totalEstimatedValue = leads.filter(l => l.status !== 'closed').reduce((acc, l) => acc + (l.estimatedValue || 0), 0);
  const weeklyLeads = leads.filter(l => {
    const leadDate = new Date(l.createdAt);
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return leadDate >= weekAgo;
  }).length;

  const handleMarkContacted = (leadId: string) => {
    setLeads(leads.map(lead =>
      lead.id === leadId ? { ...lead, status: 'contacted' as const } : lead
    ));
  };

  const handleMarkClosed = (leadId: string) => {
    setLeads(leads.map(lead =>
      lead.id === leadId ? { ...lead, status: 'closed' as const } : lead
    ));
  };

  const handleReplyToReview = (reviewId: string) => {
    const reply = replyText[reviewId];
    if (reply && reply.trim()) {
      setReviews(reviews.map(review =>
        review.id === reviewId ? { ...review, reply } : review
      ));
      setReplyText({ ...replyText, [reviewId]: '' });
    }
  };

  const getLeadLimitMessage = () => {
    const currentLeadsThisMonth = leads.length;
    switch (profile.planType) {
      case 'free':
        return 'Upgrade to receive leads';
      case 'starter':
        return `${currentLeadsThisMonth}/10 leads this month`;
      case 'pro':
      case 'elite':
        return 'Unlimited leads';
      default:
        return '';
    }
  };

  const filteredLeads = leads.filter(lead => {
    const matchesFilter = leadFilter === 'all' || lead.status === leadFilter;
    const matchesSearch = lead.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          lead.flooringType.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          lead.city.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getPriorityColor = (priority?: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-blue-100 text-blue-700 border-blue-200';
      default: return 'bg-neutral-100 text-neutral-700 border-neutral-200';
    }
  };

  const renderDashboard = () => {
    return (
      <div className="space-y-6">
        {/* Welcome Header */}
        <div className="bg-gradient-to-r from-amber-500 to-amber-600 rounded-2xl p-6 md:p-8 text-white">
          <div className="flex items-start justify-between mb-4 flex-wrap gap-4">
            <div>
              <h2 className="text-white mb-2">Welcome back, {profile.ownerName}! 👋</h2>
              <p className="text-white/90 text-lg">{profile.companyName}</p>
            </div>
            <div className="text-right">
              <p className="text-white/80 text-sm mb-1">Current Plan</p>
              <span className="bg-white/20 text-white px-4 py-1.5 rounded-full text-sm capitalize backdrop-blur-sm">
                {profile.planType}
              </span>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div>
              <p className="text-white/80 text-sm mb-1">New Leads</p>
              <p className="text-2xl sm:text-3xl text-white">{newLeadsCount}</p>
            </div>
            <div>
              <p className="text-white/80 text-sm mb-1">In Progress</p>
              <p className="text-2xl sm:text-3xl text-white">{contactedLeadsCount}</p>
            </div>
            <div>
              <p className="text-white/80 text-sm mb-1">This Week</p>
              <p className="text-2xl sm:text-3xl text-white">+{weeklyLeads}</p>
            </div>
            <div>
              <p className="text-white/80 text-sm mb-1">Est. Pipeline</p>
              <p className="text-2xl sm:text-3xl text-white">${(totalEstimatedValue / 1000).toFixed(1)}K</p>
            </div>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* New Leads Card */}
          <div className="bg-white rounded-xl p-6 border border-neutral-200 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <Zap className="w-6 h-6 text-green-600" />
              </div>
              {newLeadsCount > 0 && (
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">
                  Active
                </span>
              )}
            </div>
            <p className="text-sm text-neutral-600 mb-1">New Leads</p>
            <p className="text-3xl text-neutral-900 mb-2">{newLeadsCount}</p>
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="text-green-600">+{weeklyLeads} this week</span>
            </div>
          </div>

          {/* Average Rating Card */}
          <div className="bg-white rounded-xl p-6 border border-neutral-200 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
                <Award className="w-6 h-6 text-yellow-600" />
              </div>
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.round(averageRating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-neutral-300'
                    }`}
                  />
                ))}
              </div>
            </div>
            <p className="text-sm text-neutral-600 mb-1">Customer Rating</p>
            <p className="text-3xl text-neutral-900 mb-2">{averageRating.toFixed(1)}</p>
            <div className="flex items-center gap-2 text-sm text-neutral-600">
              <span>{reviews.length} total reviews</span>
            </div>
          </div>

          {/* Response Rate Card */}
          <div className="bg-white rounded-xl p-6 border border-neutral-200 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <Activity className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <p className="text-sm text-neutral-600 mb-1">Response Rate</p>
            <p className="text-3xl text-neutral-900 mb-2">94%</p>
            <div className="flex items-center gap-2 text-sm">
              <Clock className="w-4 h-4 text-neutral-600" />
              <span className="text-neutral-600">Avg. 2.3 hrs</span>
            </div>
          </div>

          {/* Conversion Rate Card */}
          <div className="bg-white rounded-xl p-6 border border-neutral-200 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                <Target className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <p className="text-sm text-neutral-600 mb-1">Conversion Rate</p>
            <p className="text-3xl text-neutral-900 mb-2">38%</p>
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="text-green-600">+5% vs last month</span>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-xl p-6 border border-neutral-200">
          <h3 className="text-neutral-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <button
              onClick={() => setActiveTab('leads')}
              className="bg-amber-600 text-white py-4 px-6 rounded-xl hover:bg-amber-700 transition-all flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5" />
                <div className="text-left">
                  <p className="font-medium">View New Leads</p>
                  <p className="text-sm text-white/80">{newLeadsCount} waiting</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className="bg-white border-2 border-neutral-200 text-neutral-900 py-4 px-6 rounded-xl hover:border-amber-600 hover:bg-amber-50 transition-all flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <Star className="w-5 h-5 text-amber-600" />
                <div className="text-left">
                  <p className="font-medium">Manage Reviews</p>
                  <p className="text-sm text-neutral-600">{reviews.filter(r => !r.reply).length} to respond</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="bg-white border-2 border-neutral-200 text-neutral-900 py-4 px-6 rounded-xl hover:border-amber-600 hover:bg-amber-50 transition-all flex items-center justify-between group">
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-blue-600" />
                <div className="text-left">
                  <p className="font-medium">Edit Profile</p>
                  <p className="text-sm text-neutral-600">85% complete</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* High Priority Leads */}
          <div className="lg:col-span-2 bg-white rounded-xl border border-neutral-200 overflow-hidden">
            <div className="p-6 border-b border-neutral-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-neutral-900 mb-1">High Priority Leads</h3>
                  <p className="text-sm text-neutral-600">Respond quickly to win more jobs</p>
                </div>
                <button
                  onClick={() => setActiveTab('leads')}
                  className="text-sm text-amber-600 hover:text-amber-700 flex items-center gap-1"
                >
                  View All
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="divide-y divide-neutral-200">
              {leads.filter(l => l.priority === 'high' && l.status === 'new').slice(0, 3).map(lead => (
                <div key={lead.id} className="p-6 hover:bg-neutral-50 transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <h4 className="text-neutral-900">{lead.customerName}</h4>
                        <span className="bg-red-100 text-red-700 text-xs px-2 py-0.5 rounded-full">
                          High Priority
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-sm text-neutral-600">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          {lead.city}
                        </span>
                        <span>{lead.flooringType}</span>
                        <span>{lead.sqFt} sq ft</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {lead.timeline}
                        </span>
                      </div>
                    </div>
                    <span className="text-lg text-green-600 font-medium">
                      ${lead.estimatedValue?.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <a
                      href={`tel:${lead.customerPhone}`}
                      className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2 text-sm"
                    >
                      <Phone className="w-4 h-4" />
                      Call Now
                    </a>
                    <button
                      onClick={() => handleMarkContacted(lead.id)}
                      className="bg-neutral-100 text-neutral-700 py-2 px-4 rounded-lg hover:bg-neutral-200 transition-colors text-sm"
                    >
                      Mark Contacted
                    </button>
                  </div>
                </div>
              ))}
              {leads.filter(l => l.priority === 'high' && l.status === 'new').length === 0 && (
                <div className="p-12 text-center">
                  <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-3" />
                  <p className="text-neutral-600">No high priority leads right now</p>
                  <p className="text-sm text-neutral-500 mt-1">Great job staying on top of everything!</p>
                </div>
              )}
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Performance Stats */}
            <div className="bg-white rounded-xl p-6 border border-neutral-200">
              <h3 className="text-neutral-900 mb-4">This Month</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-neutral-600">Leads Received</span>
                    <span className="text-sm text-neutral-900">{leads.length}</span>
                  </div>
                  <div className="w-full bg-neutral-200 rounded-full h-2">
                    <div className="bg-amber-600 h-2 rounded-full" style={{ width: '75%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-neutral-600">Leads Contacted</span>
                    <span className="text-sm text-neutral-900">{contactedLeadsCount}</span>
                  </div>
                  <div className="w-full bg-neutral-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: '60%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-neutral-600">Jobs Won</span>
                    <span className="text-sm text-neutral-900">3</span>
                  </div>
                  <div className="w-full bg-neutral-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '38%' }} />
                  </div>
                </div>
              </div>
            </div>

            {/* Plan Info */}
            <div className="bg-gradient-to-br from-neutral-900 to-neutral-800 rounded-xl p-6 text-white">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="text-white/70 text-sm mb-1">Your Plan</p>
                  <p className="text-2xl text-white capitalize">{profile.planType}</p>
                </div>
                <DollarSign className="w-8 h-8 text-white/50" />
              </div>
              <p className="text-sm text-white/80 mb-4">{getLeadLimitMessage()}</p>
              {profile.planType !== 'elite' && (
                <button className="w-full bg-white text-neutral-900 py-2.5 px-4 rounded-lg hover:bg-neutral-100 transition-colors text-sm font-medium">
                  Upgrade Plan
                </button>
              )}
            </div>

            {/* Recent Reviews */}
            <div className="bg-white rounded-xl p-6 border border-neutral-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-neutral-900">Recent Reviews</h3>
                <button
                  onClick={() => setActiveTab('reviews')}
                  className="text-sm text-amber-600 hover:text-amber-700"
                >
                  View All
                </button>
              </div>
              <div className="space-y-3">
                {reviews.slice(0, 2).map(review => (
                  <div key={review.id} className="pb-3 border-b border-neutral-200 last:border-0 last:pb-0">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3 h-3 ${
                              i < review.rating
                                ? 'fill-yellow-400 text-yellow-400'
                                : 'text-neutral-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-neutral-900">{review.customerName}</span>
                    </div>
                    <p className="text-sm text-neutral-600 line-clamp-2">{review.comment}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Upgrade Banner */}
        {profile.planType !== 'elite' && profile.planType !== 'pro' && (
          <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 rounded-2xl p-8 text-white relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent transform -skew-x-12" />
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row items-start gap-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm flex-shrink-0">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white text-xl mb-2">Unlock Unlimited Leads with Pro</h3>
                  <p className="text-white/90 mb-4">
                    Get unlimited leads, priority placement, and advanced filters. Just one job pays for a year of service!
                  </p>
                  <div className="flex flex-wrap gap-3">
                    <button className="bg-white text-amber-600 px-6 py-2.5 rounded-lg hover:bg-neutral-100 transition-colors font-medium">
                      Upgrade to Pro - $49/mo
                    </button>
                    <button className="bg-white/20 text-white px-6 py-2.5 rounded-lg hover:bg-white/30 transition-colors backdrop-blur-sm">
                      Compare Plans
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderLeads = () => {
    return (
      <div className="space-y-6">
        {/* Header with Stats */}
        <div className="bg-white rounded-xl p-6 border border-neutral-200">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <div>
              <h2 className="text-neutral-900 mb-1">Lead Inbox</h2>
              <p className="text-neutral-600">{newLeadsCount} new leads • {contactedLeadsCount} in progress</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-neutral-600">{getLeadLimitMessage()}</span>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-green-50 rounded-lg p-4 border border-green-200">
              <p className="text-sm text-green-700 mb-1">New</p>
              <p className="text-2xl text-green-900">{newLeadsCount}</p>
            </div>
            <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
              <p className="text-sm text-blue-700 mb-1">Contacted</p>
              <p className="text-2xl text-blue-900">{contactedLeadsCount}</p>
            </div>
            <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
              <p className="text-sm text-purple-700 mb-1">Est. Value</p>
              <p className="text-2xl text-purple-900">${(totalEstimatedValue / 1000).toFixed(0)}K</p>
            </div>
            <div className="bg-amber-50 rounded-lg p-4 border border-amber-200">
              <p className="text-sm text-amber-700 mb-1">This Week</p>
              <p className="text-2xl text-amber-900">+{weeklyLeads}</p>
            </div>
          </div>
        </div>

        {/* Filters & Search */}
        <div className="bg-white rounded-xl p-6 border border-neutral-200">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="w-5 h-5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name, city, or flooring type..."
                className="w-full pl-10 pr-4 py-2.5 border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600"
              />
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setLeadFilter('all')}
                className={`px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  leadFilter === 'all'
                    ? 'bg-amber-600 text-white'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                All ({leads.length})
              </button>
              <button
                onClick={() => setLeadFilter('new')}
                className={`px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  leadFilter === 'new'
                    ? 'bg-amber-600 text-white'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                New ({newLeadsCount})
              </button>
              <button
                onClick={() => setLeadFilter('contacted')}
                className={`px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  leadFilter === 'contacted'
                    ? 'bg-amber-600 text-white'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                Contacted ({contactedLeadsCount})
              </button>
            </div>
          </div>
        </div>

        {/* Leads List */}
        <div className="space-y-4">
          {filteredLeads.map(lead => (
            <div key={lead.id} className="bg-white rounded-xl border-2 border-neutral-200 hover:border-amber-600 transition-all overflow-hidden">
              <div className="p-6">
                {/* Lead Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <h3 className="text-neutral-900 text-lg">{lead.customerName}</h3>
                      <span className={`text-xs px-2 py-1 rounded-full border ${
                        lead.status === 'new' ? 'bg-green-100 text-green-700 border-green-200' :
                        lead.status === 'contacted' ? 'bg-blue-100 text-blue-700 border-blue-200' :
                        'bg-neutral-100 text-neutral-700 border-neutral-200'
                      }`}>
                        {lead.status}
                      </span>
                      {lead.priority && (
                        <span className={`text-xs px-2 py-1 rounded-full border ${getPriorityColor(lead.priority)}`}>
                          {lead.priority} priority
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-neutral-600 mb-3">
                      <Calendar className="w-4 h-4 inline mr-1" />
                      Received {new Date(lead.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-neutral-600 mb-1">Est. Value</p>
                    <p className="text-2xl text-green-600 font-medium">
                      ${lead.estimatedValue?.toLocaleString()}
                    </p>
                  </div>
                </div>

                {/* Lead Details Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 p-4 bg-neutral-50 rounded-lg">
                  <div>
                    <p className="text-xs text-neutral-600 mb-1">Flooring Type</p>
                    <p className="text-sm text-neutral-900 font-medium">{lead.flooringType}</p>
                  </div>
                  <div>
                    <p className="text-xs text-neutral-600 mb-1">Square Feet</p>
                    <p className="text-sm text-neutral-900 font-medium">{lead.sqFt.toLocaleString()} sq ft</p>
                  </div>
                  <div>
                    <p className="text-xs text-neutral-600 mb-1">Location</p>
                    <p className="text-sm text-neutral-900 font-medium">{lead.city}</p>
                  </div>
                  <div>
                    <p className="text-xs text-neutral-600 mb-1">Timeline</p>
                    <p className="text-sm text-neutral-900 font-medium">{lead.timeline}</p>
                  </div>
                </div>

                {/* Contact Info */}
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4">
                  <p className="text-xs text-amber-800 mb-2 font-medium">Contact Information</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-amber-600" />
                      <span className="text-sm text-neutral-900">{lead.customerPhone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-amber-600" />
                      <span className="text-sm text-neutral-900">{lead.customerEmail}</span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-2">
                  <a
                    href={`tel:${lead.customerPhone}`}
                    className="flex-1 min-w-[140px] bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2 font-medium"
                  >
                    <Phone className="w-4 h-4" />
                    Call Now
                  </a>
                  <a
                    href={`sms:${lead.customerPhone}`}
                    className="flex-1 min-w-[140px] bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 font-medium"
                  >
                    <MessageSquare className="w-4 h-4" />
                    Send Text
                  </a>
                  <a
                    href={`mailto:${lead.customerEmail}`}
                    className="flex-1 min-w-[140px] bg-amber-600 text-white py-3 px-4 rounded-lg hover:bg-amber-700 transition-colors flex items-center justify-center gap-2 font-medium"
                  >
                    <Mail className="w-4 h-4" />
                    Send Email
                  </a>
                  {lead.status === 'new' && (
                    <button
                      onClick={() => handleMarkContacted(lead.id)}
                      className="flex-1 min-w-[140px] bg-neutral-600 text-white py-3 px-4 rounded-lg hover:bg-neutral-700 transition-colors flex items-center justify-center gap-2 font-medium"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Mark Contacted
                    </button>
                  )}
                  {lead.status === 'contacted' && (
                    <button
                      onClick={() => handleMarkClosed(lead.id)}
                      className="flex-1 min-w-[140px] bg-purple-600 text-white py-3 px-4 rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center gap-2 font-medium"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Mark as Won
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredLeads.length === 0 && (
          <div className="bg-white rounded-xl p-12 text-center border border-neutral-200">
            <Mail className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
            <h3 className="text-neutral-900 mb-2">No leads found</h3>
            <p className="text-neutral-600 mb-6">
              {searchQuery ? 'Try adjusting your search' : 'New leads will appear here as homeowners request quotes'}
            </p>
            {profile.planType === 'free' && (
              <button className="bg-amber-600 text-white px-6 py-3 rounded-lg hover:bg-amber-700 transition-colors">
                Upgrade to Start Receiving Leads
              </button>
            )}
          </div>
        )}
      </div>
    );
  };

  const renderReviews = () => {
    return (
      <div className="space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl p-6 border border-neutral-200">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-neutral-900 mb-1">Customer Reviews</h2>
              <p className="text-neutral-600">{reviews.length} total reviews • {averageRating.toFixed(1)} average rating</p>
            </div>
          </div>

          {/* Rating Summary */}
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <div className="text-center md:text-left">
              <p className="text-5xl text-neutral-900 mb-2">{averageRating.toFixed(1)}</p>
              <div className="flex items-center gap-1 justify-center md:justify-start mb-2">
                {[1, 2, 3, 4, 5].map(star => (
                  <Star
                    key={star}
                    className={`w-5 h-5 ${
                      star <= Math.round(averageRating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-neutral-300'
                    }`}
                  />
                ))}
              </div>
              <p className="text-sm text-neutral-600">{reviews.length} reviews</p>
            </div>

            <div className="flex-1 space-y-2 w-full">
              {[5, 4, 3, 2, 1].map(rating => {
                const count = reviews.filter(r => r.rating === rating).length;
                const percentage = (count / reviews.length) * 100;
                return (
                  <div key={rating} className="flex items-center gap-3">
                    <span className="text-sm text-neutral-600 w-8">{rating}★</span>
                    <div className="flex-1 bg-neutral-200 rounded-full h-2">
                      <div
                        className="bg-yellow-400 h-2 rounded-full transition-all"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <span className="text-sm text-neutral-600 w-8 text-right">{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Reviews List */}
        <div className="space-y-4">
          {reviews.map(review => (
            <div key={review.id} className="bg-white rounded-xl p-6 border border-neutral-200 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <p className="text-neutral-900 font-medium">{review.customerName}</p>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map(star => (
                        <Star
                          key={star}
                          className={`w-4 h-4 ${
                            star <= review.rating
                              ? 'fill-yellow-400 text-yellow-400'
                              : 'text-neutral-300'
                          }`}
                        />
                      ))}
                    </div>
                    {review.flooringType && (
                      <span className="text-xs bg-neutral-100 text-neutral-700 px-2 py-1 rounded">
                        {review.flooringType}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-neutral-600">{new Date(review.createdAt).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
                </div>
              </div>

              <p className="text-neutral-700 mb-4 leading-relaxed">{review.comment}</p>

              {/* Contractor Reply */}
              {review.reply ? (
                <div className="bg-amber-50 rounded-lg p-4 border-l-4 border-amber-600">
                  <p className="text-sm text-amber-800 font-medium mb-1">Your reply:</p>
                  <p className="text-neutral-900">{review.reply}</p>
                </div>
              ) : (
                <div className="space-y-2">
                  <textarea
                    value={replyText[review.id] || ''}
                    onChange={(e) => setReplyText({ ...replyText, [review.id]: e.target.value })}
                    className="w-full border border-neutral-200 rounded-lg p-3 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                    placeholder="Reply to this review..."
                    rows={2}
                  />
                  <button
                    onClick={() => handleReplyToReview(review.id)}
                    disabled={!replyText[review.id]?.trim()}
                    className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors text-sm disabled:opacity-50 disabled:cursor-not-allowed font-medium"
                  >
                    Post Reply
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {reviews.length === 0 && (
          <div className="bg-white rounded-xl p-12 text-center border border-neutral-200">
            <Star className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
            <h3 className="text-neutral-900 mb-2">No reviews yet</h3>
            <p className="text-neutral-600">
              Customer reviews will appear here after you complete jobs. Great reviews help you win more leads!
            </p>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <div className="bg-white border-b border-neutral-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-neutral-900">Floor Master Solutions</h1>
            <div className="flex items-center gap-4">
              <span className="text-sm text-neutral-600 hidden sm:inline">{profile.companyName}</span>
              <button className="text-sm text-amber-600 hover:text-amber-700">
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-neutral-200 sticky top-[73px] z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex gap-4 sm:gap-6 overflow-x-auto">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`py-4 px-2 border-b-2 transition-colors whitespace-nowrap ${
                activeTab === 'dashboard'
                  ? 'border-amber-600 text-amber-600'
                  : 'border-transparent text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => setActiveTab('leads')}
              className={`py-4 px-2 border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
                activeTab === 'leads'
                  ? 'border-amber-600 text-amber-600'
                  : 'border-transparent text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Lead Inbox
              {newLeadsCount > 0 && (
                <span className="bg-green-600 text-white text-xs px-2 py-0.5 rounded-full">
                  {newLeadsCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className={`py-4 px-2 border-b-2 transition-colors whitespace-nowrap ${
                activeTab === 'reviews'
                  ? 'border-amber-600 text-amber-600'
                  : 'border-transparent text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Reviews
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {activeTab === 'dashboard' && renderDashboard()}
        {activeTab === 'leads' && renderLeads()}
        {activeTab === 'reviews' && renderReviews()}
      </div>
    </div>
  );
}
