export function LeadsList() {
  const leads = [
    {
      id: '1',
      name: 'Amanda Peterson',
      email: 'amanda@email.com',
      phone: '(555) 234-5678',
      flooringType: 'Hardwood',
      message: 'Looking to install hardwood in my living room and dining room. Approximately 600 sq ft total.',
      status: 'New',
      date: '2024-12-17 10:30 AM',
      source: 'Website'
    },
    {
      id: '2',
      name: 'Marcus Thompson',
      email: 'marcus@email.com',
      phone: '(555) 345-6789',
      flooringType: 'LVP',
      message: 'Need waterproof flooring for my basement. About 800 sq ft. Looking for quick turnaround.',
      status: 'Contacted',
      date: '2024-12-16 3:15 PM',
      source: 'Referral'
    },
    {
      id: '3',
      name: 'Lisa Chen',
      email: 'lisa@email.com',
      phone: '(555) 456-7890',
      flooringType: 'Tile',
      message: 'Interested in tile for kitchen and two bathrooms. Would like a quote and timeline.',
      status: 'New',
      date: '2024-12-16 11:45 AM',
      source: 'Website'
    },
    {
      id: '4',
      name: 'Daniel Rodriguez',
      email: 'daniel@email.com',
      phone: '(555) 567-8901',
      flooringType: 'Carpet',
      message: 'Need carpet replacement in 3 bedrooms. High-quality, pet-friendly options preferred.',
      status: 'Quoted',
      date: '2024-12-15 2:20 PM',
      source: 'Website'
    },
    {
      id: '5',
      name: 'Karen Mitchell',
      email: 'karen@email.com',
      phone: '(555) 678-9012',
      flooringType: 'Engineered Wood',
      message: 'Replacing laminate with engineered wood. Main floor of house, roughly 1000 sq ft.',
      status: 'Contacted',
      date: '2024-12-15 9:00 AM',
      source: 'Social Media'
    }
  ];

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        <div className="mb-8">
          <h1 className="text-neutral-900 mb-2">Customer Leads</h1>
          <p className="text-neutral-600">Manage incoming customer requests and inquiries</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-neutral-600 text-sm">New Leads</span>
              <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center">
                <svg className="w-4 h-4 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </div>
            </div>
            <p className="text-neutral-900">{leads.filter(l => l.status === 'New').length}</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-neutral-600 text-sm">Contacted</span>
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                <svg className="w-4 h-4 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </div>
            </div>
            <p className="text-neutral-900">{leads.filter(l => l.status === 'Contacted').length}</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-neutral-600 text-sm">Quoted</span>
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                <svg className="w-4 h-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
            </div>
            <p className="text-neutral-900">{leads.filter(l => l.status === 'Quoted').length}</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-neutral-600 text-sm">Total Leads</span>
              <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                <svg className="w-4 h-4 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
            </div>
            <p className="text-neutral-900">{leads.length}</p>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl p-4 shadow-sm mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-neutral-700 mb-2 text-sm">Status</label>
              <select className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent text-sm">
                <option>All Statuses</option>
                <option>New</option>
                <option>Contacted</option>
                <option>Quoted</option>
                <option>Converted</option>
                <option>Lost</option>
              </select>
            </div>
            <div>
              <label className="block text-neutral-700 mb-2 text-sm">Source</label>
              <select className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent text-sm">
                <option>All Sources</option>
                <option>Website</option>
                <option>Referral</option>
                <option>Social Media</option>
                <option>Other</option>
              </select>
            </div>
            <div>
              <label className="block text-neutral-700 mb-2 text-sm">Sort By</label>
              <select className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent text-sm">
                <option>Newest First</option>
                <option>Oldest First</option>
                <option>Status</option>
              </select>
            </div>
          </div>
        </div>

        {/* Leads List */}
        <div className="space-y-4">
          {leads.map((lead) => (
            <div key={lead.id} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-neutral-900">{lead.name}</h3>
                    <span className={`px-3 py-1 rounded-full text-xs ${
                      lead.status === 'New' ? 'bg-amber-100 text-amber-700' :
                      lead.status === 'Contacted' ? 'bg-blue-100 text-blue-700' :
                      lead.status === 'Quoted' ? 'bg-green-100 text-green-700' :
                      'bg-neutral-100 text-neutral-700'
                    }`}>
                      {lead.status}
                    </span>
                    <span className="px-3 py-1 bg-neutral-100 text-neutral-600 rounded-full text-xs">
                      {lead.source}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-4 text-sm text-neutral-600 mb-3">
                    <div className="flex items-center gap-1">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                      </svg>
                      {lead.email}
                    </div>
                    <div className="flex items-center gap-1">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                      </svg>
                      {lead.phone}
                    </div>
                    <div className="flex items-center gap-1">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      {lead.date}
                    </div>
                  </div>
                  <div className="mb-3">
                    <span className="inline-flex px-3 py-1 bg-amber-50 text-amber-700 rounded-lg text-sm">
                      Interested in: {lead.flooringType}
                    </span>
                  </div>
                  <p className="text-neutral-600 text-sm bg-neutral-50 p-3 rounded-lg">
                    {lead.message}
                  </p>
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-neutral-100">
                <button className="px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors text-sm">
                  Contact Customer
                </button>
                <button className="px-4 py-2 border border-neutral-300 text-neutral-700 rounded-lg hover:bg-neutral-50 transition-colors text-sm">
                  Create Estimate
                </button>
                <button className="px-4 py-2 text-neutral-600 hover:text-neutral-900 transition-colors text-sm">
                  Mark as Quoted
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
