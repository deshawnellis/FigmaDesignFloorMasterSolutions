interface EstimatesListProps {
  onCreateNew: () => void;
}

export function EstimatesList({ onCreateNew }: EstimatesListProps) {
  const estimates = [
    { id: '1', customer: 'Sarah Johnson', email: 'sarah@email.com', flooring: 'Hardwood', area: 1200, amount: 14400, status: 'Sent', date: '2024-12-16' },
    { id: '2', customer: 'Michael Chen', email: 'michael@email.com', flooring: 'LVP', area: 800, amount: 4800, status: 'Viewed', date: '2024-12-15' },
    { id: '3', customer: 'Emily Davis', email: 'emily@email.com', flooring: 'Tile', area: 450, amount: 6750, status: 'Accepted', date: '2024-12-14' },
    { id: '4', customer: 'David Martinez', email: 'david@email.com', flooring: 'Carpet', area: 600, amount: 3600, status: 'Sent', date: '2024-12-13' },
    { id: '5', customer: 'Jennifer Williams', email: 'jennifer@email.com', flooring: 'Engineered Wood', area: 950, amount: 9500, status: 'Declined', date: '2024-12-12' },
    { id: '6', customer: 'Robert Thompson', email: 'robert@email.com', flooring: 'Laminate', area: 700, amount: 3500, status: 'Accepted', date: '2024-12-11' }
  ];

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-neutral-900 mb-2">Estimates</h1>
            <p className="text-neutral-600">Manage and track all your project estimates</p>
          </div>
          <button
            onClick={onCreateNew}
            className="bg-amber-600 text-white px-6 py-3 rounded-lg hover:bg-amber-700 transition-colors flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
            New Estimate
          </button>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl p-4 shadow-sm mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-neutral-700 mb-2 text-sm">Status</label>
              <select className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent text-sm">
                <option>All Statuses</option>
                <option>Sent</option>
                <option>Viewed</option>
                <option>Accepted</option>
                <option>Declined</option>
              </select>
            </div>
            <div>
              <label className="block text-neutral-700 mb-2 text-sm">Flooring Type</label>
              <select className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent text-sm">
                <option>All Types</option>
                <option>Hardwood</option>
                <option>LVP</option>
                <option>Tile</option>
                <option>Carpet</option>
                <option>Laminate</option>
                <option>Engineered Wood</option>
              </select>
            </div>
            <div>
              <label className="block text-neutral-700 mb-2 text-sm">Date Range</label>
              <select className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent text-sm">
                <option>Last 30 Days</option>
                <option>Last 7 Days</option>
                <option>Last 90 Days</option>
                <option>All Time</option>
              </select>
            </div>
            <div>
              <label className="block text-neutral-700 mb-2 text-sm">Sort By</label>
              <select className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent text-sm">
                <option>Newest First</option>
                <option>Oldest First</option>
                <option>Highest Amount</option>
                <option>Lowest Amount</option>
              </select>
            </div>
          </div>
        </div>

        {/* Estimates Table */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-neutral-50 border-b border-neutral-200">
                <tr>
                  <th className="px-6 py-4 text-left text-neutral-700">Customer</th>
                  <th className="px-6 py-4 text-left text-neutral-700">Flooring Type</th>
                  <th className="px-6 py-4 text-left text-neutral-700">Area</th>
                  <th className="px-6 py-4 text-left text-neutral-700">Amount</th>
                  <th className="px-6 py-4 text-left text-neutral-700">Status</th>
                  <th className="px-6 py-4 text-left text-neutral-700">Date</th>
                  <th className="px-6 py-4 text-left text-neutral-700">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {estimates.map((estimate) => (
                  <tr key={estimate.id} className="hover:bg-neutral-50 transition-colors">
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-neutral-900">{estimate.customer}</p>
                        <p className="text-neutral-600 text-sm">{estimate.email}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-neutral-700">{estimate.flooring}</td>
                    <td className="px-6 py-4 text-neutral-700">{estimate.area} sq ft</td>
                    <td className="px-6 py-4 text-neutral-900">
                      ${estimate.amount.toLocaleString()}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex px-3 py-1 rounded-full text-sm ${
                        estimate.status === 'Accepted' ? 'bg-green-100 text-green-700' :
                        estimate.status === 'Viewed' ? 'bg-blue-100 text-blue-700' :
                        estimate.status === 'Declined' ? 'bg-red-100 text-red-700' :
                        'bg-neutral-100 text-neutral-700'
                      }`}>
                        {estimate.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-neutral-600 text-sm">
                      {new Date(estimate.date).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <button className="text-amber-600 hover:text-amber-700 text-sm">
                          View
                        </button>
                        <button className="text-neutral-600 hover:text-neutral-900 text-sm">
                          Edit
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-6">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <p className="text-neutral-600 text-sm mb-1">Total Estimates</p>
            <p className="text-neutral-900">{estimates.length}</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-6">
            <p className="text-neutral-600 text-sm mb-1">Accepted</p>
            <p className="text-green-600">
              {estimates.filter(e => e.status === 'Accepted').length}
            </p>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-6">
            <p className="text-neutral-600 text-sm mb-1">Pending</p>
            <p className="text-blue-600">
              {estimates.filter(e => e.status === 'Sent' || e.status === 'Viewed').length}
            </p>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-6">
            <p className="text-neutral-600 text-sm mb-1">Total Value</p>
            <p className="text-neutral-900">
              ${estimates.reduce((sum, e) => sum + e.amount, 0).toLocaleString()}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
