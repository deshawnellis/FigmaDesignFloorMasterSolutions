import { useState } from 'react';

interface ScheduledItem {
  id: string;
  type: 'estimate' | 'job' | 'consultation';
  title: string;
  client: string;
  date: string;
  time: string;
  status: 'scheduled' | 'in-progress' | 'completed' | 'cancelled';
  location: string;
  notes?: string;
  value?: string;
}

interface ContractorCalendarProps {
  scheduledItems: ScheduledItem[];
  onAddItem: (item: Omit<ScheduledItem, 'id'>) => void;
}

export function ContractorCalendar({ scheduledItems, onAddItem }: ContractorCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState<'month' | 'week' | 'day'>('month');
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days: (Date | null)[] = [];

    // Add empty slots for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }

    // Add all days of the month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i));
    }

    return days;
  };

  const getItemsForDate = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return scheduledItems.filter(item => item.date === dateStr);
  };

  const isToday = (date: Date) => {
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  const isSameMonth = (date: Date) => {
    return date.getMonth() === currentDate.getMonth();
  };

  const goToPreviousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const goToNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'estimate':
        return 'bg-blue-500';
      case 'job':
        return 'bg-green-500';
      case 'consultation':
        return 'bg-purple-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'scheduled':
        return 'bg-blue-100 text-blue-700';
      case 'in-progress':
        return 'bg-amber-100 text-amber-700';
      case 'completed':
        return 'bg-green-100 text-green-700';
      case 'cancelled':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const days = getDaysInMonth(currentDate);

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-neutral-900 mb-2">Schedule & Calendar</h1>
              <p className="text-neutral-600">
                Manage your estimates, jobs, and appointments
              </p>
            </div>
            <button
              onClick={() => setShowAddModal(true)}
              className="bg-amber-600 text-white px-6 py-3 rounded-xl hover:bg-amber-700 transition-colors flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Add to Schedule
            </button>
          </div>
        </div>

        {/* Calendar Controls */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-4">
              <button
                onClick={goToPreviousMonth}
                className="p-2 hover:bg-neutral-100 rounded-lg transition-colors"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h2 className="text-neutral-900">
                {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
              </h2>
              <button
                onClick={goToNextMonth}
                className="p-2 hover:bg-neutral-100 rounded-lg transition-colors"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
              <button
                onClick={goToToday}
                className="px-4 py-2 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors text-sm"
              >
                Today
              </button>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setView('month')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  view === 'month'
                    ? 'bg-amber-600 text-white'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                Month
              </button>
              <button
                onClick={() => setView('week')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  view === 'week'
                    ? 'bg-amber-600 text-white'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                Week
              </button>
              <button
                onClick={() => setView('day')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  view === 'day'
                    ? 'bg-amber-600 text-white'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                Day
              </button>
            </div>
          </div>
        </div>

        {/* Calendar Grid */}
        {view === 'month' && (
          <div className="bg-white rounded-2xl shadow-sm p-6">
            {/* Day Headers */}
            <div className="grid grid-cols-7 gap-2 mb-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                <div key={day} className="text-center text-neutral-600 py-2">
                  {day}
                </div>
              ))}
            </div>

            {/* Calendar Days */}
            <div className="grid grid-cols-7 gap-2">
              {days.map((day, index) => {
                if (!day) {
                  return <div key={`empty-${index}`} className="aspect-square" />;
                }

                const items = getItemsForDate(day);
                const today = isToday(day);
                const sameMonth = isSameMonth(day);

                return (
                  <button
                    key={index}
                    onClick={() => setSelectedDate(day)}
                    className={`aspect-square border rounded-xl p-2 hover:border-amber-600 transition-all ${
                      today ? 'bg-amber-50 border-amber-600' : 'border-neutral-200'
                    } ${!sameMonth ? 'opacity-40' : ''}`}
                  >
                    <div className="flex flex-col h-full">
                      <span
                        className={`text-sm ${
                          today ? 'text-amber-600' : 'text-neutral-900'
                        }`}
                      >
                        {day.getDate()}
                      </span>
                      <div className="flex-1 overflow-hidden mt-1">
                        {items.slice(0, 3).map((item) => (
                          <div
                            key={item.id}
                            className={`${getTypeColor(item.type)} rounded text-white text-xs px-1 py-0.5 mb-1 truncate`}
                          >
                            {item.time}
                          </div>
                        ))}
                        {items.length > 3 && (
                          <div className="text-xs text-neutral-500">
                            +{items.length - 3} more
                          </div>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Week View Placeholder */}
        {view === 'week' && (
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <p className="text-neutral-600 text-center py-12">Week view coming soon...</p>
          </div>
        )}

        {/* Day View Placeholder */}
        {view === 'day' && (
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <p className="text-neutral-600 text-center py-12">Day view coming soon...</p>
          </div>
        )}

        {/* Upcoming Schedule */}
        <div className="mt-6 bg-white rounded-2xl shadow-sm p-6">
          <h3 className="text-neutral-900 mb-4">Upcoming Schedule</h3>
          <div className="space-y-4">
            {scheduledItems
              .filter((item) => new Date(item.date) >= new Date())
              .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
              .slice(0, 5)
              .map((item) => (
                <div
                  key={item.id}
                  className="flex items-start gap-4 p-4 border border-neutral-200 rounded-xl hover:border-amber-600 transition-colors"
                >
                  <div className={`w-3 h-3 ${getTypeColor(item.type)} rounded-full mt-1.5`} />
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="text-neutral-900 mb-1">{item.title}</h4>
                        <p className="text-neutral-600 text-sm">{item.client}</p>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-xs ${getStatusBadge(
                          item.status
                        )}`}
                      >
                        {item.status}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-4 text-sm text-neutral-600">
                      <div className="flex items-center gap-1">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        {new Date(item.date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        {item.time}
                      </div>
                      <div className="flex items-center gap-1">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        {item.location}
                      </div>
                      {item.value && (
                        <div className="flex items-center gap-1">
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          {item.value}
                        </div>
                      )}
                    </div>
                    {item.notes && (
                      <p className="text-neutral-600 text-sm mt-2">{item.notes}</p>
                    )}
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>

      {/* Add Item Modal */}
      {showAddModal && (
        <AddScheduleModal
          onClose={() => setShowAddModal(false)}
          onAdd={(item) => {
            onAddItem(item);
            setShowAddModal(false);
          }}
        />
      )}
    </div>
  );
}

interface AddScheduleModalProps {
  onClose: () => void;
  onAdd: (item: Omit<ScheduledItem, 'id'>) => void;
}

function AddScheduleModal({ onClose, onAdd }: AddScheduleModalProps) {
  const [formData, setFormData] = useState({
    type: 'estimate' as 'estimate' | 'job' | 'consultation',
    title: '',
    client: '',
    date: '',
    time: '',
    status: 'scheduled' as 'scheduled' | 'in-progress' | 'completed' | 'cancelled',
    location: '',
    notes: '',
    value: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-neutral-200">
          <div className="flex items-center justify-between">
            <h2 className="text-neutral-900">Add to Schedule</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-neutral-100 rounded-lg transition-colors"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="text-neutral-900 mb-2 block">Type</label>
            <select
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
              className="w-full px-4 py-3 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600"
              required
            >
              <option value="estimate">Estimate</option>
              <option value="job">Job</option>
              <option value="consultation">Consultation</option>
            </select>
          </div>

          <div>
            <label className="text-neutral-900 mb-2 block">Title</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-4 py-3 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600"
              placeholder="Kitchen hardwood installation"
              required
            />
          </div>

          <div>
            <label className="text-neutral-900 mb-2 block">Client Name</label>
            <input
              type="text"
              value={formData.client}
              onChange={(e) => setFormData({ ...formData, client: e.target.value })}
              className="w-full px-4 py-3 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600"
              placeholder="John Smith"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-neutral-900 mb-2 block">Date</label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full px-4 py-3 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600"
                required
              />
            </div>
            <div>
              <label className="text-neutral-900 mb-2 block">Time</label>
              <input
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                className="w-full px-4 py-3 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-neutral-900 mb-2 block">Location</label>
            <input
              type="text"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="w-full px-4 py-3 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600"
              placeholder="123 Main St, San Francisco, CA"
              required
            />
          </div>

          <div>
            <label className="text-neutral-900 mb-2 block">Estimated Value (Optional)</label>
            <input
              type="text"
              value={formData.value}
              onChange={(e) => setFormData({ ...formData, value: e.target.value })}
              className="w-full px-4 py-3 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600"
              placeholder="$5,000"
            />
          </div>

          <div>
            <label className="text-neutral-900 mb-2 block">Notes (Optional)</label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full px-4 py-3 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600"
              rows={3}
              placeholder="Additional details about this appointment..."
            />
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-neutral-200 rounded-xl hover:bg-neutral-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-3 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors"
            >
              Add to Schedule
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
