import { useState } from 'react';

interface CreateEstimateProps {
  onBack: () => void;
}

export function CreateEstimate({ onBack }: CreateEstimateProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    customerName: '',
    customerEmail: '',
    customerPhone: '',
    flooringType: '',
    roomLength: '',
    roomWidth: '',
    laborRate: '8',
    materialCost: '',
    wasteFactor: '10',
    additionalCosts: ''
  });

  const calculateArea = () => {
    const length = parseFloat(formData.roomLength) || 0;
    const width = parseFloat(formData.roomWidth) || 0;
    return length * width;
  };

  const calculateTotalArea = () => {
    const baseArea = calculateArea();
    const wasteFactor = parseFloat(formData.wasteFactor) || 0;
    return baseArea * (1 + wasteFactor / 100);
  };

  const calculateMaterialCost = () => {
    const totalArea = calculateTotalArea();
    const costPerSqFt = parseFloat(formData.materialCost) || 0;
    return totalArea * costPerSqFt;
  };

  const calculateLaborCost = () => {
    const totalArea = calculateTotalArea();
    const laborRate = parseFloat(formData.laborRate) || 0;
    return totalArea * laborRate;
  };

  const calculateTotal = () => {
    const materialCost = calculateMaterialCost();
    const laborCost = calculateLaborCost();
    const additional = parseFloat(formData.additionalCosts) || 0;
    return materialCost + laborCost + additional;
  };

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
  };

  const handlePrevious = () => {
    if (step > 1) setStep(step - 1);
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-4xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Estimates
          </button>
          <h1 className="text-neutral-900 mb-2">Create New Estimate</h1>
          <p className="text-neutral-600">Generate a professional flooring estimate</p>
        </div>

        {/* Progress Steps */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-2">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center flex-1">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  step >= s ? 'bg-amber-600 text-white' : 'bg-neutral-200 text-neutral-500'
                }`}>
                  {s}
                </div>
                {s < 3 && (
                  <div className={`flex-1 h-1 mx-2 ${
                    step > s ? 'bg-amber-600' : 'bg-neutral-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-sm text-neutral-600 mt-2">
            <span>Customer Info</span>
            <span>Measurements</span>
            <span>Review & Send</span>
          </div>
        </div>

        {/* Form Content */}
        <div className="bg-white rounded-xl shadow-sm p-8">
          {step === 1 && (
            <div className="space-y-6">
              <h2 className="text-neutral-900 mb-6">Customer Information</h2>
              
              <div>
                <label className="block text-neutral-700 mb-2">Customer Name *</label>
                <input
                  type="text"
                  value={formData.customerName}
                  onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                  className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                  placeholder="John Doe"
                />
              </div>

              <div>
                <label className="block text-neutral-700 mb-2">Email Address *</label>
                <input
                  type="email"
                  value={formData.customerEmail}
                  onChange={(e) => setFormData({ ...formData, customerEmail: e.target.value })}
                  className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                  placeholder="john@example.com"
                />
              </div>

              <div>
                <label className="block text-neutral-700 mb-2">Phone Number *</label>
                <input
                  type="tel"
                  value={formData.customerPhone}
                  onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                  className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                  placeholder="(555) 123-4567"
                />
              </div>

              <div>
                <label className="block text-neutral-700 mb-2">Flooring Type *</label>
                <select
                  value={formData.flooringType}
                  onChange={(e) => setFormData({ ...formData, flooringType: e.target.value })}
                  className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                >
                  <option value="">Select flooring type...</option>
                  <option value="hardwood">Hardwood</option>
                  <option value="lvp">Luxury Vinyl Plank (LVP)</option>
                  <option value="tile">Tile</option>
                  <option value="carpet">Carpet</option>
                  <option value="laminate">Laminate</option>
                  <option value="engineered">Engineered Wood</option>
                </select>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h2 className="text-neutral-900 mb-6">Measurements & Pricing</h2>
              
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div>
                    <p className="text-amber-900 text-sm">
                      Enter room dimensions in feet. The waste factor accounts for cuts and mistakes.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-neutral-700 mb-2">Room Length (ft) *</label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.roomLength}
                    onChange={(e) => setFormData({ ...formData, roomLength: e.target.value })}
                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                    placeholder="20"
                  />
                </div>
                <div>
                  <label className="block text-neutral-700 mb-2">Room Width (ft) *</label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.roomWidth}
                    onChange={(e) => setFormData({ ...formData, roomWidth: e.target.value })}
                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                    placeholder="15"
                  />
                </div>
              </div>

              <div className="bg-neutral-50 rounded-lg p-4">
                <p className="text-neutral-600 text-sm">Base Area: <span className="text-neutral-900">{calculateArea().toFixed(2)} sq ft</span></p>
              </div>

              <div>
                <label className="block text-neutral-700 mb-2">Waste Factor (%) *</label>
                <input
                  type="number"
                  step="1"
                  value={formData.wasteFactor}
                  onChange={(e) => setFormData({ ...formData, wasteFactor: e.target.value })}
                  className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                  placeholder="10"
                />
                <p className="text-neutral-600 text-sm mt-1">Recommended: 10% for standard rooms, 15% for complex layouts</p>
              </div>

              <div className="bg-neutral-50 rounded-lg p-4">
                <p className="text-neutral-600 text-sm">Total Area (with waste): <span className="text-neutral-900">{calculateTotalArea().toFixed(2)} sq ft</span></p>
              </div>

              <div>
                <label className="block text-neutral-700 mb-2">Material Cost (per sq ft) *</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500">$</span>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.materialCost}
                    onChange={(e) => setFormData({ ...formData, materialCost: e.target.value })}
                    className="w-full pl-8 pr-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                    placeholder="5.00"
                  />
                </div>
              </div>

              <div>
                <label className="block text-neutral-700 mb-2">Labor Rate (per sq ft) *</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500">$</span>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.laborRate}
                    onChange={(e) => setFormData({ ...formData, laborRate: e.target.value })}
                    className="w-full pl-8 pr-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                    placeholder="8.00"
                  />
                </div>
              </div>

              <div>
                <label className="block text-neutral-700 mb-2">Additional Costs (optional)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500">$</span>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.additionalCosts}
                    onChange={(e) => setFormData({ ...formData, additionalCosts: e.target.value })}
                    className="w-full pl-8 pr-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                    placeholder="0.00"
                  />
                </div>
                <p className="text-neutral-600 text-sm mt-1">e.g., removal of old flooring, subfloor repair, trim work</p>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <h2 className="text-neutral-900 mb-6">Review Estimate</h2>
              
              {/* Customer Info Summary */}
              <div className="border border-neutral-200 rounded-lg p-6">
                <h3 className="text-neutral-900 mb-4">Customer Details</h3>
                <div className="space-y-2 text-sm">
                  <p className="text-neutral-600">Name: <span className="text-neutral-900">{formData.customerName}</span></p>
                  <p className="text-neutral-600">Email: <span className="text-neutral-900">{formData.customerEmail}</span></p>
                  <p className="text-neutral-600">Phone: <span className="text-neutral-900">{formData.customerPhone}</span></p>
                  <p className="text-neutral-600">Flooring: <span className="text-neutral-900 capitalize">{formData.flooringType}</span></p>
                </div>
              </div>

              {/* Cost Breakdown */}
              <div className="border border-neutral-200 rounded-lg p-6">
                <h3 className="text-neutral-900 mb-4">Cost Breakdown</h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-neutral-600">Base Area:</span>
                    <span className="text-neutral-900">{calculateArea().toFixed(2)} sq ft</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-neutral-600">Waste Factor ({formData.wasteFactor}%):</span>
                    <span className="text-neutral-900">{(calculateTotalArea() - calculateArea()).toFixed(2)} sq ft</span>
                  </div>
                  <div className="flex justify-between text-sm pt-2 border-t border-neutral-200">
                    <span className="text-neutral-600">Total Area:</span>
                    <span className="text-neutral-900">{calculateTotalArea().toFixed(2)} sq ft</span>
                  </div>
                  <div className="flex justify-between pt-4 border-t border-neutral-200">
                    <span className="text-neutral-600">Materials:</span>
                    <span className="text-neutral-900">${calculateMaterialCost().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-600">Labor:</span>
                    <span className="text-neutral-900">${calculateLaborCost().toFixed(2)}</span>
                  </div>
                  {parseFloat(formData.additionalCosts) > 0 && (
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Additional Costs:</span>
                      <span className="text-neutral-900">${parseFloat(formData.additionalCosts).toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between pt-4 border-t-2 border-neutral-300">
                    <span className="text-neutral-900">Total Estimate:</span>
                    <span className="text-neutral-900">${calculateTotal().toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div>
                    <p className="text-green-900 text-sm">
                      Your estimate is ready! Click "Send Estimate" to email it to {formData.customerName}.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex gap-3 mt-8 pt-6 border-t border-neutral-200">
            {step > 1 && (
              <button
                onClick={handlePrevious}
                className="px-6 py-3 border border-neutral-300 text-neutral-700 rounded-lg hover:bg-neutral-50 transition-colors"
              >
                Previous
              </button>
            )}
            {step < 3 ? (
              <button
                onClick={handleNext}
                className="ml-auto px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
              >
                Next Step
              </button>
            ) : (
              <button
                onClick={() => alert('Estimate sent! (This is a demo)')}
                className="ml-auto px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
              >
                Send Estimate
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
