import { useState } from 'react';
import { ContractorLayout } from './ContractorLayout';
import { ContractorHome } from './ContractorHome';
import { EstimatesList } from './EstimatesList';
import { CreateEstimate } from './CreateEstimate';
import { AIChat } from '../homeowner/AIChat';
import { LeadsList } from './LeadsList';
import { UserProfile } from '../homeowner/UserProfile';
import { ContractorCalendar } from './ContractorCalendar';
import { ContractorReviews } from './ContractorReviews';
import { DesignRequests } from './DesignRequests';
import { FloatingChat } from '../FloatingChat';

type Page = 'home' | 'estimates' | 'createEstimate' | 'chat' | 'leads' | 'calendar' | 'reviews' | 'requests' | 'profile';

interface ScheduledItem {
  id: string;
  type: 'estimate' | 'job' | 'consultation';
  title: string;
  client: string;
  date: string;
  time: string;
  status: 'scheduled' | 'in-progress' | 'completed' | 'cancelled';
  location: string;
  notes?: string;
  value?: string;
}

const initialScheduledItems: ScheduledItem[] = [
  {
    id: '1',
    type: 'estimate',
    title: 'Kitchen Flooring Estimate',
    client: 'Sarah Johnson',
    date: '2024-12-20',
    time: '10:00 AM',
    status: 'scheduled',
    location: '123 Oak Street, Springfield',
    notes: 'Interested in hardwood for 300 sq ft kitchen',
    value: '$4,500'
  },
  {
    id: '2',
    type: 'job',
    title: 'Living Room Installation',
    client: 'Michael Chen',
    date: '2024-12-21',
    time: '8:00 AM',
    status: 'scheduled',
    location: '456 Maple Ave, Springfield',
    notes: 'LVP installation - materials already delivered',
    value: '$8,200'
  },
  {
    id: '3',
    type: 'consultation',
    title: 'Whole House Flooring Consultation',
    client: 'Emily Rodriguez',
    date: '2024-12-19',
    time: '2:00 PM',
    status: 'scheduled',
    location: '789 Pine Road, Springfield',
    notes: 'Looking to replace flooring in entire home - 2500 sq ft'
  }
];

interface ContractorDashboardProps {
  onLogout: () => void;
}

export function ContractorDashboard({ onLogout }: ContractorDashboardProps) {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [scheduledItems, setScheduledItems] = useState<ScheduledItem[]>(initialScheduledItems);

  const handleNavigate = (page: 'home' | 'estimates' | 'chat' | 'leads' | 'calendar' | 'reviews' | 'requests' | 'profile') => {
    setCurrentPage(page);
  };

  const handleCreateEstimate = () => {
    setCurrentPage('createEstimate');
  };

  const handleBackFromCreateEstimate = () => {
    setCurrentPage('estimates');
  };

  const handleAddScheduleItem = (item: Omit<typeof scheduledItems[0], 'id'>) => {
    const newItem = {
      ...item,
      id: Date.now().toString()
    };
    setScheduledItems([...scheduledItems, newItem]);
  };

  const renderContent = () => {
    switch (currentPage) {
      case 'home':
        return <ContractorHome onNavigate={handleNavigate} onCreateEstimate={handleCreateEstimate} />;
      case 'estimates':
        return <EstimatesList onCreateNew={handleCreateEstimate} />;
      case 'createEstimate':
        return <CreateEstimate onBack={handleBackFromCreateEstimate} />;
      case 'chat':
        return <AIChat userType="contractor" />;
      case 'leads':
        return <LeadsList />;
      case 'calendar':
        return <ContractorCalendar scheduledItems={scheduledItems} onAddItem={handleAddScheduleItem} />;
      case 'reviews':
        return <ContractorReviews />;
      case 'requests':
        return <DesignRequests />;
      case 'profile':
        return <UserProfile userType="contractor" onLogout={onLogout} />;
      default:
        return <ContractorHome onNavigate={handleNavigate} onCreateEstimate={handleCreateEstimate} />;
    }
  };

  const layoutPage = currentPage === 'createEstimate' ? 'estimates' : currentPage;

  return (
    <ContractorLayout currentPage={layoutPage as any} onNavigate={handleNavigate}>
      {renderContent()}
      <FloatingChat userType="contractor" />
    </ContractorLayout>
  );
}