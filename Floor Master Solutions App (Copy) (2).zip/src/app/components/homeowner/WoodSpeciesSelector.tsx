import { useState, useMemo } from 'react';
import { woodSpecies, getAllCategories, getAllPriceCategories, WoodSpecies } from '../../data/woodSpecies';
import { WoodComparisonChart } from './WoodComparisonChart';

interface WoodSpeciesSelectorProps {
  hardwoodType: string;
  onSelectSpecies: (speciesId: string) => void;
  onBack: () => void;
}

export function WoodSpeciesSelector({ hardwoodType, onSelectSpecies, onBack }: WoodSpeciesSelectorProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPriceCategory, setSelectedPriceCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'hardness' | 'price'>('name');
  const [showDetails, setShowDetails] = useState<string | null>(null);
  const [showComparisonChart, setShowComparisonChart] = useState(false);

  const typeLabel = useMemo(() => {
    const labels: Record<string, string> = {
      unfinished: 'Unfinished',
      prefinished: 'Prefinished',
      engineered: 'Engineered',
      lvp: 'LVP'
    };
    return labels[hardwoodType] || 'Hardwood';
  }, [hardwoodType]);

  const categories = getAllCategories();
  const priceCategories = getAllPriceCategories();

  const filteredSpecies = useMemo(() => {
    let filtered = woodSpecies.filter((species) => {
      const matchesCategory = selectedCategory === 'all' || species.category === selectedCategory;
      const matchesPrice = selectedPriceCategory === 'all' || species.priceCategory === selectedPriceCategory;
      return matchesCategory && matchesPrice;
    });

    // Sort
    if (sortBy === 'hardness') {
      filtered = [...filtered].sort((a, b) => b.hardness - a.hardness);
    } else if (sortBy === 'price') {
      const priceOrder = { 'Budget': 1, 'Mid-Range': 2, 'Premium': 3, 'Luxury': 4 };
      filtered = [...filtered].sort((a, b) => priceOrder[a.priceCategory] - priceOrder[b.priceCategory]);
    } else {
      filtered = [...filtered].sort((a, b) => a.name.localeCompare(b.name));
    }

    return filtered;
  }, [selectedCategory, selectedPriceCategory, sortBy]);

  const handleReset = () => {
    setSelectedCategory('all');
    setSelectedPriceCategory('all');
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      {showComparisonChart && (
        <WoodComparisonChart
          onClose={() => setShowComparisonChart(false)}
          onSelectSpecies={onSelectSpecies}
        />
      )}
      
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Type Selection</span>
          </button>
          
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-neutral-900 mb-2">Choose Your Wood Species</h1>
              <p className="text-neutral-600">
                Select from {woodSpecies.length} different wood species for your {typeLabel} flooring
              </p>
            </div>
            <button
              onClick={() => setShowComparisonChart(true)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex-shrink-0 ml-4"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
              <span>Compare All Woods</span>
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-neutral-900 text-sm">Filter Species</h3>
            <button
              onClick={handleReset}
              className="text-amber-600 hover:text-amber-700 text-sm transition-colors"
            >
              Reset Filters
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            {/* Category Filter */}
            <div>
              <label htmlFor="category" className="block text-neutral-700 mb-2 text-sm">
                Wood Category
              </label>
              <select
                id="category"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              >
                <option value="all">All Categories</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            {/* Price Category Filter */}
            <div>
              <label htmlFor="priceCategory" className="block text-neutral-700 mb-2 text-sm">
                Price Range
              </label>
              <select
                id="priceCategory"
                value={selectedPriceCategory}
                onChange={(e) => setSelectedPriceCategory(e.target.value)}
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              >
                <option value="all">All Prices</option>
                {priceCategories.map((price) => (
                  <option key={price} value={price}>{price}</option>
                ))}
              </select>
            </div>

            {/* Sort */}
            <div>
              <label htmlFor="sort" className="block text-neutral-700 mb-2 text-sm">
                Sort By
              </label>
              <select
                id="sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'name' | 'hardness' | 'price')}
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              >
                <option value="name">Name</option>
                <option value="hardness">Hardness (Highest First)</option>
                <option value="price">Price (Low to High)</option>
              </select>
            </div>
          </div>

          <div className="text-neutral-600 text-sm pt-4 border-t border-neutral-200">
            Showing {filteredSpecies.length} of {woodSpecies.length} species
          </div>
        </div>

        {/* Species Grid */}
        {filteredSpecies.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSpecies.map((species) => (
              <div
                key={species.id}
                className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden"
              >
                <div className="aspect-video overflow-hidden bg-neutral-100">
                  <img
                    src={species.image}
                    alt={species.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                
                <div className="p-6">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="text-neutral-900 mb-1">{species.name}</h3>
                      <p className="text-neutral-500 text-xs italic">{species.scientificName}</p>
                    </div>
                    <span className={`px-2 py-1 rounded text-xs flex-shrink-0 ml-2 ${
                      species.priceCategory === 'Budget' ? 'bg-green-100 text-green-700' :
                      species.priceCategory === 'Mid-Range' ? 'bg-blue-100 text-blue-700' :
                      species.priceCategory === 'Premium' ? 'bg-purple-100 text-purple-700' :
                      'bg-amber-100 text-amber-700'
                    }`}>
                      {species.priceCategory}
                    </span>
                  </div>
                  
                  <p className="text-neutral-600 text-sm mb-4 line-clamp-2">
                    {species.description}
                  </p>
                  
                  {/* Key Info */}
                  <div className="space-y-2 text-sm mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500">Hardness:</span>
                      <span className="text-neutral-700">{species.hardness} Janka</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500">Durability:</span>
                      <div className="flex items-center gap-1">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <div
                            key={i}
                            className={`w-2 h-2 rounded-full ${
                              i < species.durability ? 'bg-amber-600' : 'bg-neutral-300'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500">Color:</span>
                      <span className="text-neutral-700 text-xs text-right">{species.colorRange}</span>
                    </div>
                  </div>

                  {/* Expandable Details */}
                  {showDetails === species.id && (
                    <div className="mb-4 p-4 bg-neutral-50 rounded-lg space-y-3 text-sm">
                      <div>
                        <div className="text-neutral-700 mb-1">Grain Pattern:</div>
                        <div className="text-neutral-600 text-xs">{species.grainPattern}</div>
                      </div>
                      <div>
                        <div className="text-neutral-700 mb-1">Origin:</div>
                        <div className="text-neutral-600 text-xs">{species.origin}</div>
                      </div>
                      <div>
                        <div className="text-neutral-700 mb-1">Best For:</div>
                        <div className="flex flex-wrap gap-1">
                          {species.bestFor.map((use, idx) => (
                            <span key={idx} className="px-2 py-0.5 bg-white rounded text-xs text-neutral-600">
                              {use}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div>
                        <div className="text-neutral-700 mb-1">Key Characteristics:</div>
                        <ul className="space-y-1">
                          {species.characteristics.slice(0, 3).map((char, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-neutral-600 text-xs">
                              <svg className="w-3 h-3 text-amber-600 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                              <span>{char}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShowDetails(showDetails === species.id ? null : species.id)}
                      className="flex-1 px-4 py-2 border border-neutral-300 text-neutral-700 rounded-lg hover:bg-neutral-50 transition-colors text-sm"
                    >
                      {showDetails === species.id ? 'Hide Details' : 'View Details'}
                    </button>
                    <button
                      onClick={() => onSelectSpecies(species.id)}
                      className="flex-1 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors text-sm"
                    >
                      Select
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-xl">
            <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <h3 className="text-neutral-900 mb-2">No species found</h3>
            <p className="text-neutral-600 mb-4">
              Try adjusting your filters to see more options
            </p>
            <button
              onClick={handleReset}
              className="px-6 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        )}

        {/* Info Banner */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
          <div className="flex gap-4">
            <div className="flex-shrink-0">
              <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h4 className="text-neutral-900 mb-1">Understanding Janka Hardness</h4>
              <p className="text-neutral-600 text-sm">
                The Janka hardness test measures resistance to denting and wear. Higher numbers mean harder, more durable wood. 
                For reference: 1000+ is good for high-traffic areas, 1500+ is excellent, and 2000+ is commercial-grade.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}