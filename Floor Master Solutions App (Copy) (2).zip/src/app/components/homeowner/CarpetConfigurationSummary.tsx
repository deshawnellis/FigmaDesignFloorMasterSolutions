import { CarpetConfiguration } from './CarpetCustomizer';
import { carpetStyles, fiberTypes } from '../../data/carpetStyles';

interface CarpetConfigurationSummaryProps {
  configuration: CarpetConfiguration;
  onEdit: () => void;
  onRequestQuote: () => void;
}

export function CarpetConfigurationSummary({ configuration, onEdit, onRequestQuote }: CarpetConfigurationSummaryProps) {
  const style = carpetStyles.find(s => s.id === configuration.styleId);
  const fiber = fiberTypes.find(f => f.id === configuration.fiberType);

  if (!style || !fiber) {
    return null;
  }

  const getPileHeightLabel = (id: string) => {
    const labels: Record<string, string> = {
      low: 'Low Pile (1/4" - 1/2")',
      medium: 'Medium Pile (1/2" - 3/4")',
      high: 'High Pile (3/4" - 1")',
      ultra: 'Ultra/Shag Pile (1"+)'
    };
    return labels[id] || id;
  };

  const getBackingLabel = (id: string) => {
    const labels: Record<string, string> = {
      'action-back': 'Action Back (Standard)',
      'attached-pad': 'Attached Pad',
      'double-stick': 'Double Stick',
      'moisture-barrier': 'Moisture Barrier'
    };
    return labels[id] || id;
  };

  const getPaddingLabel = (id: string) => {
    const labels: Record<string, string> = {
      rebond: 'Rebond (Standard 6-8 lbs)',
      'memory-foam': 'Memory Foam (3-5 lbs)',
      'frothed-foam': 'Frothed Foam (8-10 lbs)',
      rubber: 'Rubber/Waffle (10-12 lbs)',
      premium: 'Premium Dense (12+ lbs)'
    };
    return labels[id] || id;
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-4xl mx-auto px-6 py-8 md:ml-64">
        <div className="mb-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-neutral-900 mb-2">Carpet Configuration Complete!</h1>
          <p className="text-neutral-600">
            Review your custom carpet specification below
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
          <div className="aspect-video bg-neutral-100">
            <img
              src={style.image}
              alt={style.name}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="p-8">
            <div className="mb-6">
              <h2 className="text-neutral-900 mb-1">Custom {style.name} Carpet</h2>
              <p className="text-neutral-600">{style.pileType} - {fiber.name}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div>
                <h3 className="text-neutral-900 mb-4">Style & Construction</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Style:</span>
                    <span className="text-neutral-900 text-right">{style.name}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Pile Type:</span>
                    <span className="text-neutral-900 text-right">{style.pileType}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Pile Height:</span>
                    <span className="text-neutral-900 text-right">{getPileHeightLabel(configuration.pileHeight)}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Traffic Rating:</span>
                    <span className="text-neutral-900 text-right">{style.traffic}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Maintenance:</span>
                    <span className="text-neutral-900 text-right">{style.maintenance}</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-neutral-900 mb-4">Fiber & Performance</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Fiber Type:</span>
                    <span className="text-neutral-900 text-right">{fiber.name}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Durability:</span>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div
                          key={i}
                          className={`w-2 h-2 rounded-full ${
                            i < fiber.durability ? 'bg-amber-600' : 'bg-neutral-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Stain Resistance:</span>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div
                          key={i}
                          className={`w-2 h-2 rounded-full ${
                            i < fiber.stainResistance ? 'bg-blue-600' : 'bg-neutral-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Softness:</span>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div
                          key={i}
                          className={`w-2 h-2 rounded-full ${
                            i < fiber.softness ? 'bg-purple-600' : 'bg-neutral-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-neutral-900 mb-4">Color & Pattern</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Color:</span>
                    <span className="text-neutral-900 text-right">{configuration.specificColor}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Color Family:</span>
                    <span className="text-neutral-900 text-right capitalize">{configuration.colorFamily}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Pattern:</span>
                    <span className="text-neutral-900 text-right capitalize">{configuration.pattern.replace('-', ' ')}</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-neutral-900 mb-4">Installation Details</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Backing:</span>
                    <span className="text-neutral-900 text-right">{getBackingLabel(configuration.backing)}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Padding:</span>
                    <span className="text-neutral-900 text-right">{getPaddingLabel(configuration.padding)}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Carpet Width:</span>
                    <span className="text-neutral-900 text-right">{configuration.width} feet</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mb-6 p-4 bg-neutral-50 rounded-lg">
              <h4 className="text-neutral-900 mb-2">Best For:</h4>
              <div className="flex flex-wrap gap-2">
                {style.bestFor.map((use, idx) => (
                  <span key={idx} className="px-3 py-1 bg-white border border-neutral-200 rounded-full text-neutral-700 text-sm">
                    {use}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={onEdit}
                className="flex-1 px-6 py-3 border-2 border-neutral-300 text-neutral-700 rounded-lg hover:bg-neutral-50 transition-colors"
              >
                Edit Configuration
              </button>
              <button
                onClick={onRequestQuote}
                className="flex-1 px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
              >
                Request Quote from Contractors
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h4 className="text-neutral-900 mb-2">Save Configuration</h4>
            <p className="text-neutral-600 text-sm mb-4">
              Download your carpet specification sheet
            </p>
            <button className="text-blue-600 hover:text-blue-700 text-sm">
              Download PDF
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
              </svg>
            </div>
            <h4 className="text-neutral-900 mb-2">Request Samples</h4>
            <p className="text-neutral-600 text-sm mb-4">
              Order physical carpet samples to see and feel
            </p>
            <button className="text-purple-600 hover:text-purple-700 text-sm">
              Order Samples
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
              </svg>
            </div>
            <h4 className="text-neutral-900 mb-2">Measure Your Room</h4>
            <p className="text-neutral-600 text-sm mb-4">
              Use our calculator to estimate square footage
            </p>
            <button className="text-green-600 hover:text-green-700 text-sm">
              Open Calculator
            </button>
          </div>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
          <div className="flex gap-4">
            <div className="flex-shrink-0">
              <svg className="w-6 h-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h4 className="text-neutral-900 mb-1">Important Carpet Care Information</h4>
              <p className="text-neutral-600 text-sm">
                {fiber.name} carpet requires {style.maintenance.toLowerCase()} maintenance. Regular vacuuming and prompt stain treatment will help maintain your carpet's appearance and extend its life. Professional cleaning is recommended every 12-18 months.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
