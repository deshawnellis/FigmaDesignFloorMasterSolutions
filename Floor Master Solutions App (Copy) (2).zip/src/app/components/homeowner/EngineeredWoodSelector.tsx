import { useState } from 'react';

interface EngineeredWoodSelectorProps {
  onSelectStyle: (typeId: string) => void;
  onBack: () => void;
}

export function EngineeredWoodSelector({ onSelectStyle, onBack }: EngineeredWoodSelectorProps) {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'construction' | 'species' | 'installation'>('all');

  const engineeredTypes = [
    {
      id: 'oak-3ply',
      name: 'Oak 3-Ply Engineered',
      category: 'species',
      species: 'Oak',
      construction: '3-Ply',
      wearLayer: '3mm',
      image: 'https://images.unsplash.com/photo-1631669394390-baf737ef47de?w=600&q=80',
      priceRange: '$5-8/sqft',
      description: 'Classic oak beauty with stable 3-layer construction',
      features: ['3mm wear layer', 'Can be refinished 1-2 times', 'Stable in varying humidity'],
      badge: 'Popular',
      gradient: 'from-amber-500 to-orange-500'
    },
    {
      id: 'oak-5ply',
      name: 'Oak 5-Ply Premium',
      category: 'species',
      species: 'Oak',
      construction: '5-Ply',
      wearLayer: '4mm',
      image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=600&q=80',
      priceRange: '$7-10/sqft',
      description: 'Premium oak with thicker wear layer for longevity',
      features: ['4mm wear layer', 'Can be refinished 2-3 times', 'Maximum stability'],
      badge: 'Premium',
      gradient: 'from-orange-500 to-red-500'
    },
    {
      id: 'maple-3ply',
      name: 'Maple 3-Ply Engineered',
      category: 'species',
      species: 'Maple',
      construction: '3-Ply',
      wearLayer: '3mm',
      image: 'https://images.unsplash.com/photo-1600585152915-d208bec867a1?w=600&q=80',
      priceRange: '$5-8/sqft',
      description: 'Light, elegant maple with 3-layer stability',
      features: ['Lighter color tones', 'Hard & durable', 'Modern aesthetic'],
      badge: 'Modern',
      gradient: 'from-yellow-500 to-amber-500'
    },
    {
      id: 'walnut-5ply',
      name: 'Walnut 5-Ply Premium',
      category: 'species',
      species: 'Walnut',
      construction: '5-Ply',
      wearLayer: '4mm',
      image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=600&q=80',
      priceRange: '$8-12/sqft',
      description: 'Rich, dark walnut with premium construction',
      features: ['Luxurious dark tones', 'Thick wear layer', 'High-end appearance'],
      badge: 'Luxury',
      gradient: 'from-stone-600 to-stone-800'
    },
    {
      id: 'hickory-3ply',
      name: 'Hickory 3-Ply Engineered',
      category: 'species',
      species: 'Hickory',
      construction: '3-Ply',
      wearLayer: '3mm',
      image: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=600&q=80',
      priceRange: '$6-9/sqft',
      description: 'Extremely durable hickory with varied grain patterns',
      features: ['Hardest domestic wood', 'Unique grain patterns', 'Rustic charm'],
      badge: 'Durable',
      gradient: 'from-amber-600 to-orange-600'
    },
    {
      id: 'birch-multilayer',
      name: 'Birch Multi-Layer',
      category: 'construction',
      species: 'Birch',
      construction: 'Multi-Layer',
      wearLayer: '2mm',
      image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&q=80',
      priceRange: '$4-6/sqft',
      description: 'Budget-friendly multi-layer with birch veneer',
      features: ['7-9 ply construction', 'Budget-friendly', 'Good stability'],
      badge: 'Value',
      gradient: 'from-neutral-400 to-neutral-600'
    },
    {
      id: 'ash-3ply',
      name: 'Ash 3-Ply Engineered',
      category: 'species',
      species: 'Ash',
      construction: '3-Ply',
      wearLayer: '3mm',
      image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=600&q=80',
      priceRange: '$5-8/sqft',
      description: 'Contemporary ash with pronounced grain',
      features: ['Distinctive grain', 'Light to medium tones', 'Contemporary style'],
      badge: 'Trending',
      gradient: 'from-slate-400 to-slate-600'
    },
    {
      id: 'cherry-5ply',
      name: 'Cherry 5-Ply Premium',
      category: 'species',
      species: 'Cherry',
      construction: '5-Ply',
      wearLayer: '4mm',
      image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=600&q=80',
      priceRange: '$8-11/sqft',
      description: 'Warm cherry tones with premium construction',
      features: ['Rich reddish-brown color', 'Ages beautifully', 'Elegant appearance'],
      badge: 'Classic',
      gradient: 'from-red-500 to-rose-600'
    },
    {
      id: 'click-lock-oak',
      name: 'Click-Lock Oak System',
      category: 'installation',
      species: 'Oak',
      construction: '3-Ply',
      wearLayer: '3mm',
      image: 'https://images.unsplash.com/photo-1631669394404-9a104e2eeee2?w=600&q=80',
      priceRange: '$6-9/sqft',
      description: 'Easy DIY installation with click-lock system',
      features: ['No glue needed', 'Easy DIY install', 'Floating floor system'],
      badge: 'DIY Friendly',
      gradient: 'from-blue-500 to-blue-600'
    },
    {
      id: 'glue-down-oak',
      name: 'Glue-Down Oak Premium',
      category: 'installation',
      species: 'Oak',
      construction: '5-Ply',
      wearLayer: '5mm',
      image: 'https://images.unsplash.com/photo-1600585152220-90363fe7e115?w=600&q=80',
      priceRange: '$7-10/sqft',
      description: 'Professional glue-down for maximum stability',
      features: ['Thickest wear layer', 'Most stable', 'Professional install'],
      badge: 'Pro Grade',
      gradient: 'from-indigo-500 to-purple-600'
    },
    {
      id: 'nail-down-maple',
      name: 'Nail-Down Maple Traditional',
      category: 'installation',
      species: 'Maple',
      construction: '3-Ply',
      wearLayer: '4mm',
      image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=600&q=80',
      priceRange: '$6-9/sqft',
      description: 'Traditional nail-down installation method',
      features: ['Traditional install', 'Over wood subfloor', 'Very stable'],
      badge: 'Traditional',
      gradient: 'from-green-500 to-teal-600'
    },
    {
      id: 'wide-plank-oak',
      name: 'Wide Plank Oak 7-inch',
      category: 'construction',
      species: 'Oak',
      construction: '5-Ply',
      wearLayer: '4mm',
      image: 'https://images.unsplash.com/photo-1600210491369-e753d80a41f3?w=600&q=80',
      priceRange: '$8-12/sqft',
      description: 'Modern wide plank format for dramatic effect',
      features: ['7-inch wide planks', 'Contemporary look', 'Shows grain beautifully'],
      badge: 'Wide Format',
      gradient: 'from-orange-600 to-red-600'
    }
  ];

  const categories = [
    { id: 'all', name: 'All Types', icon: '🪵', count: engineeredTypes.length },
    { id: 'species', name: 'By Wood Species', icon: '🌳', count: engineeredTypes.filter(t => t.category === 'species').length },
    { id: 'construction', name: 'By Construction', icon: '🔨', count: engineeredTypes.filter(t => t.category === 'construction').length },
    { id: 'installation', name: 'By Installation', icon: '🔧', count: engineeredTypes.filter(t => t.category === 'installation').length }
  ];

  const filteredTypes = selectedCategory === 'all' 
    ? engineeredTypes 
    : engineeredTypes.filter(t => t.category === selectedCategory);

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-6 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Flooring Types</span>
          </button>

          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-orange-600 to-red-600 rounded-2xl flex items-center justify-center text-3xl shadow-lg">
              🪵
            </div>
            <div>
              <h1 className="text-neutral-900 text-3xl md:text-4xl">Engineered Wood Flooring</h1>
              <p className="text-neutral-600 text-lg">Choose from {engineeredTypes.length} types of engineered wood</p>
            </div>
          </div>

          {/* Info Banner */}
          <div className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-2xl p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-2xl flex-shrink-0">
                💡
              </div>
              <div>
                <h3 className="text-neutral-900 mb-2">What is Engineered Wood?</h3>
                <p className="text-neutral-700 text-sm mb-3">
                  Engineered wood has a real wood veneer on top bonded to multiple layers of plywood. This makes it more stable than solid hardwood and suitable for basements and over radiant heat.
                </p>
                <div className="flex flex-wrap gap-3">
                  <div className="flex items-center gap-2 text-sm text-neutral-700">
                    <span className="text-green-600">✓</span>
                    <span>More stable than solid wood</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-neutral-700">
                    <span className="text-green-600">✓</span>
                    <span>Better moisture resistance</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-neutral-700">
                    <span className="text-green-600">✓</span>
                    <span>Can be used in basements</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-neutral-700">
                    <span className="text-green-600">✓</span>
                    <span>Real wood appearance</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Category Filter */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <svg className="w-5 h-5 text-neutral-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
            </svg>
            <span className="text-neutral-900">Filter by Category</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id as any)}
                className={`p-4 rounded-xl transition-all ${
                  selectedCategory === category.id
                    ? 'bg-gradient-to-br from-orange-600 to-red-600 text-white shadow-lg scale-105'
                    : 'bg-white text-neutral-900 hover:shadow-lg'
                }`}
              >
                <div className="text-3xl mb-2">{category.icon}</div>
                <div className="text-sm mb-1">{category.name}</div>
                <div className={`text-xs ${selectedCategory === category.id ? 'text-orange-100' : 'text-neutral-600'}`}>
                  {category.count} options
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Engineered Wood Types Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => onSelectStyle(type.id)}
              className="group bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all hover:scale-105 text-left"
            >
              {/* Image with Overlay */}
              <div className="relative h-56 overflow-hidden">
                <img
                  src={type.image}
                  alt={type.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${type.gradient} opacity-50`} />
                
                {/* Badge */}
                <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-3 py-1 rounded-full text-sm text-neutral-900 shadow-lg">
                  {type.badge}
                </div>

                {/* Title Overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent">
                  <h3 className="text-white text-xl mb-1">{type.name}</h3>
                  <div className="flex items-center gap-2 text-white/80 text-sm">
                    <span>{type.priceRange}</span>
                  </div>
                </div>
              </div>

              {/* Details */}
              <div className="p-6">
                <p className="text-neutral-600 text-sm mb-4">{type.description}</p>

                {/* Specs */}
                <div className="grid grid-cols-3 gap-3 mb-4 pb-4 border-b border-neutral-100">
                  <div>
                    <div className="text-xs text-neutral-500 mb-1">Species</div>
                    <div className="text-sm text-neutral-900">{type.species}</div>
                  </div>
                  <div>
                    <div className="text-xs text-neutral-500 mb-1">Construction</div>
                    <div className="text-sm text-neutral-900">{type.construction}</div>
                  </div>
                  <div>
                    <div className="text-xs text-neutral-500 mb-1">Wear Layer</div>
                    <div className="text-sm text-neutral-900">{type.wearLayer}</div>
                  </div>
                </div>

                {/* Features */}
                <div className="space-y-2 mb-4">
                  {type.features.map((feature, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <svg className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      <span className="text-neutral-600">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* CTA */}
                <div className={`flex items-center justify-center gap-2 text-transparent bg-gradient-to-r ${type.gradient} bg-clip-text group-hover:gap-3 transition-all`}>
                  <span>Customize This Floor</span>
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Comparison Info */}
        <div className="mt-12 bg-gradient-to-br from-neutral-900 to-neutral-800 rounded-3xl p-8 md:p-12 text-white">
          <h2 className="text-white text-3xl mb-6 text-center">Understanding Engineered Wood Construction</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-2xl mb-4">
                📏
              </div>
              <h3 className="text-white text-xl mb-3">Wear Layer Thickness</h3>
              <p className="text-neutral-300 text-sm mb-3">
                The top solid wood layer determines how many times you can refinish the floor.
              </p>
              <ul className="space-y-2 text-sm text-neutral-400">
                <li>• 2mm: Light sanding only</li>
                <li>• 3mm: 1-2 refinishes</li>
                <li>• 4-5mm: 2-3+ refinishes</li>
              </ul>
            </div>

            <div>
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-2xl mb-4">
                🔨
              </div>
              <h3 className="text-white text-xl mb-3">Ply Construction</h3>
              <p className="text-neutral-300 text-sm mb-3">
                More plies mean better stability and resistance to warping.
              </p>
              <ul className="space-y-2 text-sm text-neutral-400">
                <li>• 3-Ply: Good stability</li>
                <li>• 5-Ply: Excellent stability</li>
                <li>• Multi-Layer: Budget option</li>
              </ul>
            </div>

            <div>
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-2xl mb-4">
                🔧
              </div>
              <h3 className="text-white text-xl mb-3">Installation Methods</h3>
              <p className="text-neutral-300 text-sm mb-3">
                Different methods work for different subfloors and skill levels.
              </p>
              <ul className="space-y-2 text-sm text-neutral-400">
                <li>• Click-Lock: DIY friendly</li>
                <li>• Glue-Down: Most stable</li>
                <li>• Nail-Down: Traditional</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}