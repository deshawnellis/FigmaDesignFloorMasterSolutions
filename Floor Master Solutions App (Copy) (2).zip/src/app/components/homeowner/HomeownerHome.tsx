import { useState, useEffect } from 'react';

interface HomeownerHomeProps {
  onNavigate: (page: 'home' | 'flooring' | 'visualizer' | 'chat' | 'contractors' | 'profile') => void;
  onSelectFlooring: (id: string) => void;
}

export function HomeownerHome({ onNavigate, onSelectFlooring }: HomeownerHomeProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [activeTab, setActiveTab] = useState(0);

  const heroSlides = [
    {
      image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1600&q=80',
      title: 'Design Your Dream Floor',
      subtitle: 'From hardwood to tile - customize every detail and visualize it in your space',
      gradient: 'from-amber-900/70 to-amber-600/70'
    },
    {
      image: 'https://images.unsplash.com/photo-1631679706909-1844bbd07221?w=1600&q=80',
      title: 'Connect with Expert Installers',
      subtitle: 'Get quotes from verified contractors and schedule installation in minutes',
      gradient: 'from-blue-900/70 to-blue-600/70'
    },
    {
      image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=1600&q=80',
      title: 'See Before You Buy',
      subtitle: 'Use our AI visualizer to preview any floor in your actual room photos',
      gradient: 'from-purple-900/70 to-purple-600/70'
    }
  ];

  const flooringShowcase = [
    {
      id: 'hardwood',
      name: 'Hardwood Flooring',
      description: 'Timeless beauty with 18 wood species to customize',
      image: 'https://images.unsplash.com/photo-1631669394390-baf737ef47de?w=800&q=80',
      icon: '🌳',
      gradient: 'from-amber-600 to-orange-600',
      stats: { options: '18 Species', price: '$8-15/sqft', durability: '4.5/5' },
      badge: 'Most Popular'
    },
    {
      id: 'engineered',
      name: 'Engineered Wood',
      description: 'Real wood top layer with stable plywood base',
      image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&q=80',
      icon: '🪵',
      gradient: 'from-orange-600 to-red-600',
      stats: { options: '20+ Styles', price: '$4-10/sqft', durability: '4/5' },
      badge: 'Versatile'
    },
    {
      id: 'lvp',
      name: 'Luxury Vinyl Plank',
      description: '100% waterproof with realistic wood looks',
      image: 'https://images.unsplash.com/photo-1604410880766-737427d11b70?w=800&q=80',
      icon: '💧',
      gradient: 'from-blue-600 to-cyan-600',
      stats: { options: '50+ Styles', price: '$3-8/sqft', durability: '5/5' },
      badge: 'Waterproof'
    },
    {
      id: 'tile',
      name: 'Ceramic & Porcelain Tile',
      description: 'Endless patterns, colors, and durability',
      image: 'https://images.unsplash.com/photo-1719782758766-f0a4a3808afe?w=800&q=80',
      icon: '⬜',
      gradient: 'from-purple-600 to-pink-600',
      stats: { options: '10 Materials', price: '$5-15/sqft', durability: '5/5' },
      badge: 'Ultra Durable'
    },
    {
      id: 'carpet',
      name: 'Premium Carpet',
      description: 'Cozy comfort with stain-resistant options',
      image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=800&q=80',
      icon: '🏠',
      gradient: 'from-green-600 to-teal-600',
      stats: { options: '8 Styles', price: '$2-10/sqft', durability: '3.5/5' },
      badge: 'Comfortable'
    },
    {
      id: 'epoxy',
      name: 'Epoxy Flooring',
      description: 'Modern, seamless floors for garages & more',
      image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&q=80',
      icon: '✨',
      gradient: 'from-indigo-600 to-purple-600',
      stats: { options: '6 Finishes', price: '$4-12/sqft', durability: '5/5' },
      badge: 'Industrial'
    },
    {
      id: 'laminate',
      name: 'Laminate Flooring',
      description: 'Budget-friendly with wood-look styles',
      image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=800&q=80',
      icon: '📐',
      gradient: 'from-amber-600 to-yellow-600',
      stats: { options: '30+ Styles', price: '$1-5/sqft', durability: '3/5' },
      badge: 'Budget Friendly'
    }
  ];

  const processSteps = [
    {
      step: '1',
      title: 'Explore & Compare',
      description: 'Browse flooring types with detailed specs, pricing, and durability ratings. Use our comparison tool to see options side-by-side.',
      image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=600&q=80',
      icon: '🔍',
      color: 'from-blue-500 to-blue-600',
      features: ['7+ Flooring Types', 'Side-by-Side Compare', 'Real Pricing', 'Expert Guides']
    },
    {
      step: '2',
      title: 'Customize Your Design',
      description: 'Use our interactive tools to select colors, finishes, materials, and patterns. See price updates in real-time as you design.',
      image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=600&q=80',
      icon: '🎨',
      color: 'from-purple-500 to-purple-600',
      features: ['Custom Colors', 'Finish Options', 'Pattern Preview', 'Live Pricing']
    },
    {
      step: '3',
      title: 'Visualize in Your Room',
      description: 'Upload a photo of your space and see your custom floor design overlaid in real-time. Share designs with family or contractors.',
      image: 'https://images.unsplash.com/photo-1600210491892-03d54c0aaf87?w=600&q=80',
      icon: '📸',
      color: 'from-green-500 to-green-600',
      features: ['Photo Upload', 'AI Visualization', 'Save & Share', 'Multiple Rooms']
    },
    {
      step: '4',
      title: 'Get Professional Installation',
      description: 'Connect with background-checked contractors, read verified reviews, and get multiple quotes. Message pros directly in the app.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=80',
      icon: '✅',
      color: 'from-amber-500 to-amber-600',
      features: ['Verified Contractors', 'Real Reviews', 'Direct Messaging', 'Competitive Quotes']
    }
  ];

  const whyChooseUs = [
    {
      title: 'Save Money',
      description: 'Compare prices from multiple contractors and get the best deal',
      icon: '💰',
      image: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=400&q=80',
      stat: 'Save up to 30%'
    },
    {
      title: 'Save Time',
      description: 'Everything in one place - no more calling around or store visits',
      icon: '⏱️',
      image: 'https://images.unsplash.com/photo-1501139083538-0139583c060f?w=400&q=80',
      stat: 'Done in days, not weeks'
    },
    {
      title: 'Expert Guidance',
      description: '24/7 AI assistant plus educational guides for every flooring type',
      icon: '🎓',
      image: 'https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?w=400&q=80',
      stat: 'Always available'
    },
    {
      title: 'Verified Quality',
      description: 'All contractors are background-checked and rated by real customers',
      icon: '⭐',
      image: 'https://images.unsplash.com/photo-1560264280-88b68371db39?w=400&q=80',
      stat: '4.8/5 avg rating'
    }
  ];

  const testimonials = [
    {
      name: 'Jessica Martinez',
      location: 'Austin, TX',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80',
      text: 'The visualizer tool was a game-changer! I could see exactly how the hardwood would look in my living room before buying. Saved me from making an expensive mistake.',
      rating: 5,
      floor: 'Oak Hardwood',
      floorImage: 'https://images.unsplash.com/photo-1631669394390-baf737ef47de?w=300&q=80'
    },
    {
      name: 'Robert Chen',
      location: 'Seattle, WA',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&q=80',
      text: 'Got 4 quotes in 24 hours! The contractors were professional and the whole process was seamless. Love our new LVP - totally waterproof and looks amazing.',
      rating: 5,
      floor: 'Luxury Vinyl Plank',
      floorImage: 'https://images.unsplash.com/photo-1604410880766-737427d11b70?w=300&q=80'
    },
    {
      name: 'Amanda Williams',
      location: 'Miami, FL',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80',
      text: 'The AI assistant answered all my questions about tile durability and maintenance. The comparison tool made it so easy to choose. Best home improvement experience ever!',
      rating: 5,
      floor: 'Porcelain Tile',
      floorImage: 'https://images.unsplash.com/photo-1719782758766-f0a4a3808afe?w=300&q=80'
    }
  ];

  const comparisonData = [
    {
      id: 'hardwood',
      name: 'Hardwood',
      icon: '🌳',
      priceRange: '$8-15',
      durability: 4.5,
      waterResistance: 2,
      maintenance: 'Medium',
      lifespan: '25-100 years',
      installation: 'Professional',
      bestFor: 'Living rooms, bedrooms',
      image: 'https://images.unsplash.com/photo-1631669394390-baf737ef47de?w=300&q=80',
      pros: ['Timeless beauty', 'Increases home value', 'Can be refinished'],
      cons: ['Expensive', 'Sensitive to moisture', 'Requires maintenance'],
      color: 'from-amber-600 to-orange-600'
    },
    {
      id: 'engineered',
      name: 'Engineered Wood',
      icon: '🪵',
      priceRange: '$4-10',
      durability: 4,
      waterResistance: 3,
      maintenance: 'Low',
      lifespan: '20-40 years',
      installation: 'DIY Friendly',
      bestFor: 'All rooms, basements',
      image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=300&q=80',
      pros: ['More stable than hardwood', 'Better moisture resistance', 'Real wood top layer'],
      cons: ['Limited refinishing', 'Thinner wear layer', 'Quality varies by brand'],
      color: 'from-orange-600 to-red-600'
    },
    {
      id: 'lvp',
      name: 'Luxury Vinyl',
      icon: '💧',
      priceRange: '$3-8',
      durability: 5,
      waterResistance: 5,
      maintenance: 'Low',
      lifespan: '10-20 years',
      installation: 'DIY Friendly',
      bestFor: 'Kitchens, bathrooms, basements',
      image: 'https://images.unsplash.com/photo-1604410880766-737427d11b70?w=300&q=80',
      pros: ['100% waterproof', 'Very durable', 'Easy to install'],
      cons: ['Not as prestigious', 'Can\'t be refinished', 'May fade in sunlight'],
      color: 'from-blue-600 to-cyan-600'
    },
    {
      id: 'tile',
      name: 'Tile',
      icon: '⬜',
      priceRange: '$5-15',
      durability: 5,
      waterResistance: 5,
      maintenance: 'Low',
      lifespan: '50-100 years',
      installation: 'Professional',
      bestFor: 'Bathrooms, kitchens, entryways',
      image: 'https://images.unsplash.com/photo-1719782758766-f0a4a3808afe?w=300&q=80',
      pros: ['Extremely durable', 'Waterproof', 'Endless designs'],
      cons: ['Cold & hard', 'Grout maintenance', 'Installation cost'],
      color: 'from-purple-600 to-pink-600'
    },
    {
      id: 'carpet',
      name: 'Carpet',
      icon: '🏠',
      priceRange: '$2-10',
      durability: 3.5,
      waterResistance: 1,
      maintenance: 'High',
      lifespan: '5-15 years',
      installation: 'Professional',
      bestFor: 'Bedrooms, living rooms',
      image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=300&q=80',
      pros: ['Soft & comfortable', 'Sound insulation', 'Affordable'],
      cons: ['Stains easily', 'Not waterproof', 'Traps allergens'],
      color: 'from-green-600 to-teal-600'
    },
    {
      id: 'laminate',
      name: 'Laminate',
      icon: '📐',
      priceRange: '$1-5',
      durability: 3,
      waterResistance: 2,
      maintenance: 'Low',
      lifespan: '10-25 years',
      installation: 'DIY Friendly',
      bestFor: 'Living rooms, bedrooms',
      image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=300&q=80',
      pros: ['Budget-friendly', 'Easy to install', 'Scratch resistant'],
      cons: ['Can\'t be refinished', 'Not waterproof', 'Hollow sound'],
      color: 'from-amber-600 to-yellow-600'
    },
    {
      id: 'epoxy',
      name: 'Epoxy',
      icon: '✨',
      priceRange: '$4-12',
      durability: 5,
      waterResistance: 5,
      maintenance: 'Very Low',
      lifespan: '10-20 years',
      installation: 'Professional',
      bestFor: 'Garages, basements, commercial',
      image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=300&q=80',
      pros: ['Seamless surface', 'Chemical resistant', 'Easy to clean'],
      cons: ['Installation odor', 'Long cure time', 'Limited to certain spaces'],
      color: 'from-indigo-600 to-purple-600'
    },
    {
      id: 'bamboo',
      name: 'Bamboo',
      icon: '🎋',
      priceRange: '$3-8',
      durability: 4,
      waterResistance: 2,
      maintenance: 'Medium',
      lifespan: '20-25 years',
      installation: 'Professional',
      bestFor: 'Living rooms, bedrooms',
      image: 'https://images.unsplash.com/photo-1615874959474-d609969a20ed?w=300&q=80',
      pros: ['Eco-friendly', 'Renewable resource', 'Unique look'],
      cons: ['Sensitive to moisture', 'Can scratch', 'Quality varies'],
      color: 'from-lime-600 to-green-600'
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTab((prev) => (prev + 1) % processSteps.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto md:ml-64">
        {/* Hero Section with Parallax Effect */}
        <div className="relative h-[600px] overflow-hidden rounded-b-3xl">
          {heroSlides.map((slide, index) => (
            <div
              key={index}
              className={`absolute inset-0 transition-all duration-1000 ${
                index === currentSlide ? 'opacity-100 scale-100' : 'opacity-0 scale-110'
              }`}
            >
              <img
                src={slide.image}
                alt={slide.title}
                className="w-full h-full object-cover"
              />
              <div className={`absolute inset-0 bg-gradient-to-r ${slide.gradient}`} />
            </div>
          ))}
          
          <div className="absolute inset-0 flex items-center justify-center px-6 z-10">
            <div className="max-w-4xl text-center">
              <div className="mb-6 inline-block px-6 py-2 bg-white/20 backdrop-blur-md rounded-full text-white border border-white/30">
                ✨ Trusted by 1,000+ Happy Homeowners
              </div>
              <h1 className="text-white text-4xl md:text-6xl mb-6 drop-shadow-2xl">
                {heroSlides[currentSlide].title}
              </h1>
              <p className="text-white/95 text-xl md:text-2xl mb-10 drop-shadow-lg max-w-2xl mx-auto">
                {heroSlides[currentSlide].subtitle}
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => onNavigate('flooring')}
                  className="px-10 py-4 bg-white text-neutral-900 rounded-xl hover:bg-neutral-100 transition-all shadow-2xl text-lg flex items-center justify-center gap-2"
                >
                  <span>Explore Flooring</span>
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </button>
                <button
                  onClick={() => onNavigate('visualizer')}
                  className="px-10 py-4 bg-white/10 backdrop-blur-md text-white rounded-xl hover:bg-white/20 transition-all border-2 border-white/40 text-lg"
                >
                  Try Visualizer Free
                </button>
              </div>
            </div>
          </div>

          {/* Carousel Dots */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20 flex gap-3">
            {heroSlides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`transition-all rounded-full ${
                  index === currentSlide
                    ? 'w-10 h-3 bg-white'
                    : 'w-3 h-3 bg-white/50 hover:bg-white/70'
                }`}
              />
            ))}
          </div>
        </div>

        <div className="px-6 py-16">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 -mt-32 mb-20 relative z-20">
            {[
              { icon: '🏠', value: '7+', label: 'Flooring Types', color: 'from-blue-500 to-blue-600' },
              { icon: '⭐', value: '1,000+', label: 'Happy Customers', color: 'from-purple-500 to-purple-600' },
              { icon: '👷', value: '500+', label: 'Verified Contractors', color: 'from-green-500 to-green-600' },
              { icon: '💬', value: '24/7', label: 'AI Support', color: 'from-amber-500 to-amber-600' }
            ].map((stat, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-8 shadow-2xl text-center hover:scale-105 transition-transform"
              >
                <div className="text-5xl mb-3">{stat.icon}</div>
                <div className={`text-3xl bg-gradient-to-r ${stat.color} bg-clip-text text-transparent mb-2`}>
                  {stat.value}
                </div>
                <div className="text-neutral-600">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Featured Flooring Showcase */}
          <div className="mb-20">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl text-neutral-900 mb-4">
                Explore Our Flooring Collection
              </h2>
              <p className="text-xl text-neutral-600 max-w-3xl mx-auto">
                From timeless hardwood to modern epoxy - find your perfect floor with detailed customization options
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {flooringShowcase.map((flooring) => (
                <button
                  key={flooring.id}
                  onClick={() => onSelectFlooring(flooring.id)}
                  className="group bg-white rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all hover:scale-105"
                >
                  <div className="relative h-64 overflow-hidden">
                    <img
                      src={flooring.image}
                      alt={flooring.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className={`absolute inset-0 bg-gradient-to-t ${flooring.gradient} opacity-40`} />
                    <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-4 py-2 rounded-full text-sm text-neutral-900">
                      {flooring.badge}
                    </div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-4xl">{flooring.icon}</span>
                        <h3 className="text-white text-2xl">{flooring.name}</h3>
                      </div>
                    </div>
                  </div>
                  <div className="p-6">
                    <p className="text-neutral-600 mb-4">{flooring.description}</p>
                    <div className="grid grid-cols-3 gap-3 mb-4">
                      <div className="text-center">
                        <div className="text-xs text-neutral-500 mb-1">Options</div>
                        <div className="text-sm text-neutral-900">{flooring.stats.options}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xs text-neutral-500 mb-1">Price</div>
                        <div className="text-sm text-neutral-900">{flooring.stats.price}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xs text-neutral-500 mb-1">Durability</div>
                        <div className="text-sm text-neutral-900">{flooring.stats.durability}</div>
                      </div>
                    </div>
                    <div className={`flex items-center justify-center gap-2 text-transparent bg-gradient-to-r ${flooring.gradient} bg-clip-text group-hover:gap-3 transition-all`}>
                      <span>Customize Now</span>
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Flooring Comparison Chart */}
          <div className="mb-20">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl text-neutral-900 mb-4">
                Compare All Flooring Types
              </h2>
              <p className="text-xl text-neutral-600 max-w-3xl mx-auto">
                Side-by-side comparison to help you make the best decision for your space
              </p>
            </div>

            {/* Desktop Table View */}
            <div className="hidden lg:block bg-white rounded-3xl shadow-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gradient-to-r from-blue-600 to-purple-600">
                    <tr>
                      <th className="py-6 px-6 text-left text-white">Flooring Type</th>
                      <th className="py-6 px-4 text-center text-white">Price/sqft</th>
                      <th className="py-6 px-4 text-center text-white">Durability</th>
                      <th className="py-6 px-4 text-center text-white">Water Resistance</th>
                      <th className="py-6 px-4 text-center text-white">Maintenance</th>
                      <th className="py-6 px-4 text-center text-white">Lifespan</th>
                      <th className="py-6 px-4 text-center text-white">Installation</th>
                      <th className="py-6 px-4 text-center text-white">Best For</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {comparisonData.map((floor, index) => (
                      <tr key={floor.id} className={`hover:bg-neutral-50 transition-colors ${index % 2 === 0 ? 'bg-white' : 'bg-neutral-25'}`}>
                        <td className="py-6 px-6">
                          <div className="flex items-center gap-4">
                            <div className="relative w-16 h-16 rounded-xl overflow-hidden flex-shrink-0">
                              <img src={floor.image} alt={floor.name} className="w-full h-full object-cover" />
                              <div className={`absolute inset-0 bg-gradient-to-br ${floor.color} opacity-30`} />
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="text-2xl">{floor.icon}</span>
                                <span className="text-neutral-900">{floor.name}</span>
                              </div>
                              <button
                                onClick={() => onSelectFlooring(floor.id)}
                                className={`text-sm text-transparent bg-gradient-to-r ${floor.color} bg-clip-text hover:underline mt-1`}
                              >
                                View Details →
                              </button>
                            </div>
                          </div>
                        </td>
                        <td className="py-6 px-4 text-center text-neutral-900">{floor.priceRange}</td>
                        <td className="py-6 px-4">
                          <div className="flex items-center justify-center gap-1">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <svg
                                key={i}
                                className={`w-5 h-5 ${i < floor.durability ? 'text-amber-400' : 'text-neutral-200'}`}
                                fill="currentColor"
                                viewBox="0 0 20 20"
                              >
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                              </svg>
                            ))}
                          </div>
                        </td>
                        <td className="py-6 px-4">
                          <div className="flex items-center justify-center gap-1">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <div
                                key={i}
                                className={`w-3 h-8 rounded ${i < floor.waterResistance ? 'bg-blue-500' : 'bg-neutral-200'}`}
                              />
                            ))}
                          </div>
                        </td>
                        <td className="py-6 px-4">
                          <span className={`px-3 py-1 rounded-full text-sm ${
                            floor.maintenance === 'Low' || floor.maintenance === 'Very Low'
                              ? 'bg-green-100 text-green-700'
                              : floor.maintenance === 'Medium'
                              ? 'bg-amber-100 text-amber-700'
                              : 'bg-red-100 text-red-700'
                          }`}>
                            {floor.maintenance}
                          </span>
                        </td>
                        <td className="py-6 px-4 text-center text-neutral-900 text-sm">{floor.lifespan}</td>
                        <td className="py-6 px-4">
                          <span className={`px-3 py-1 rounded-full text-sm ${
                            floor.installation === 'DIY Friendly'
                              ? 'bg-purple-100 text-purple-700'
                              : 'bg-blue-100 text-blue-700'
                          }`}>
                            {floor.installation}
                          </span>
                        </td>
                        <td className="py-6 px-4 text-center text-neutral-600 text-sm">{floor.bestFor}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Mobile Card View */}
            <div className="lg:hidden space-y-6">
              {comparisonData.map((floor) => (
                <div key={floor.id} className="bg-white rounded-2xl shadow-xl overflow-hidden">
                  {/* Floor Header */}
                  <div className="relative h-32 overflow-hidden">
                    <img src={floor.image} alt={floor.name} className="w-full h-full object-cover" />
                    <div className={`absolute inset-0 bg-gradient-to-br ${floor.color} opacity-60`} />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center text-white">
                        <div className="text-4xl mb-2">{floor.icon}</div>
                        <h3 className="text-white text-2xl">{floor.name}</h3>
                      </div>
                    </div>
                  </div>

                  {/* Floor Stats */}
                  <div className="p-6 space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-xs text-neutral-500 mb-1">Price/sqft</div>
                        <div className={`text-transparent bg-gradient-to-r ${floor.color} bg-clip-text`}>{floor.priceRange}</div>
                      </div>
                      <div>
                        <div className="text-xs text-neutral-500 mb-1">Lifespan</div>
                        <div className="text-neutral-900 text-sm">{floor.lifespan}</div>
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-neutral-500 mb-2">Durability</div>
                      <div className="flex gap-1">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <svg
                            key={i}
                            className={`w-5 h-5 ${i < floor.durability ? 'text-amber-400' : 'text-neutral-200'}`}
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-neutral-500 mb-2">Water Resistance</div>
                      <div className="flex gap-1">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <div
                            key={i}
                            className={`w-10 h-2 rounded ${i < floor.waterResistance ? 'bg-blue-500' : 'bg-neutral-200'}`}
                          />
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-xs text-neutral-500 mb-1">Maintenance</div>
                        <span className={`inline-block px-3 py-1 rounded-full text-xs ${
                          floor.maintenance === 'Low' || floor.maintenance === 'Very Low'
                            ? 'bg-green-100 text-green-700'
                            : floor.maintenance === 'Medium'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-red-100 text-red-700'
                        }`}>
                          {floor.maintenance}
                        </span>
                      </div>
                      <div>
                        <div className="text-xs text-neutral-500 mb-1">Installation</div>
                        <span className={`inline-block px-3 py-1 rounded-full text-xs ${
                          floor.installation === 'DIY Friendly'
                            ? 'bg-purple-100 text-purple-700'
                            : 'bg-blue-100 text-blue-700'
                        }`}>
                          {floor.installation}
                        </span>
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-neutral-500 mb-1">Best For</div>
                      <div className="text-neutral-900 text-sm">{floor.bestFor}</div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-4 border-t border-neutral-100">
                      <div>
                        <div className="text-xs text-neutral-500 mb-2">Pros</div>
                        {floor.pros.map((pro, i) => (
                          <div key={i} className="text-xs text-green-700 flex items-start gap-1 mb-1">
                            <span>✓</span>
                            <span>{pro}</span>
                          </div>
                        ))}
                      </div>
                      <div>
                        <div className="text-xs text-neutral-500 mb-2">Cons</div>
                        {floor.cons.map((con, i) => (
                          <div key={i} className="text-xs text-red-700 flex items-start gap-1 mb-1">
                            <span>✗</span>
                            <span>{con}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={() => onSelectFlooring(floor.id)}
                      className={`w-full py-3 rounded-xl bg-gradient-to-r ${floor.color} text-white hover:shadow-lg transition-all mt-4`}
                    >
                      Customize {floor.name}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Legend */}
            <div className="mt-8 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-6">
              <h3 className="text-neutral-900 text-xl mb-4">How to Read This Chart</h3>
              <div className="grid md:grid-cols-3 gap-4 text-sm">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex gap-0.5">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <svg key={i} className="w-4 h-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                    <span className="text-neutral-900">Durability</span>
                  </div>
                  <p className="text-neutral-600 text-xs">More stars = longer lasting</p>
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex gap-0.5">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div key={i} className="w-2 h-6 rounded bg-blue-500" />
                      ))}
                    </div>
                    <span className="text-neutral-900">Water Resistance</span>
                  </div>
                  <p className="text-neutral-600 text-xs">More bars = better for wet areas</p>
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-3 py-1 rounded-full text-xs bg-green-100 text-green-700">Low</span>
                    <span className="text-neutral-900">Maintenance</span>
                  </div>
                  <p className="text-neutral-600 text-xs">Lower = easier to maintain</p>
                </div>
              </div>
            </div>
          </div>

          {/* How It Works - Interactive Tabs */}
          <div className="mb-20 bg-gradient-to-br from-blue-50 to-purple-50 rounded-3xl p-8 md:p-12">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl text-neutral-900 mb-4">
                How It Works
              </h2>
              <p className="text-xl text-neutral-600">
                Your journey from browsing to installation - made simple
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12 items-center">
              {/* Tab Buttons */}
              <div className="space-y-4">
                {processSteps.map((step, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveTab(index)}
                    className={`w-full text-left p-6 rounded-2xl transition-all ${
                      activeTab === index
                        ? 'bg-white shadow-2xl scale-105'
                        : 'bg-white/50 hover:bg-white/80'
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <div className={`w-16 h-16 bg-gradient-to-br ${step.color} rounded-2xl flex items-center justify-center text-3xl flex-shrink-0 shadow-lg relative`}>
                        {step.icon}
                        <div className="absolute -top-2 -right-2 w-8 h-8 bg-white rounded-full flex items-center justify-center text-sm text-neutral-900">
                          {step.step}
                        </div>
                      </div>
                      <div className="flex-1">
                        <h3 className="text-neutral-900 text-xl mb-2">{step.title}</h3>
                        <p className="text-neutral-600 text-sm mb-3">{step.description}</p>
                        {activeTab === index && (
                          <div className="flex flex-wrap gap-2">
                            {step.features.map((feature, i) => (
                              <span key={i} className="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
                                ✓ {feature}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>

              {/* Tab Image */}
              <div className="relative">
                {processSteps.map((step, index) => (
                  <div
                    key={index}
                    className={`transition-opacity duration-500 ${
                      activeTab === index ? 'opacity-100' : 'opacity-0 absolute inset-0'
                    }`}
                  >
                    <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                      <img
                        src={step.image}
                        alt={step.title}
                        className="w-full h-[500px] object-cover"
                      />
                      <div className={`absolute inset-0 bg-gradient-to-t ${step.color} opacity-20`} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Why Choose Us */}
          <div className="mb-20">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl text-neutral-900 mb-4">
                Why 1,000+ Homeowners Choose Us
              </h2>
              <p className="text-xl text-neutral-600">
                More than just a flooring marketplace
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {whyChooseUs.map((item, index) => (
                <div key={index} className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all">
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="text-4xl mb-2">{item.icon}</div>
                      <div className="text-white text-sm">{item.stat}</div>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-neutral-900 text-xl mb-2">{item.title}</h3>
                    <p className="text-neutral-600">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Testimonials with Floor Photos */}
          <div className="mb-20">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl text-neutral-900 mb-4">
                Real Stories, Real Floors
              </h2>
              <p className="text-xl text-neutral-600">
                See what our community has accomplished
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <div key={index} className="bg-white rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all">
                  {/* Floor Photo */}
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={testimonial.floorImage}
                      alt={testimonial.floor}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm px-4 py-2 rounded-full text-sm text-neutral-900">
                      {testimonial.floor}
                    </div>
                  </div>

                  <div className="p-6">
                    {/* Stars */}
                    <div className="flex gap-1 mb-4">
                      {Array.from({ length: testimonial.rating }).map((_, i) => (
                        <svg key={i} className="w-5 h-5 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>

                    <p className="text-neutral-700 italic mb-6">"{testimonial.text}"</p>

                    {/* Author */}
                    <div className="flex items-center gap-3 border-t border-neutral-100 pt-4">
                      <img
                        src={testimonial.image}
                        alt={testimonial.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div>
                        <div className="text-neutral-900">{testimonial.name}</div>
                        <div className="text-sm text-neutral-600">{testimonial.location}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Action Cards */}
          <div className="grid md:grid-cols-3 gap-8 mb-20">
            <button
              onClick={() => onNavigate('visualizer')}
              className="group relative bg-gradient-to-br from-purple-600 to-indigo-600 rounded-3xl p-10 text-white overflow-hidden shadow-xl hover:shadow-2xl transition-all hover:scale-105"
            >
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-20" />
              <div className="relative">
                <div className="text-6xl mb-4">📸</div>
                <h3 className="text-white text-2xl mb-3">Try Room Visualizer</h3>
                <p className="text-purple-100 mb-6">Upload your room photo and see any floor in real-time</p>
                <div className="inline-flex items-center gap-2 text-white">
                  <span>Start Visualizing</span>
                  <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </div>
              </div>
            </button>

            <button
              onClick={() => onNavigate('chat')}
              className="group relative bg-gradient-to-br from-blue-600 to-cyan-600 rounded-3xl p-10 text-white overflow-hidden shadow-xl hover:shadow-2xl transition-all hover:scale-105"
            >
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-20" />
              <div className="relative">
                <div className="text-6xl mb-4">💬</div>
                <h3 className="text-white text-2xl mb-3">Ask AI Assistant</h3>
                <p className="text-blue-100 mb-6">Get instant expert advice and recommendations 24/7</p>
                <div className="inline-flex items-center gap-2 text-white">
                  <span>Chat Now</span>
                  <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </div>
              </div>
            </button>

            <button
              onClick={() => onNavigate('contractors')}
              className="group relative bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white overflow-hidden shadow-xl hover:shadow-2xl transition-all hover:scale-105"
            >
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-20" />
              <div className="relative">
                <div className="text-6xl mb-4">👷</div>
                <h3 className="text-white text-2xl mb-3">Find Contractors</h3>
                <p className="text-amber-100 mb-6">Compare quotes from verified pros near you</p>
                <div className="inline-flex items-center gap-2 text-white">
                  <span>Get Quotes</span>
                  <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </div>
              </div>
            </button>
          </div>

          {/* Final CTA */}
          <div className="bg-gradient-to-br from-neutral-900 to-neutral-800 rounded-3xl p-12 md:p-16 text-center text-white relative overflow-hidden">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1600&q=80')] opacity-10 bg-cover bg-center" />
            <div className="relative z-10">
              <h2 className="text-white text-4xl md:text-5xl mb-6">
                Ready to Transform Your Space?
              </h2>
              <p className="text-neutral-300 text-xl mb-10 max-w-2xl mx-auto">
                Start exploring flooring options, customize your design, and connect with professional installers today
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => onNavigate('flooring')}
                  className="px-10 py-5 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-all shadow-2xl text-lg"
                >
                  Browse All Flooring
                </button>
                <button
                  onClick={() => onNavigate('visualizer')}
                  className="px-10 py-5 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-all border-2 border-white/30 text-lg"
                >
                  Try Visualizer Free
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}