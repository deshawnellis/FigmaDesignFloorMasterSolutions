import { useState } from 'react';
import { tileMaterials, tileSizes } from '../../data/tileMaterials';

interface TileCustomizerProps {
  materialId: string;
  onBack: () => void;
  onComplete: (configuration: TileConfiguration) => void;
}

export interface TileConfiguration {
  materialId: string;
  size: string;
  finish: string;
  color: string;
  pattern: string;
  groutColor: string;
  groutWidth: string;
  edgeTrim: string;
}

const finishes = [
  { id: 'polished', label: 'Polished', description: 'Shiny, reflective surface' },
  { id: 'glazed', label: 'Glazed', description: 'Glass-like protective coating' },
  { id: 'matte', label: 'Matte/Satin', description: 'Low sheen, modern look' },
  { id: 'honed', label: 'Honed', description: 'Smooth but not shiny' },
  { id: 'textured', label: 'Textured', description: 'Raised surface for grip' },
  { id: 'natural', label: 'Natural Cleft', description: 'Rough natural surface' }
];

const colors = [
  { id: 'white', label: 'White/Bright White', family: 'Light' },
  { id: 'cream', label: 'Cream/Ivory', family: 'Light' },
  { id: 'beige', label: 'Beige', family: 'Neutral' },
  { id: 'gray-light', label: 'Light Gray', family: 'Neutral' },
  { id: 'gray', label: 'Gray', family: 'Neutral' },
  { id: 'gray-dark', label: 'Dark Gray/Charcoal', family: 'Dark' },
  { id: 'black', label: 'Black', family: 'Dark' },
  { id: 'brown-light', label: 'Light Brown/Tan', family: 'Warm' },
  { id: 'brown', label: 'Brown', family: 'Warm' },
  { id: 'wood-light', label: 'Light Wood Tone', family: 'Warm' },
  { id: 'wood-medium', label: 'Medium Wood Tone', family: 'Warm' },
  { id: 'wood-dark', label: 'Dark Wood Tone', family: 'Dark' },
  { id: 'blue', label: 'Blue', family: 'Bold' },
  { id: 'green', label: 'Green', family: 'Bold' },
  { id: 'terracotta', label: 'Terracotta/Rust', family: 'Bold' }
];

const patterns = [
  { id: 'straight', label: 'Straight Stack', description: 'Aligned grid pattern', image: 'https://images.unsplash.com/photo-1642678751244-296d18c4cab3?w=400' },
  { id: 'brick', label: 'Running Bond/Brick', description: 'Offset brick pattern', image: 'https://images.unsplash.com/photo-1695191388218-f6259600223f?w=400' },
  { id: 'herringbone', label: 'Herringbone', description: 'V-shaped zigzag pattern', image: 'https://images.unsplash.com/photo-1761053130711-2515ef532bb5?w=400' },
  { id: 'diagonal', label: 'Diagonal', description: '45-degree angle', image: 'https://images.unsplash.com/photo-1650047236599-cd639f36b9d1?w=400' },
  { id: 'basketweave', label: 'Basketweave', description: 'Woven appearance', image: 'https://images.unsplash.com/photo-1731045521151-07a0fe502009?w=400' },
  { id: 'versailles', label: 'Versailles', description: 'French pattern with multiple sizes', image: 'https://images.unsplash.com/photo-1669643219984-2ff3eea887a0?w=400' }
];

const groutColors = [
  { id: 'white', label: 'White', description: 'Bright and clean' },
  { id: 'ivory', label: 'Ivory', description: 'Soft off-white' },
  { id: 'gray-light', label: 'Light Gray', description: 'Subtle neutral' },
  { id: 'gray', label: 'Gray', description: 'Popular neutral' },
  { id: 'gray-dark', label: 'Dark Gray', description: 'Modern contrast' },
  { id: 'black', label: 'Black', description: 'Bold contrast' },
  { id: 'match-tile', label: 'Match Tile Color', description: 'Seamless appearance' }
];

const groutWidths = [
  { id: '1/16', label: '1/16 inch', description: 'Minimal grout line, rectified tiles' },
  { id: '1/8', label: '1/8 inch', description: 'Thin grout line, common' },
  { id: '1/4', label: '1/4 inch', description: 'Standard grout line' },
  { id: '3/8', label: '3/8 inch', description: 'Wider grout line' },
  { id: '1/2', label: '1/2 inch', description: 'Wide grout line, rustic look' }
];

const edgeTrims = [
  { id: 'none', label: 'No Trim', description: 'Standard tile edge' },
  { id: 'bullnose', label: 'Bullnose', description: 'Rounded finished edge' },
  { id: 'schluter', label: 'Schluter Edge', description: 'Metal edge profile' },
  { id: 'pencil', label: 'Pencil Trim', description: 'Narrow rounded edge' },
  { id: 'chair-rail', label: 'Chair Rail', description: 'Decorative molding trim' }
];

export function TileCustomizer({ materialId, onBack, onComplete }: TileCustomizerProps) {
  const [step, setStep] = useState(1);
  const [size, setSize] = useState('12x12');
  const [finish, setFinish] = useState('glazed');
  const [color, setColor] = useState('beige');
  const [pattern, setPattern] = useState('straight');
  const [groutColor, setGroutColor] = useState('gray');
  const [groutWidth, setGroutWidth] = useState('1/8');
  const [edgeTrim, setEdgeTrim] = useState('none');

  const material = tileMaterials.find(m => m.id === materialId);
  const totalSteps = 4;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    }
  };

  const handlePrevious = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleComplete = () => {
    const configuration: TileConfiguration = {
      materialId,
      size,
      finish,
      color,
      pattern,
      groutColor,
      groutWidth,
      edgeTrim
    };
    onComplete(configuration);
  };

  if (!material) {
    return null;
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-5xl mx-auto px-6 py-8 md:ml-64">
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Material Selection</span>
          </button>
          
          <h1 className="text-neutral-900 mb-2">Customize Your {material.name} Tile</h1>
          <p className="text-neutral-600">
            Step {step} of {totalSteps}: Design your perfect tile installation
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            {['Size & Finish', 'Color', 'Layout Pattern', 'Grout & Trim'].map((label, idx) => (
              <div key={idx} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                  step > idx + 1 ? 'bg-amber-600 text-white' :
                  step === idx + 1 ? 'bg-amber-600 text-white' :
                  'bg-neutral-200 text-neutral-500'
                }`}>
                  {step > idx + 1 ? '✓' : idx + 1}
                </div>
                {idx < 3 && <div className={`w-16 h-1 mx-2 ${step > idx + 1 ? 'bg-amber-600' : 'bg-neutral-200'}`} />}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-8 mb-6">
          {/* Step 1: Size & Finish */}
          {step === 1 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Select Tile Size & Finish</h2>
              
              <div className="mb-8">
                <h3 className="text-neutral-700 mb-4">Tile Size</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {tileSizes.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setSize(s.id)}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        size === s.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900 text-sm">{s.dimensions}</span>
                        {size === s.id && (
                          <svg className="w-4 h-4 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-xs">{s.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-neutral-700 mb-4">Surface Finish</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {finishes.map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setFinish(f.id)}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        finish === f.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900">{f.label}</span>
                        {finish === f.id && (
                          <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-sm">{f.description}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Color */}
          {step === 2 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Choose Tile Color</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {colors.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setColor(c.id)}
                    className={`p-4 border-2 rounded-lg text-left transition-all ${
                      color === c.id
                        ? 'border-amber-600 bg-amber-50'
                        : 'border-neutral-200 hover:border-amber-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div>
                        <span className="text-neutral-900 text-sm block">{c.label}</span>
                        <span className="text-neutral-500 text-xs">{c.family}</span>
                      </div>
                      {color === c.id && (
                        <svg className="w-5 h-5 text-amber-600 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 3: Layout Pattern */}
          {step === 3 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Choose Layout Pattern</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {patterns.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setPattern(p.id)}
                    className={`border-2 rounded-lg overflow-hidden text-left transition-all ${
                      pattern === p.id
                        ? 'border-amber-600'
                        : 'border-neutral-200 hover:border-amber-300'
                    }`}
                  >
                    <div className="aspect-video overflow-hidden bg-neutral-100">
                      <img src={p.image} alt={p.label} className="w-full h-full object-cover" />
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900">{p.label}</span>
                        {pattern === p.id && (
                          <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-sm">{p.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 4: Grout & Trim */}
          {step === 4 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Select Grout & Edge Trim</h2>
              
              <div className="mb-8">
                <h3 className="text-neutral-700 mb-4">Grout Color</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {groutColors.map((g) => (
                    <button
                      key={g.id}
                      onClick={() => setGroutColor(g.id)}
                      className={`p-3 border-2 rounded-lg text-left transition-all ${
                        groutColor === g.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900 text-sm">{g.label}</span>
                        {groutColor === g.id && (
                          <svg className="w-4 h-4 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-xs">{g.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-neutral-700 mb-4">Grout Width</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {groutWidths.map((w) => (
                    <button
                      key={w.id}
                      onClick={() => setGroutWidth(w.id)}
                      className={`p-3 border-2 rounded-lg text-left transition-all ${
                        groutWidth === w.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900 text-sm">{w.label}</span>
                        {groutWidth === w.id && (
                          <svg className="w-4 h-4 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-xs">{w.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-neutral-700 mb-4">Edge Trim/Transition</h3>
                <div className="space-y-3">
                  {edgeTrims.map((e) => (
                    <button
                      key={e.id}
                      onClick={() => setEdgeTrim(e.id)}
                      className={`w-full p-4 border-2 rounded-lg text-left transition-all ${
                        edgeTrim === e.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-neutral-900 block mb-1">{e.label}</span>
                          <p className="text-neutral-600 text-sm">{e.description}</p>
                        </div>
                        {edgeTrim === e.id && (
                          <svg className="w-5 h-5 text-amber-600 flex-shrink-0 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={handlePrevious}
            disabled={step === 1}
            className={`px-6 py-3 border-2 border-neutral-300 rounded-lg transition-colors ${
              step === 1
                ? 'text-neutral-400 cursor-not-allowed'
                : 'text-neutral-700 hover:bg-neutral-50'
            }`}
          >
            Previous
          </button>

          {step < totalSteps ? (
            <button
              onClick={handleNext}
              className="px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
            >
              Next Step
            </button>
          ) : (
            <button
              onClick={handleComplete}
              className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              Complete Configuration
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
