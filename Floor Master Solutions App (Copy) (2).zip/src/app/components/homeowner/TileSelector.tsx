import { useState, useMemo } from 'react';
import { tileMaterials, TileMaterial } from '../../data/tileMaterials';

interface TileSelectorProps {
  onSelectMaterial: (materialId: string) => void;
  onBack: () => void;
}

export function TileSelector({ onSelectMaterial, onBack }: TileSelectorProps) {
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedPriceCategory, setSelectedPriceCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'durability' | 'water'>('name');
  const [showDetails, setShowDetails] = useState<string | null>(null);

  const filteredMaterials = useMemo(() => {
    let filtered = tileMaterials.filter((material) => {
      const matchesType = selectedType === 'all' || material.type === selectedType;
      const matchesPrice = selectedPriceCategory === 'all' || material.priceCategory === selectedPriceCategory;
      return matchesType && matchesPrice;
    });

    if (sortBy === 'durability') {
      filtered = [...filtered].sort((a, b) => b.durability - a.durability);
    } else if (sortBy === 'water') {
      filtered = [...filtered].sort((a, b) => b.waterResistance - a.waterResistance);
    } else {
      filtered = [...filtered].sort((a, b) => a.name.localeCompare(b.name));
    }

    return filtered;
  }, [selectedType, selectedPriceCategory, sortBy]);

  const handleReset = () => {
    setSelectedType('all');
    setSelectedPriceCategory('all');
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Flooring Types</span>
          </button>
          
          <h1 className="text-neutral-900 mb-2">Choose Your Tile Material</h1>
          <p className="text-neutral-600">
            Select from {tileMaterials.length} different tile materials to customize
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-neutral-900 text-sm">Filter Materials</h3>
            <button
              onClick={handleReset}
              className="text-amber-600 hover:text-amber-700 text-sm transition-colors"
            >
              Reset Filters
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label htmlFor="type" className="block text-neutral-700 mb-2 text-sm">
                Tile Type
              </label>
              <select
                id="type"
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              >
                <option value="all">All Types</option>
                <option value="Ceramic">Ceramic</option>
                <option value="Porcelain">Porcelain</option>
                <option value="Natural Stone">Natural Stone</option>
                <option value="Glass">Glass</option>
                <option value="Wood-Look">Wood-Look</option>
              </select>
            </div>

            <div>
              <label htmlFor="priceCategory" className="block text-neutral-700 mb-2 text-sm">
                Price Range
              </label>
              <select
                id="priceCategory"
                value={selectedPriceCategory}
                onChange={(e) => setSelectedPriceCategory(e.target.value)}
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              >
                <option value="all">All Prices</option>
                <option value="Budget">Budget</option>
                <option value="Mid-Range">Mid-Range</option>
                <option value="Premium">Premium</option>
                <option value="Luxury">Luxury</option>
              </select>
            </div>

            <div>
              <label htmlFor="sort" className="block text-neutral-700 mb-2 text-sm">
                Sort By
              </label>
              <select
                id="sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'name' | 'durability' | 'water')}
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              >
                <option value="name">Name</option>
                <option value="durability">Durability</option>
                <option value="water">Water Resistance</option>
              </select>
            </div>
          </div>

          <div className="text-neutral-600 text-sm pt-4 border-t border-neutral-200">
            Showing {filteredMaterials.length} of {tileMaterials.length} materials
          </div>
        </div>

        {/* Materials Grid */}
        {filteredMaterials.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMaterials.map((material) => (
              <div
                key={material.id}
                className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden"
              >
                <div className="aspect-video overflow-hidden bg-neutral-100">
                  <img
                    src={material.image}
                    alt={material.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                
                <div className="p-6">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="text-neutral-900 mb-1">{material.name}</h3>
                      <p className="text-neutral-500 text-xs">{material.type}</p>
                    </div>
                    <span className={`px-2 py-1 rounded text-xs flex-shrink-0 ml-2 ${
                      material.priceCategory === 'Budget' ? 'bg-green-100 text-green-700' :
                      material.priceCategory === 'Mid-Range' ? 'bg-blue-100 text-blue-700' :
                      material.priceCategory === 'Premium' ? 'bg-purple-100 text-purple-700' :
                      'bg-amber-100 text-amber-700'
                    }`}>
                      {material.priceCategory}
                    </span>
                  </div>
                  
                  <p className="text-neutral-600 text-sm mb-4 line-clamp-2">
                    {material.description}
                  </p>
                  
                  {/* Key Info */}
                  <div className="space-y-2 text-sm mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500">Durability:</span>
                      <div className="flex items-center gap-1">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <div
                            key={i}
                            className={`w-2 h-2 rounded-full ${
                              i < material.durability ? 'bg-amber-600' : 'bg-neutral-300'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500">Water Resist:</span>
                      <div className="flex items-center gap-1">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <div
                            key={i}
                            className={`w-2 h-2 rounded-full ${
                              i < material.waterResistance ? 'bg-blue-600' : 'bg-neutral-300'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500">Maintenance:</span>
                      <span className="text-neutral-700">{material.maintenance}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500">Porosity:</span>
                      <span className="text-neutral-700 text-xs">{material.porosity}</span>
                    </div>
                  </div>

                  {/* Expandable Details */}
                  {showDetails === material.id && (
                    <div className="mb-4 p-4 bg-neutral-50 rounded-lg space-y-3 text-sm">
                      <div>
                        <div className="text-neutral-700 mb-1">Best For:</div>
                        <div className="flex flex-wrap gap-1">
                          {material.bestFor.map((use, idx) => (
                            <span key={idx} className="px-2 py-0.5 bg-white rounded text-xs text-neutral-600">
                              {use}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div>
                        <div className="text-neutral-700 mb-1">Key Characteristics:</div>
                        <ul className="space-y-1">
                          {material.characteristics.map((char, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-neutral-600 text-xs">
                              <svg className="w-3 h-3 text-amber-600 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                              <span>{char}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShowDetails(showDetails === material.id ? null : material.id)}
                      className="flex-1 px-4 py-2 border border-neutral-300 text-neutral-700 rounded-lg hover:bg-neutral-50 transition-colors text-sm"
                    >
                      {showDetails === material.id ? 'Hide Details' : 'View Details'}
                    </button>
                    <button
                      onClick={() => onSelectMaterial(material.id)}
                      className="flex-1 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors text-sm"
                    >
                      Customize
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-xl">
            <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <h3 className="text-neutral-900 mb-2">No materials found</h3>
            <p className="text-neutral-600 mb-4">
              Try adjusting your filters to see more options
            </p>
            <button
              onClick={handleReset}
              className="px-6 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        )}

        {/* Info Cards */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h4 className="text-neutral-900 mb-2">Porosity Explained</h4>
            <p className="text-neutral-600 text-sm">
              <strong>Impervious:</strong> &lt;0.5% absorption (best for wet areas)<br/>
              <strong>Vitreous:</strong> 0.5-3% absorption<br/>
              <strong>Semi-Vitreous:</strong> 3-7% absorption<br/>
              <strong>Non-Vitreous:</strong> &gt;7% absorption
            </p>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h4 className="text-neutral-900 mb-2">Tile vs Location</h4>
            <p className="text-neutral-600 text-sm">
              <strong>Bathrooms:</strong> Use impervious tiles<br/>
              <strong>Kitchens:</strong> Porcelain or ceramic<br/>
              <strong>Floors:</strong> Check durability rating<br/>
              <strong>Walls:</strong> Any tile type works
            </p>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h4 className="text-neutral-900 mb-2">Natural Stone Care</h4>
            <p className="text-neutral-600 text-sm">
              Natural stone tiles like marble, granite, and travertine require regular sealing to protect against stains and moisture. Plan for resealing every 1-2 years.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
