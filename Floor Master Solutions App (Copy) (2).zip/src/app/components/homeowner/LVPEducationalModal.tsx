interface LVPEducationalModalProps {
  topic: string;
  onClose: () => void;
}

export function LVPEducationalModal({ topic, onClose }: LVPEducationalModalProps) {
  const content: { [key: string]: any } = {
    'wear-layer': {
      title: 'Understanding Wear Layer Thickness',
      subtitle: 'The protective clear coat that determines your floor\'s lifespan',
      sections: [
        {
          heading: 'What is a Wear Layer?',
          text: 'The wear layer is a clear, protective coating on top of the LVP design layer. It\'s made from urethane or aluminum oxide and protects against scratches, stains, and daily wear. Think of it like a screen protector for your phone - but for your floor!',
          image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=600&q=80'
        },
        {
          heading: 'Thickness Matters',
          text: '6 mil (0.006 inches): Good for low-traffic areas like bedrooms. Budget-friendly but less durable.\n\n12 mil (0.012 inches): Perfect for most homes. Handles living rooms, hallways, and kitchens with ease. Best value for money.\n\n20 mil (0.020 inches): Heavy-duty protection for high-traffic homes with pets and kids. Can handle light commercial use.\n\n30 mil (0.030 inches): Commercial grade. Overkill for most homes, but perfect for rental properties or extremely high-traffic areas.',
          comparison: true
        },
        {
          heading: 'How to Choose',
          text: 'Low Traffic (Bedrooms, guest rooms): 6-12 mil\nModerate Traffic (Living rooms, kitchens): 12-20 mil\nHigh Traffic (Busy households, pets, kids): 20-30 mil\nCommercial (Retail, offices): 30+ mil',
          image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&q=80'
        }
      ]
    },
    'thickness': {
      title: 'Total Plank Thickness Explained',
      subtitle: 'How thick should your LVP be?',
      sections: [
        {
          heading: 'What\'s Included in Total Thickness?',
          text: 'Total thickness includes the wear layer, design/print layer, core layer, and backing. It affects how the floor feels underfoot, sound transmission, and overall durability.',
          image: 'https://images.unsplash.com/photo-1615876234886-fd9a39fda97f?w=600&q=80'
        },
        {
          heading: 'Thickness Comparison',
          text: '4mm (0.16"): Entry-level option. Feels thin underfoot. Best for rentals or temporary solutions. Less sound dampening.\n\n6mm (0.24"): Industry standard. Good balance of performance and price. Feels solid without being heavy. Most popular choice.\n\n8mm (0.31"): Premium feel. Excellent sound dampening. Feels more like hardwood. Best for luxury installations.',
          comparison: true
        },
        {
          heading: 'Important Considerations',
          text: 'Thicker doesn\'t always mean better quality - the wear layer matters more for durability. Thicker floors do provide better sound insulation and feel more solid. Consider door clearances - thicker floors may require trimming doors.',
          image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=600&q=80'
        }
      ]
    },
    'core': {
      title: 'Core Construction Types',
      subtitle: 'The foundation of your LVP - what\'s inside matters',
      sections: [
        {
          heading: 'Standard Flexible Core',
          text: 'Traditional vinyl construction that bends easily. Requires a perfectly flat subfloor. Less expensive but less forgiving during installation. Best for: Level concrete slabs, smooth existing floors, budget installations.',
          image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=600&q=80'
        },
        {
          heading: 'Rigid Core (SPC/WPC)',
          text: 'SPC (Stone Plastic Composite): Dense, limestone-based core. Extremely stable, won\'t expand/contract with temperature. Very durable and waterproof.\n\nWPC (Wood Plastic Composite): Wood pulp and plastic blend. Slightly softer and warmer than SPC. Better sound dampening. More comfortable underfoot.\n\nBoth types: Can handle minor subfloor imperfections. Most popular choice for residential installations.',
          image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=600&q=80',
          comparison: true
        },
        {
          heading: 'Enhanced Backing',
          text: 'Includes additional cork or foam padding attached to the bottom. Benefits: Superior noise reduction, extra cushioning, warmer feel in winter. Ideal for: Multi-story homes, condos with noise regulations, homes over concrete.',
          image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=600&q=80'
        }
      ]
    },
    'texture': {
      title: 'Surface Textures Explained',
      subtitle: 'How texture affects look, feel, and maintenance',
      sections: [
        {
          heading: 'Smooth Surface',
          text: 'Clean, contemporary look with minimal texture. Easiest to clean - dirt doesn\'t get trapped. Shows scratches more easily. Best for: Modern homes, minimalist design, high-gloss finishes, those who prioritize easy cleaning.',
          image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=600&q=80'
        },
        {
          heading: 'Embossed Texture',
          text: 'Texture follows the printed wood grain pattern - called "embossed in register" (EIR). Looks and feels more like real wood. Hides minor scratches and wear. Most popular choice. Best for: Those wanting authentic wood feel, families with kids/pets, traditional to transitional design styles.',
          image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&q=80'
        },
        {
          heading: 'Hand-Scraped',
          text: 'Deep, irregular texture mimicking hand-scraped wood planks. Rustic, aged appearance. Excellent at hiding imperfections. Slightly harder to clean than smooth. Best for: Farmhouse, rustic, or country decor, those who love character and texture, high-traffic areas needing durability.',
          image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=600&q=80'
        },
        {
          heading: 'Wire-Brushed',
          text: 'Subtle texture with soft grain lines. Comfortable balance between smooth and heavily textured. Hides wear well while remaining easy to clean. Best for: Transitional homes, those wanting texture without going rustic, versatile option that suits many styles.',
          image: 'https://images.unsplash.com/photo-1615876234886-fd9a39fda97f?w=600&q=80'
        }
      ]
    },
    'installation': {
      title: 'Installation Methods Compared',
      subtitle: 'How your floor gets installed',
      sections: [
        {
          heading: 'Click-Lock (Floating Floor)',
          text: 'Planks click together like puzzle pieces. Nothing is attached to subfloor - floor "floats" on top. Pros: DIY-friendly, fast installation, can be removed/reused, no messy adhesive, walk on immediately. Cons: Can feel slightly hollow, may shift without proper perimeter molding. Best for: DIY installers, renters (if allowed), quick renovations, most residential applications.',
          image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=600&q=80'
        },
        {
          heading: 'Glue-Down',
          text: 'Each plank is glued directly to the subfloor with adhesive. Pros: Most permanent, no hollow feeling, quieter, suitable for commercial use, no expansion gaps needed. Cons: Professional installation recommended, harder to remove, messy, longer installation time, waiting for adhesive to cure. Best for: Commercial spaces, high-traffic areas, permanent installations, those wanting the most solid feel.',
          image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=600&q=80'
        },
        {
          heading: 'Loose-Lay',
          text: 'Heavy vinyl planks held in place by friction and their own weight. No clicking, no glue. Pros: Easiest installation, truly temporary, perfect for rentals, can replace individual planks easily. Cons: May shift over time, requires heavier/thicker planks, needs perfect subfloor, edges must be secured. Best for: Rental properties, temporary installations, frequently changed spaces, DIY beginners.',
          image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=600&q=80'
        }
      ]
    },
    'dimensions': {
      title: 'Plank Dimensions Guide',
      subtitle: 'How size affects your room\'s appearance',
      sections: [
        {
          heading: 'Width Matters',
          text: '5" Wide Planks: Traditional, classic look. Many seams. Makes small rooms look busier. Good for: Traditional homes, period-appropriate renovations.\n\n7" Wide Planks: Modern standard. Balanced look. Fewer seams than 5". Good for: Most homes, versatile width that works everywhere.\n\n9" Wide Planks: Contemporary, spacious feel. Very few seams. Makes rooms look larger. Good for: Modern homes, open floor plans, those wanting a high-end look.',
          image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&q=80',
          comparison: true
        },
        {
          heading: 'Length Considerations',
          text: '36" Planks: More seams, easier to work with in small spaces. Better for DIY beginners.\n\n48" Planks: Industry standard. Good balance of ease and fewer seams.\n\n60" Planks: Fewer seams, more elegant look. Harder to maneuver during installation. Creates more waste.',
          image: 'https://images.unsplash.com/photo-1615876234886-fd9a39fda97f?w=600&q=80'
        },
        {
          heading: 'Visual Impact',
          text: 'Wider, longer planks make rooms appear larger. Narrower planks give a traditional, detailed look. Consider your room size - large planks can overwhelm tiny bathrooms. Plan installation direction - running planks lengthwise makes rooms look longer.',
          image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=600&q=80'
        }
      ]
    }
  };

  const currentContent = content[topic] || content['wear-layer'];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div 
        className="bg-white rounded-2xl max-w-4xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 rounded-t-2xl">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-white text-2xl mb-2">{currentContent.title}</h2>
              <p className="text-blue-100">{currentContent.subtitle}</p>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Content Sections */}
        <div className="p-6 space-y-8">
          {currentContent.sections.map((section: any, index: number) => (
            <div key={index} className="space-y-4">
              <h3 className="text-neutral-900 text-xl flex items-center gap-2">
                <span className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                  {index + 1}
                </span>
                {section.heading}
              </h3>
              
              {section.image && (
                <div className="rounded-xl overflow-hidden">
                  <img 
                    src={section.image} 
                    alt={section.heading}
                    className="w-full h-64 object-cover"
                  />
                </div>
              )}
              
              <div className={`${section.comparison ? 'bg-amber-50 border border-amber-200' : 'bg-neutral-50'} rounded-xl p-5`}>
                {section.text.split('\n\n').map((paragraph: string, pIndex: number) => (
                  <p key={pIndex} className="text-neutral-700 leading-relaxed mb-3 last:mb-0 whitespace-pre-line">
                    {paragraph}
                  </p>
                ))}
              </div>
            </div>
          ))}

          {/* Bottom CTA */}
          <div className="bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-xl p-6 mt-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
              </div>
              <div>
                <h4 className="text-green-900 mb-2">Pro Tip</h4>
                <p className="text-green-800">
                  Still not sure which option is right for you? Our AI chat assistant can help you choose based on your specific needs, lifestyle, and budget. Just describe your situation and get personalized recommendations!
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-neutral-50 border-t border-neutral-200 p-6 rounded-b-2xl">
          <button
            onClick={onClose}
            className="w-full bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 transition-colors"
          >
            Got it! Continue Customizing
          </button>
        </div>
      </div>
    </div>
  );
}
