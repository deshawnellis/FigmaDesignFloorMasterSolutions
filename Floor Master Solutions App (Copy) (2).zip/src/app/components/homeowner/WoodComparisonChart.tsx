import { useState, useMemo } from 'react';
import { woodSpecies, WoodSpecies } from '../../data/woodSpecies';

interface WoodComparisonChartProps {
  onClose: () => void;
  onSelectSpecies?: (speciesId: string) => void;
}

export function WoodComparisonChart({ onClose, onSelectSpecies }: WoodComparisonChartProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPriceRange, setSelectedPriceRange] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'hardness' | 'price'>('hardness');
  const [compareMode, setCompareMode] = useState(false);
  const [selectedForComparison, setSelectedForComparison] = useState<Set<string>>(new Set());
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('table');

  const filteredSpecies = useMemo(() => {
    let filtered = woodSpecies.filter((species) => {
      const matchesCategory = selectedCategory === 'all' || species.category === selectedCategory;
      const matchesPrice = selectedPriceRange === 'all' || species.priceCategory === selectedPriceRange;
      return matchesCategory && matchesPrice;
    });

    // Sort
    if (sortBy === 'hardness') {
      filtered = [...filtered].sort((a, b) => b.hardness - a.hardness);
    } else if (sortBy === 'price') {
      const priceOrder = { 'Budget': 1, 'Mid-Range': 2, 'Premium': 3, 'Luxury': 4 };
      filtered = [...filtered].sort((a, b) => priceOrder[a.priceCategory] - priceOrder[b.priceCategory]);
    } else {
      filtered = [...filtered].sort((a, b) => a.name.localeCompare(b.name));
    }

    return filtered;
  }, [selectedCategory, selectedPriceRange, sortBy]);

  const comparisonSpecies = useMemo(() => {
    return woodSpecies.filter(species => selectedForComparison.has(species.id));
  }, [selectedForComparison]);

  const toggleComparison = (speciesId: string) => {
    const newSet = new Set(selectedForComparison);
    if (newSet.has(speciesId)) {
      newSet.delete(speciesId);
    } else {
      if (newSet.size < 4) {
        newSet.add(speciesId);
      }
    }
    setSelectedForComparison(newSet);
  };

  const getHardnessLevel = (hardness: number): { label: string; color: string } => {
    if (hardness < 1000) return { label: 'Soft', color: 'text-amber-600' };
    if (hardness < 1300) return { label: 'Medium', color: 'text-green-600' };
    if (hardness < 1600) return { label: 'Hard', color: 'text-blue-600' };
    return { label: 'Very Hard', color: 'text-purple-600' };
  };

  const getDurabilityStars = (durability: number) => {
    return Array.from({ length: 5 }, (_, i) => i < durability);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div 
        className="bg-white rounded-2xl max-w-7xl w-full max-h-[90vh] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-600 to-amber-700 text-white p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-white text-2xl mb-2">Wood Species Comparison Chart</h2>
              <p className="text-amber-100">Compare {woodSpecies.length} wood species to find your perfect match</p>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* View Mode Tabs */}
          <div className="flex gap-2">
            <button
              onClick={() => setViewMode('table')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                viewMode === 'table'
                  ? 'bg-white text-amber-600'
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              Table View
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                viewMode === 'grid'
                  ? 'bg-white text-amber-600'
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              Visual Cards
            </button>
            <button
              onClick={() => setCompareMode(!compareMode)}
              className={`px-4 py-2 rounded-lg transition-colors ml-auto ${
                compareMode
                  ? 'bg-blue-600 text-white'
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              {compareMode ? `Compare Selected (${selectedForComparison.size}/4)` : 'Compare Mode'}
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="border-b border-neutral-200 p-4 bg-neutral-50">
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <label className="text-sm text-neutral-700">Category:</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 py-1.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
              >
                <option value="all">All Types</option>
                <option value="Domestic Hardwood">Domestic Hardwood</option>
                <option value="Exotic Hardwood">Exotic Hardwood</option>
                <option value="Softwood">Softwood</option>
                <option value="Bamboo">Bamboo</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-sm text-neutral-700">Price:</label>
              <select
                value={selectedPriceRange}
                onChange={(e) => setSelectedPriceRange(e.target.value)}
                className="px-3 py-1.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
              >
                <option value="all">All Prices</option>
                <option value="Budget">Budget</option>
                <option value="Mid-Range">Mid-Range</option>
                <option value="Premium">Premium</option>
                <option value="Luxury">Luxury</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-sm text-neutral-700">Sort by:</label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-3 py-1.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
              >
                <option value="name">Name</option>
                <option value="hardness">Hardness Rating</option>
                <option value="price">Price</option>
              </select>
            </div>

            <button
              onClick={() => {
                setSelectedCategory('all');
                setSelectedPriceRange('all');
                setSelectedForComparison(new Set());
              }}
              className="ml-auto text-sm text-amber-600 hover:text-amber-700"
            >
              Reset All
            </button>
          </div>
        </div>

        {/* Comparison View - Shows when items are selected */}
        {compareMode && selectedForComparison.size > 0 && (
          <div className="border-b border-neutral-200 p-4 bg-blue-50">
            <h3 className="text-neutral-900 mb-3">Side-by-Side Comparison</h3>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {comparisonSpecies.map((species) => (
                <div key={species.id} className="bg-white rounded-lg p-3 border-2 border-blue-600">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="text-neutral-900 text-sm">{species.name}</h4>
                    <button
                      onClick={() => toggleComparison(species.id)}
                      className="text-neutral-400 hover:text-neutral-600"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Hardness:</span>
                      <span className="text-neutral-900">{species.hardness}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Price:</span>
                      <span className="text-neutral-900">{species.priceCategory}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Durability:</span>
                      <div className="flex gap-0.5">
                        {getDurabilityStars(species.durability).map((filled, i) => (
                          <svg
                            key={i}
                            className={`w-3 h-3 ${filled ? 'text-amber-400' : 'text-neutral-300'}`}
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {viewMode === 'table' ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-neutral-100 sticky top-0">
                  <tr>
                    {compareMode && <th className="px-4 py-3 text-left text-sm text-neutral-700">Select</th>}
                    <th className="px-4 py-3 text-left text-sm text-neutral-700">Wood Species</th>
                    <th className="px-4 py-3 text-left text-sm text-neutral-700">Image</th>
                    <th className="px-4 py-3 text-left text-sm text-neutral-700">Hardness</th>
                    <th className="px-4 py-3 text-left text-sm text-neutral-700">Durability</th>
                    <th className="px-4 py-3 text-left text-sm text-neutral-700">Color Range</th>
                    <th className="px-4 py-3 text-left text-sm text-neutral-700">Grain Pattern</th>
                    <th className="px-4 py-3 text-left text-sm text-neutral-700">Price</th>
                    <th className="px-4 py-3 text-left text-sm text-neutral-700">Best For</th>
                    {onSelectSpecies && <th className="px-4 py-3 text-left text-sm text-neutral-700">Action</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200">
                  {filteredSpecies.map((species) => {
                    const hardnessLevel = getHardnessLevel(species.hardness);
                    return (
                      <tr key={species.id} className="hover:bg-neutral-50 transition-colors">
                        {compareMode && (
                          <td className="px-4 py-3">
                            <input
                              type="checkbox"
                              checked={selectedForComparison.has(species.id)}
                              onChange={() => toggleComparison(species.id)}
                              disabled={!selectedForComparison.has(species.id) && selectedForComparison.size >= 4}
                              className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-600"
                            />
                          </td>
                        )}
                        <td className="px-4 py-3">
                          <div>
                            <p className="text-neutral-900">{species.name}</p>
                            <p className="text-xs text-neutral-500 italic">{species.scientificName}</p>
                            <p className="text-xs text-neutral-600 mt-1">{species.category}</p>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <img
                            src={species.image}
                            alt={species.name}
                            className="w-20 h-16 object-cover rounded-lg"
                          />
                        </td>
                        <td className="px-4 py-3">
                          <div>
                            <p className={`${hardnessLevel.color}`}>{species.hardness}</p>
                            <p className="text-xs text-neutral-600">{hardnessLevel.label}</p>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex gap-0.5">
                            {getDurabilityStars(species.durability).map((filled, i) => (
                              <svg
                                key={i}
                                className={`w-4 h-4 ${filled ? 'text-amber-400' : 'text-neutral-300'}`}
                                fill="currentColor"
                                viewBox="0 0 20 20"
                              >
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                              </svg>
                            ))}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <p className="text-sm text-neutral-700">{species.colorRange}</p>
                        </td>
                        <td className="px-4 py-3">
                          <p className="text-sm text-neutral-700">{species.grainPattern}</p>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`inline-block px-2 py-1 rounded text-xs ${
                            species.priceCategory === 'Budget' ? 'bg-green-100 text-green-800' :
                            species.priceCategory === 'Mid-Range' ? 'bg-blue-100 text-blue-800' :
                            species.priceCategory === 'Premium' ? 'bg-purple-100 text-purple-800' :
                            'bg-amber-100 text-amber-800'
                          }`}>
                            {species.priceCategory}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <ul className="text-xs text-neutral-600 space-y-1">
                            {species.bestFor.slice(0, 3).map((use, i) => (
                              <li key={i}>• {use}</li>
                            ))}
                          </ul>
                        </td>
                        {onSelectSpecies && (
                          <td className="px-4 py-3">
                            <button
                              onClick={() => onSelectSpecies(species.id)}
                              className="px-3 py-1 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors text-sm"
                            >
                              Select
                            </button>
                          </td>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredSpecies.map((species) => {
                const hardnessLevel = getHardnessLevel(species.hardness);
                return (
                  <div
                    key={species.id}
                    className={`bg-white rounded-xl overflow-hidden border-2 transition-all ${
                      compareMode && selectedForComparison.has(species.id)
                        ? 'border-blue-600 shadow-lg'
                        : 'border-neutral-200 hover:border-amber-300 hover:shadow-lg'
                    }`}
                  >
                    {/* Image */}
                    <div className="relative h-48">
                      <img
                        src={species.image}
                        alt={species.name}
                        className="w-full h-full object-cover"
                      />
                      {compareMode && (
                        <div className="absolute top-3 right-3">
                          <input
                            type="checkbox"
                            checked={selectedForComparison.has(species.id)}
                            onChange={() => toggleComparison(species.id)}
                            disabled={!selectedForComparison.has(species.id) && selectedForComparison.size >= 4}
                            className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-600"
                          />
                        </div>
                      )}
                      <div className="absolute top-3 left-3">
                        <span className={`inline-block px-2 py-1 rounded text-xs ${
                          species.priceCategory === 'Budget' ? 'bg-green-600 text-white' :
                          species.priceCategory === 'Mid-Range' ? 'bg-blue-600 text-white' :
                          species.priceCategory === 'Premium' ? 'bg-purple-600 text-white' :
                          'bg-amber-600 text-white'
                        }`}>
                          {species.priceCategory}
                        </span>
                      </div>
                    </div>

                    {/* Content */}
                    <div className="p-5">
                      <h3 className="text-neutral-900 mb-1">{species.name}</h3>
                      <p className="text-xs text-neutral-500 italic mb-3">{species.scientificName}</p>
                      
                      <div className="space-y-3 mb-4">
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs text-neutral-600">Hardness (Janka):</span>
                            <span className={`text-sm ${hardnessLevel.color}`}>
                              {species.hardness} - {hardnessLevel.label}
                            </span>
                          </div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs text-neutral-600">Durability:</span>
                            <div className="flex gap-0.5">
                              {getDurabilityStars(species.durability).map((filled, i) => (
                                <svg
                                  key={i}
                                  className={`w-4 h-4 ${filled ? 'text-amber-400' : 'text-neutral-300'}`}
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div>
                          <p className="text-xs text-neutral-600 mb-1">Color Range:</p>
                          <p className="text-sm text-neutral-900">{species.colorRange}</p>
                        </div>

                        <div>
                          <p className="text-xs text-neutral-600 mb-1">Grain Pattern:</p>
                          <p className="text-sm text-neutral-900">{species.grainPattern}</p>
                        </div>

                        <div>
                          <p className="text-xs text-neutral-600 mb-1">Best For:</p>
                          <ul className="text-xs text-neutral-700 space-y-0.5">
                            {species.bestFor.slice(0, 3).map((use, i) => (
                              <li key={i}>• {use}</li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <p className="text-xs text-neutral-600 mb-1">Key Characteristics:</p>
                          <div className="flex flex-wrap gap-1">
                            {species.characteristics.slice(0, 3).map((char, i) => (
                              <span key={i} className="text-xs bg-neutral-100 text-neutral-700 px-2 py-1 rounded">
                                {char}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      {onSelectSpecies && (
                        <button
                          onClick={() => onSelectSpecies(species.id)}
                          className="w-full py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
                        >
                          Select This Wood
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Legend Footer */}
        <div className="border-t border-neutral-200 p-4 bg-neutral-50">
          <div className="flex flex-wrap gap-6 text-sm">
            <div>
              <h4 className="text-neutral-900 mb-2">Hardness Guide:</h4>
              <div className="flex gap-3 text-xs">
                <span className="text-amber-600">• Soft (&lt;1000)</span>
                <span className="text-green-600">• Medium (1000-1300)</span>
                <span className="text-blue-600">• Hard (1300-1600)</span>
                <span className="text-purple-600">• Very Hard (1600+)</span>
              </div>
            </div>
            <div>
              <h4 className="text-neutral-900 mb-2">What is Janka Hardness?</h4>
              <p className="text-xs text-neutral-600 max-w-md">
                The Janka test measures the force required to embed a steel ball into wood. Higher numbers mean harder, more dent-resistant floors.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
