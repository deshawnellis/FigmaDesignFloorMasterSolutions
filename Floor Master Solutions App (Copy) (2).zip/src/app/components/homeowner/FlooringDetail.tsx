import { flooringTypes } from '../../data/flooringTypes';

interface FlooringDetailProps {
  flooringId: string;
  onBack: () => void;
}

export function FlooringDetail({ flooringId, onBack }: FlooringDetailProps) {
  const flooring = flooringTypes.find((f) => f.id === flooringId);

  if (!flooring) {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-neutral-900 mb-2">Flooring not found</h2>
          <button
            onClick={onBack}
            className="text-amber-600 hover:text-amber-700"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Back Button */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 transition-colors mb-6"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Back to Flooring
        </button>

        {/* Hero Image */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden mb-8">
          <div className="aspect-[21/9] overflow-hidden bg-neutral-100">
            <img
              src={flooring.image}
              alt={flooring.name}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Overview */}
            <div className="bg-white rounded-2xl shadow-sm p-8">
              <h1 className="text-neutral-900 mb-4">{flooring.name}</h1>
              <p className="text-neutral-600 mb-6">{flooring.description}</p>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-neutral-50 rounded-lg p-4">
                  <div className="text-neutral-500 text-sm mb-1">Price Range</div>
                  <div className="text-neutral-900">{flooring.priceRange}</div>
                </div>
                <div className="bg-neutral-50 rounded-lg p-4">
                  <div className="text-neutral-500 text-sm mb-1">Durability</div>
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div
                        key={i}
                        className={`w-2 h-2 rounded-full ${
                          i < flooring.durability ? 'bg-amber-600' : 'bg-neutral-300'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <div className="bg-neutral-50 rounded-lg p-4">
                  <div className="text-neutral-500 text-sm mb-1">Maintenance</div>
                  <div className={`inline-block px-2 py-1 rounded text-xs ${
                    flooring.maintenance === 'Low' ? 'bg-green-100 text-green-700' :
                    flooring.maintenance === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-orange-100 text-orange-700'
                  }`}>
                    {flooring.maintenance}
                  </div>
                </div>
                <div className="bg-neutral-50 rounded-lg p-4">
                  <div className="text-neutral-500 text-sm mb-1">Lifespan</div>
                  <div className="text-neutral-900">{flooring.lifespan}</div>
                </div>
              </div>
            </div>

            {/* Pros and Cons */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl shadow-sm p-8">
                <h3 className="text-neutral-900 mb-4 flex items-center gap-2">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  Pros
                </h3>
                <ul className="space-y-3">
                  {flooring.pros.map((pro, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <svg className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="text-neutral-600">{pro}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white rounded-2xl shadow-sm p-8">
                <h3 className="text-neutral-900 mb-4 flex items-center gap-2">
                  <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </div>
                  Cons
                </h3>
                <ul className="space-y-3">
                  {flooring.cons.map((con, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <svg className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                      <span className="text-neutral-600">{con}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Best For */}
            <div className="bg-white rounded-2xl shadow-sm p-8">
              <h3 className="text-neutral-900 mb-4">Best For</h3>
              <div className="flex flex-wrap gap-3">
                {flooring.bestFor.map((room, index) => (
                  <span
                    key={index}
                    className="px-4 py-2 bg-amber-50 text-amber-700 rounded-lg"
                  >
                    {room}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* CTA Card */}
            <div className="bg-gradient-to-br from-amber-600 to-amber-700 rounded-2xl shadow-sm p-8 text-white">
              <h3 className="text-white mb-3">
                Ready to Install?
              </h3>
              <p className="text-amber-50 mb-6">
                Connect with verified contractors who specialize in {flooring.name.toLowerCase()}
              </p>
              <button className="w-full bg-white text-amber-600 px-6 py-3 rounded-lg hover:bg-amber-50 transition-colors">
                Find Contractors
              </button>
            </div>

            {/* Quick Tips */}
            <div className="bg-white rounded-2xl shadow-sm p-8">
              <h3 className="text-neutral-900 mb-4">Quick Tips</h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-neutral-900 mb-1">Acclimation Period</div>
                    <p className="text-neutral-600 text-sm">
                      Let flooring materials adjust to room temperature for 48-72 hours before installation
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-neutral-900 mb-1">Professional Help</div>
                    <p className="text-neutral-600 text-sm">
                      Consider professional installation for best results and warranty coverage
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
