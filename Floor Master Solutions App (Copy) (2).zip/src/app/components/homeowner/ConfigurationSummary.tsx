import { CustomConfiguration } from './ProductCustomizer';
import { woodSpecies } from '../../data/woodSpecies';

interface ConfigurationSummaryProps {
  configuration: CustomConfiguration;
  onEdit: () => void;
  onRequestQuote: () => void;
}

export function ConfigurationSummary({ configuration, onEdit, onRequestQuote }: ConfigurationSummaryProps) {
  const species = woodSpecies.find(s => s.id === configuration.speciesId);

  if (!species) {
    return null;
  }

  const typeLabel = {
    unfinished: 'Unfinished Hardwood',
    prefinished: 'Prefinished Hardwood',
    engineered: 'Engineered Hardwood',
    lvp: 'Luxury Vinyl Plank (LVP)'
  }[configuration.hardwoodType];

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-4xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-neutral-900 mb-2">Configuration Complete!</h1>
          <p className="text-neutral-600">
            Review your custom flooring specification below
          </p>
        </div>

        {/* Summary Card */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
          {/* Image Header */}
          <div className="aspect-video bg-neutral-100">
            <img
              src={species.image}
              alt={species.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Details */}
          <div className="p-8">
            <div className="mb-6">
              <h2 className="text-neutral-900 mb-1">Custom {species.name} Flooring</h2>
              <p className="text-neutral-600">{typeLabel}</p>
            </div>

            {/* Specifications Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div>
                <h3 className="text-neutral-900 mb-4">Wood Specifications</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Species:</span>
                    <span className="text-neutral-900 text-right">{species.name}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Scientific Name:</span>
                    <span className="text-neutral-900 text-right italic text-sm">{species.scientificName}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Category:</span>
                    <span className="text-neutral-900 text-right">{species.category}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Origin:</span>
                    <span className="text-neutral-900 text-right">{species.origin}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Hardness:</span>
                    <span className="text-neutral-900 text-right">{species.hardness} Janka</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-neutral-900 mb-4">Your Configuration</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Plank Width:</span>
                    <span className="text-neutral-900 text-right">{configuration.plankWidth} inch</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Plank Length:</span>
                    <span className="text-neutral-900 text-right">
                      {configuration.plankLength === 'random-short' ? 'Random (1-4 ft)' :
                       configuration.plankLength === 'random-long' ? 'Random (2-8 ft)' :
                       `${configuration.plankLength} inch`}
                    </span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Thickness:</span>
                    <span className="text-neutral-900 text-right">{configuration.thickness}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Finish:</span>
                    <span className="text-neutral-900 text-right">
                      {configuration.finish === 'satin-poly' ? 'Satin Polyurethane' :
                       configuration.finish === 'matte-poly' ? 'Matte Polyurethane' :
                       configuration.finish === 'gloss-poly' ? 'Gloss Polyurethane' :
                       configuration.finish === 'oil' ? 'Natural Oil' :
                       configuration.finish === 'hardwax' ? 'Hardwax Oil' :
                       configuration.finish === 'uv-cure' ? 'UV Cured' :
                       configuration.finish === 'aluminum-oxide' ? 'Aluminum Oxide' :
                       'Unfinished'}
                    </span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Color Tone:</span>
                    <span className="text-neutral-900 text-right capitalize">{configuration.colorTone.replace('-', ' ')}</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-neutral-900 mb-4">Design Details</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Layout Pattern:</span>
                    <span className="text-neutral-900 text-right capitalize">{configuration.layoutPattern}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Surface Texture:</span>
                    <span className="text-neutral-900 text-right capitalize">{configuration.texture.replace('-', ' ')}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Edge Profile:</span>
                    <span className="text-neutral-900 text-right capitalize">{configuration.edgeProfile.replace('-', ' ')}</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-neutral-900 mb-4">Wood Characteristics</h3>
                <ul className="space-y-2">
                  {species.characteristics.slice(0, 5).map((char, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-neutral-600 text-sm">
                      <svg className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span>{char}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={onEdit}
                className="flex-1 px-6 py-3 border-2 border-neutral-300 text-neutral-700 rounded-lg hover:bg-neutral-50 transition-colors"
              >
                Edit Configuration
              </button>
              <button
                onClick={onRequestQuote}
                className="flex-1 px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
              >
                Request Quote from Contractors
              </button>
            </div>
          </div>
        </div>

        {/* Additional Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h4 className="text-neutral-900 mb-2">Save Configuration</h4>
            <p className="text-neutral-600 text-sm mb-4">
              Download your specification sheet for future reference
            </p>
            <button className="text-blue-600 hover:text-blue-700 text-sm">
              Download PDF
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
            </div>
            <h4 className="text-neutral-900 mb-2">Visualize Your Floor</h4>
            <p className="text-neutral-600 text-sm mb-4">
              See how this flooring looks in a room
            </p>
            <button className="text-purple-600 hover:text-purple-700 text-sm">
              Open Visualizer
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
            </div>
            <h4 className="text-neutral-900 mb-2">Request Samples</h4>
            <p className="text-neutral-600 text-sm mb-4">
              Order physical samples to see and feel
            </p>
            <button className="text-green-600 hover:text-green-700 text-sm">
              Order Samples
            </button>
          </div>
        </div>

        {/* Best For */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
          <h4 className="text-neutral-900 mb-3">This Configuration is Best For:</h4>
          <div className="flex flex-wrap gap-2">
            {species.bestFor.map((use, idx) => (
              <span key={idx} className="px-3 py-1 bg-white border border-amber-300 rounded-full text-neutral-700 text-sm">
                {use}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
