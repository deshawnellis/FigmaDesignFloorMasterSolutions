import { useState } from 'react';

export interface EngineeredWoodConfiguration {
  typeId: string;
  finish: string;
  color: string;
  plankWidth: string;
  plankLength: string;
  installation: string;
  gloss: string;
  texture: string;
  totalPrice: number;
}

interface EngineeredWoodCustomizerProps {
  styleId: string;
  onComplete: (configuration: EngineeredWoodConfiguration) => void;
  onBack: () => void;
}

export function EngineeredWoodCustomizer({ styleId, onComplete, onBack }: EngineeredWoodCustomizerProps) {
  const [finish, setFinish] = useState('natural');
  const [color, setColor] = useState('natural-oak');
  const [plankWidth, setPlankWidth] = useState('5-inch');
  const [plankLength, setPlankLength] = useState('random');
  const [installation, setInstallation] = useState('click-lock');
  const [gloss, setGloss] = useState('matte');
  const [texture, setTexture] = useState('smooth');

  const basePrice = 6.50;

  const finishOptions = [
    { id: 'natural', name: 'Natural/Unfinished', price: 0, image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=300&q=80' },
    { id: 'pre-finished', name: 'Pre-Finished', price: 1.50, image: 'https://images.unsplash.com/photo-1631669394390-baf737ef47de?w=300&q=80' },
    { id: 'hand-scraped', name: 'Hand-Scraped', price: 2.50, image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=300&q=80' },
    { id: 'wire-brushed', name: 'Wire-Brushed', price: 2.00, image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=300&q=80' }
  ];

  const colorOptions = [
    { id: 'natural-oak', name: 'Natural Oak', hex: '#D4A574', price: 0 },
    { id: 'honey', name: 'Honey', hex: '#C8995F', price: 0.25 },
    { id: 'golden-oak', name: 'Golden Oak', hex: '#B8860B', price: 0.25 },
    { id: 'medium-brown', name: 'Medium Brown', hex: '#8B6F47', price: 0.50 },
    { id: 'dark-walnut', name: 'Dark Walnut', hex: '#5C4033', price: 0.75 },
    { id: 'espresso', name: 'Espresso', hex: '#3E2723', price: 0.75 },
    { id: 'gray-wash', name: 'Gray Wash', hex: '#9E9E9E', price: 1.00 },
    { id: 'weathered-gray', name: 'Weathered Gray', hex: '#6D6D6D', price: 1.00 },
    { id: 'white-oak', name: 'White Oak', hex: '#F5E6D3', price: 0.50 },
    { id: 'charcoal', name: 'Charcoal', hex: '#4A4A4A', price: 1.00 }
  ];

  const widthOptions = [
    { id: '3-inch', name: '3 inch (Traditional)', price: 0 },
    { id: '5-inch', name: '5 inch (Standard)', price: 0.50 },
    { id: '7-inch', name: '7 inch (Wide Plank)', price: 1.50 },
    { id: '9-inch', name: '9 inch (Ultra Wide)', price: 2.50 }
  ];

  const lengthOptions = [
    { id: 'random', name: 'Random Length Mix', price: 0 },
    { id: '3-4ft', name: '3-4 ft Planks', price: 0 },
    { id: '5-7ft', name: '5-7 ft Long Planks', price: 1.00 }
  ];

  const installationOptions = [
    { id: 'click-lock', name: 'Click-Lock Floating', price: 0, description: 'Easy DIY, no glue' },
    { id: 'glue-down', name: 'Glue-Down', price: 1.50, description: 'Most stable' },
    { id: 'nail-down', name: 'Nail-Down', price: 1.00, description: 'Traditional method' }
  ];

  const glossOptions = [
    { id: 'matte', name: 'Matte', price: 0 },
    { id: 'satin', name: 'Satin', price: 0.25 },
    { id: 'semi-gloss', name: 'Semi-Gloss', price: 0.50 },
    { id: 'high-gloss', name: 'High-Gloss', price: 0.75 }
  ];

  const textureOptions = [
    { id: 'smooth', name: 'Smooth', price: 0 },
    { id: 'lightly-textured', name: 'Lightly Textured', price: 0.50 },
    { id: 'heavily-textured', name: 'Heavily Textured', price: 1.00 }
  ];

  const calculatePrice = () => {
    let total = basePrice;
    
    const selectedFinish = finishOptions.find(f => f.id === finish);
    if (selectedFinish) total += selectedFinish.price;

    const selectedColor = colorOptions.find(c => c.id === color);
    if (selectedColor) total += selectedColor.price;

    const selectedWidth = widthOptions.find(w => w.id === plankWidth);
    if (selectedWidth) total += selectedWidth.price;

    const selectedLength = lengthOptions.find(l => l.id === plankLength);
    if (selectedLength) total += selectedLength.price;

    const selectedInstallation = installationOptions.find(i => i.id === installation);
    if (selectedInstallation) total += selectedInstallation.price;

    const selectedGloss = glossOptions.find(g => g.id === gloss);
    if (selectedGloss) total += selectedGloss.price;

    const selectedTexture = textureOptions.find(t => t.id === texture);
    if (selectedTexture) total += selectedTexture.price;

    return total.toFixed(2);
  };

  const handleComplete = () => {
    onComplete({
      typeId: styleId,
      finish,
      color,
      plankWidth,
      plankLength,
      installation,
      gloss,
      texture,
      totalPrice: parseFloat(calculatePrice())
    });
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-6 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Type Selection</span>
          </button>

          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-neutral-900 text-3xl md:text-4xl mb-2">Customize Your Engineered Wood</h1>
              <p className="text-neutral-600">Design your perfect engineered wood floor</p>
            </div>

            {/* Price Display */}
            <div className="bg-gradient-to-br from-orange-600 to-red-600 text-white px-8 py-4 rounded-2xl shadow-lg">
              <div className="text-sm text-orange-100 mb-1">Price per sqft</div>
              <div className="text-3xl">${calculatePrice()}</div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Configuration Options */}
          <div className="lg:col-span-2 space-y-8">
            {/* Finish Type */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <h2 className="text-neutral-900 text-xl mb-4">Finish Type</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {finishOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setFinish(option.id)}
                    className={`group relative rounded-2xl overflow-hidden transition-all ${
                      finish === option.id
                        ? 'ring-4 ring-orange-600 scale-105'
                        : 'hover:scale-105'
                    }`}
                  >
                    <div className="aspect-square">
                      <img src={option.image} alt={option.name} className="w-full h-full object-cover" />
                      <div className={`absolute inset-0 bg-gradient-to-t from-black/60 to-transparent`} />
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-3 text-white">
                      <div className="text-sm mb-1">{option.name}</div>
                      <div className="text-xs text-orange-200">
                        {option.price > 0 ? `+$${option.price.toFixed(2)}` : 'Included'}
                      </div>
                    </div>
                    {finish === option.id && (
                      <div className="absolute top-2 right-2 w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center">
                        <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Color/Stain */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <h2 className="text-neutral-900 text-xl mb-4">Color & Stain</h2>
              <div className="grid grid-cols-5 md:grid-cols-10 gap-3">
                {colorOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setColor(option.id)}
                    className={`group relative aspect-square rounded-xl transition-all ${
                      color === option.id
                        ? 'ring-4 ring-orange-600 scale-110'
                        : 'hover:scale-110'
                    }`}
                    style={{ backgroundColor: option.hex }}
                    title={option.name}
                  >
                    {color === option.id && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-lg">
                          <svg className="w-4 h-4 text-orange-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        </div>
                      </div>
                    )}
                  </button>
                ))}
              </div>
              <div className="mt-4 text-center">
                <span className="text-neutral-600">Selected: </span>
                <span className="text-neutral-900">
                  {colorOptions.find(c => c.id === color)?.name}
                </span>
                {colorOptions.find(c => c.id === color)?.price ? (
                  <span className="text-orange-600 ml-2">
                    +${colorOptions.find(c => c.id === color)?.price.toFixed(2)}
                  </span>
                ) : null}
              </div>
            </div>

            {/* Plank Width */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <h2 className="text-neutral-900 text-xl mb-4">Plank Width</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {widthOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setPlankWidth(option.id)}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      plankWidth === option.id
                        ? 'border-orange-600 bg-orange-50 scale-105'
                        : 'border-neutral-200 hover:border-orange-300'
                    }`}
                  >
                    <div className="text-neutral-900 mb-1">{option.name}</div>
                    <div className="text-xs text-neutral-600">
                      {option.price > 0 ? `+$${option.price.toFixed(2)}` : 'Included'}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Plank Length */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <h2 className="text-neutral-900 text-xl mb-4">Plank Length</h2>
              <div className="grid grid-cols-3 gap-4">
                {lengthOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setPlankLength(option.id)}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      plankLength === option.id
                        ? 'border-orange-600 bg-orange-50 scale-105'
                        : 'border-neutral-200 hover:border-orange-300'
                    }`}
                  >
                    <div className="text-neutral-900 mb-1">{option.name}</div>
                    <div className="text-xs text-neutral-600">
                      {option.price > 0 ? `+$${option.price.toFixed(2)}` : 'Included'}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Installation Method */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <h2 className="text-neutral-900 text-xl mb-4">Installation Method</h2>
              <div className="grid grid-cols-3 gap-4">
                {installationOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setInstallation(option.id)}
                    className={`p-4 rounded-xl border-2 transition-all text-left ${
                      installation === option.id
                        ? 'border-orange-600 bg-orange-50 scale-105'
                        : 'border-neutral-200 hover:border-orange-300'
                    }`}
                  >
                    <div className="text-neutral-900 mb-1">{option.name}</div>
                    <div className="text-xs text-neutral-600 mb-2">{option.description}</div>
                    <div className="text-xs text-orange-600">
                      {option.price > 0 ? `+$${option.price.toFixed(2)}` : 'Included'}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Gloss Level */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <h2 className="text-neutral-900 text-xl mb-4">Gloss Level</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {glossOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setGloss(option.id)}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      gloss === option.id
                        ? 'border-orange-600 bg-orange-50 scale-105'
                        : 'border-neutral-200 hover:border-orange-300'
                    }`}
                  >
                    <div className="text-neutral-900 mb-1">{option.name}</div>
                    <div className="text-xs text-neutral-600">
                      {option.price > 0 ? `+$${option.price.toFixed(2)}` : 'Included'}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Surface Texture */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <h2 className="text-neutral-900 text-xl mb-4">Surface Texture</h2>
              <div className="grid grid-cols-3 gap-4">
                {textureOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setTexture(option.id)}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      texture === option.id
                        ? 'border-orange-600 bg-orange-50 scale-105'
                        : 'border-neutral-200 hover:border-orange-300'
                    }`}
                  >
                    <div className="text-neutral-900 mb-1">{option.name}</div>
                    <div className="text-xs text-neutral-600">
                      {option.price > 0 ? `+$${option.price.toFixed(2)}` : 'Included'}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-3xl p-6 shadow-lg sticky top-8">
              <h2 className="text-neutral-900 text-xl mb-6">Configuration Summary</h2>

              <div className="space-y-4 mb-6">
                <div className="pb-4 border-b border-neutral-100">
                  <div className="text-sm text-neutral-600 mb-1">Finish</div>
                  <div className="text-neutral-900">
                    {finishOptions.find(f => f.id === finish)?.name}
                  </div>
                </div>

                <div className="pb-4 border-b border-neutral-100">
                  <div className="text-sm text-neutral-600 mb-1">Color</div>
                  <div className="flex items-center gap-2">
                    <div
                      className="w-6 h-6 rounded-full border-2 border-neutral-200"
                      style={{ backgroundColor: colorOptions.find(c => c.id === color)?.hex }}
                    />
                    <div className="text-neutral-900">
                      {colorOptions.find(c => c.id === color)?.name}
                    </div>
                  </div>
                </div>

                <div className="pb-4 border-b border-neutral-100">
                  <div className="text-sm text-neutral-600 mb-1">Dimensions</div>
                  <div className="text-neutral-900">
                    {widthOptions.find(w => w.id === plankWidth)?.name}
                  </div>
                  <div className="text-sm text-neutral-600 mt-1">
                    {lengthOptions.find(l => l.id === plankLength)?.name}
                  </div>
                </div>

                <div className="pb-4 border-b border-neutral-100">
                  <div className="text-sm text-neutral-600 mb-1">Installation</div>
                  <div className="text-neutral-900">
                    {installationOptions.find(i => i.id === installation)?.name}
                  </div>
                </div>

                <div className="pb-4 border-b border-neutral-100">
                  <div className="text-sm text-neutral-600 mb-1">Finish Details</div>
                  <div className="text-neutral-900">
                    {glossOptions.find(g => g.id === gloss)?.name} / {textureOptions.find(t => t.id === texture)?.name}
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-2xl p-6 mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-neutral-600">Total Price</span>
                  <span className="text-3xl text-neutral-900">${calculatePrice()}</span>
                </div>
                <div className="text-sm text-neutral-600">per square foot</div>
              </div>

              <button
                onClick={handleComplete}
                className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-4 rounded-xl hover:shadow-xl transition-all"
              >
                Complete Configuration
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}