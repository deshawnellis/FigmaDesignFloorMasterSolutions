import { useState, useRef, useEffect } from 'react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AIChatProps {
  userType: 'homeowner' | 'contractor';
}

export function AIChat({ userType }: AIChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: userType === 'homeowner'
        ? "Hi! I'm your AI flooring assistant. I can help you choose the right flooring for your home, answer questions about installation, maintenance, and costs. What would you like to know?"
        : "Hi! I'm your AI contractor assistant. I can help you with installation tips, material recommendations, pricing guidance, and best practices. How can I assist you today?",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const suggestedQuestions = userType === 'homeowner' ? [
    "What flooring is best for dogs?",
    "What's the difference between hardwood and LVP?",
    "What works best in basements?",
    "How much does installation typically cost?",
  ] : [
    "What's the standard waste factor for tile?",
    "How do I price engineered wood installation?",
    "What tools do I need for LVP installation?",
    "How do I handle subfloor prep?",
  ];

  const getAIResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    // Homeowner responses
    if (userType === 'homeowner') {
      if (lowerMessage.includes('dog') || lowerMessage.includes('pet')) {
        return "For homes with dogs, I'd recommend Luxury Vinyl Plank (LVP) or tile. LVP is waterproof, scratch-resistant, and easy to clean. Tile is extremely durable but can be cold and hard. Avoid carpet (traps odors) and softer hardwoods (scratches easily). LVP gives you the wood look with pet-friendly durability!";
      }
      if (lowerMessage.includes('basement')) {
        return "Basements need moisture-resistant flooring! Best options: 1) LVP - completely waterproof and warm underfoot, 2) Tile - waterproof but cold, 3) Engineered wood - more stable than hardwood. Avoid: solid hardwood (warps with moisture) and carpet (mold risk). Always address moisture issues first!";
      }
      if (lowerMessage.includes('hardwood') && lowerMessage.includes('lvp')) {
        return "Great question! Hardwood is real wood, can be refinished multiple times, and adds more home value but costs more and isn't waterproof. LVP is synthetic, waterproof, cheaper, and easier to install, but can't be refinished. LVP mimics wood beautifully and is perfect for kitchens, bathrooms, and basements where hardwood would fail.";
      }
      if (lowerMessage.includes('cost') || lowerMessage.includes('price')) {
        return "Installation costs vary by material: Hardwood: $8-15/sq ft + $3-8 installation. LVP: $3-8/sq ft + $2-5 installation. Tile: $5-20/sq ft + $5-15 installation. Carpet: $2-10/sq ft + $1-3 installation. For an average room (200 sq ft), budget $1,000-$4,000 total. Prices vary by region and complexity!";
      }
      if (lowerMessage.includes('kitchen')) {
        return "Kitchens need waterproof, durable flooring! Best choices: LVP (waterproof, easy maintenance), Tile (ultra-durable, lots of styles), or Engineered Wood (upscale look, decent moisture resistance). Avoid: carpet (stains), solid hardwood (water damage risk), laminate (not waterproof). LVP is the most practical choice for most kitchens!";
      }
    }
    
    // Contractor responses
    if (userType === 'contractor') {
      if (lowerMessage.includes('waste') || lowerMessage.includes('factor')) {
        return "Standard waste factors: LVP/Laminate: 5-10%, Hardwood: 10-15%, Tile: 10-15% (20% for diagonal), Carpet: 5-10%. Complex layouts, patterns, or lots of cuts need higher waste. Always round up and include waste in your estimate - better to have extra than run short mid-job!";
      }
      if (lowerMessage.includes('price') || lowerMessage.includes('engineered wood')) {
        return "Engineered wood pricing: Material cost varies ($5-12/sq ft) based on wear layer thickness. For installation, charge $3-7/sq ft depending on: subfloor condition, room complexity, removal needs, and regional rates. Don't forget to include: floor prep, underlayment, transitions, and disposal. Add 15% waste factor and always include a contingency!";
      }
      if (lowerMessage.includes('tool') || lowerMessage.includes('lvp')) {
        return "Essential LVP tools: Utility knife & blades (for scoring), T-square or speed square, tape measure, rubber mallet, pull bar, tapping block, spacers (1/4\"), circular saw or miter saw (for complex cuts). Pro tip: Use a scoring knife for most cuts, saw only when needed. And always check for level subfloor before starting!";
      }
      if (lowerMessage.includes('subfloor')) {
        return "Subfloor prep is critical! Check for: 1) Level - max 3/16\" variation over 10ft, use self-leveling compound if needed. 2) Moisture - test with meter, address sources. 3) Damage - replace soft spots. 4) Clean - remove debris, nails, adhesive. 5) Secure - fix squeaks, secure loose boards. Poor prep = callback. Time spent here saves headaches later!";
      }
    }

    return "I'd be happy to help with that! Could you provide more details about your specific situation? I can assist with flooring types, installation, maintenance, costs, and room-specific recommendations. What would you like to know more about?";
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI thinking
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: getAIResponse(inputValue),
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1000);
  };

  const handleSuggestedQuestion = (question: string) => {
    setInputValue(question);
  };

  return (
    <div className="h-screen bg-neutral-50 flex flex-col">
      <div className="max-w-4xl mx-auto w-full flex flex-col h-full md:ml-32">
        {/* Header */}
        <div className="bg-white border-b border-neutral-200 px-6 py-4">
          <h2 className="text-neutral-900">
            AI {userType === 'homeowner' ? 'Flooring' : 'Contractor'} Assistant
          </h2>
          <p className="text-neutral-600 text-sm">
            {userType === 'homeowner'
              ? 'Ask me anything about flooring options, care, and installation'
              : 'Get help with installation, pricing, and professional tips'}
          </p>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-6 py-4 ${
                  message.role === 'user'
                    ? 'bg-amber-600 text-white'
                    : 'bg-white text-neutral-900 shadow-sm'
                }`}
              >
                {message.role === 'assistant' && (
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-6 h-6 bg-amber-100 rounded-full flex items-center justify-center">
                      <svg className="w-4 h-4 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                      </svg>
                    </div>
                    <span className="text-amber-600 text-sm">AI Assistant</span>
                  </div>
                )}
                <p className={`whitespace-pre-wrap ${message.role === 'user' ? 'text-white' : 'text-neutral-700'}`}>
                  {message.content}
                </p>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white text-neutral-900 shadow-sm rounded-2xl px-6 py-4">
                <div className="flex items-center gap-2">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                    <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                    <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                  </div>
                  <span className="text-neutral-500 text-sm">AI is thinking...</span>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Questions */}
        {messages.length === 1 && (
          <div className="px-6 pb-4">
            <div className="text-neutral-600 text-sm mb-3">Suggested questions:</div>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.map((question, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestedQuestion(question)}
                  className="px-4 py-2 bg-white text-neutral-700 rounded-lg hover:bg-neutral-50 transition-colors text-sm border border-neutral-200"
                >
                  {question}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Area */}
        <div className="bg-white border-t border-neutral-200 px-6 py-4">
          <div className="flex gap-3">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Ask a question..."
              className="flex-1 px-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputValue.trim()}
              className="bg-amber-600 text-white px-6 py-3 rounded-lg hover:bg-amber-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
