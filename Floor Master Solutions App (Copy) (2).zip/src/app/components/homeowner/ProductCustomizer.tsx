import { useState, useMemo } from 'react';
import { woodSpecies } from '../../data/woodSpecies';

interface ProductCustomizerProps {
  hardwoodType: string;
  speciesId: string;
  onBack: () => void;
  onComplete: (configuration: CustomConfiguration) => void;
}

export interface CustomConfiguration {
  hardwoodType: string;
  speciesId: string;
  plankWidth: string;
  plankLength: string;
  thickness: string;
  finish: string;
  colorTone: string;
  layoutPattern: string;
  texture: string;
  edgeProfile: string;
}

const plankWidths = [
  { id: '2.25', label: '2.25 inch', description: 'Traditional narrow planks' },
  { id: '3', label: '3 inch', description: 'Classic width' },
  { id: '4', label: '4 inch', description: 'Medium width' },
  { id: '5', label: '5 inch', description: 'Popular modern width' },
  { id: '6', label: '6 inch', description: 'Wide plank' },
  { id: '7', label: '7 inch', description: 'Extra-wide plank' },
  { id: '9', label: '9 inch', description: 'Ultra-wide plank' }
];

const plankLengths = [
  { id: 'random-short', label: 'Random (1-4 ft)', description: 'Traditional varied lengths' },
  { id: 'random-long', label: 'Random (2-8 ft)', description: 'Long varied lengths' },
  { id: '48', label: '48 inch (4 ft)', description: 'Uniform 4 ft planks' },
  { id: '72', label: '72 inch (6 ft)', description: 'Uniform 6 ft planks' }
];

const thicknesses = [
  { id: '3/8', label: '3/8 inch', description: 'Thin profile', available: ['engineered', 'lvp'] },
  { id: '1/2', label: '1/2 inch', description: 'Standard engineered', available: ['engineered'] },
  { id: '5/8', label: '5/8 inch', description: 'Thick engineered', available: ['engineered'] },
  { id: '3/4', label: '3/4 inch', description: 'Solid wood standard', available: ['unfinished', 'prefinished'] },
  { id: '5mm', label: '5mm', description: 'Standard LVP', available: ['lvp'] },
  { id: '6mm', label: '6mm', description: 'Premium LVP', available: ['lvp'] }
];

const finishes = [
  { id: 'unfinished', label: 'Unfinished', description: 'Sand and finish on-site', available: ['unfinished'] },
  { id: 'satin-poly', label: 'Satin Polyurethane', description: 'Low sheen, durable' },
  { id: 'matte-poly', label: 'Matte Polyurethane', description: 'Ultra-low sheen' },
  { id: 'gloss-poly', label: 'Gloss Polyurethane', description: 'High shine finish' },
  { id: 'oil', label: 'Natural Oil', description: 'Penetrating oil finish' },
  { id: 'hardwax', label: 'Hardwax Oil', description: 'Natural look with protection' },
  { id: 'uv-cure', label: 'UV Cured', description: 'Factory applied, very durable' },
  { id: 'aluminum-oxide', label: 'Aluminum Oxide', description: 'Maximum durability' }
];

const colorTones = [
  { id: 'natural', label: 'Natural', description: 'True wood color' },
  { id: 'honey', label: 'Honey', description: 'Warm golden tones' },
  { id: 'amber', label: 'Amber', description: 'Rich amber color' },
  { id: 'chestnut', label: 'Chestnut', description: 'Medium brown' },
  { id: 'walnut', label: 'Walnut', description: 'Rich dark brown' },
  { id: 'espresso', label: 'Espresso', description: 'Very dark brown' },
  { id: 'gray', label: 'Gray', description: 'Contemporary gray tone' },
  { id: 'white-wash', label: 'White Wash', description: 'Light, washed look' },
  { id: 'weathered', label: 'Weathered', description: 'Aged, reclaimed look' }
];

const layoutPatterns = [
  { 
    id: 'straight', 
    label: 'Straight/Traditional', 
    description: 'Parallel to walls, most common',
    image: 'https://images.unsplash.com/photo-1711915442858-2a5bb7ba67d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvYWslMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE1OXww&ixlib=rb-4.1.0&q=80&w=1080'
  },
  { 
    id: 'diagonal', 
    label: 'Diagonal', 
    description: '45-degree angle installation',
    image: 'https://images.unsplash.com/photo-1650047236599-cd639f36b9d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWFnb25hbCUyMHdvb2QlMjBmbG9vcnxlbnwxfHx8fDE3NjYwMTM4Nzl8MA&ixlib=rb-4.1.0&q=80&w=1080'
  },
  { 
    id: 'herringbone', 
    label: 'Herringbone', 
    description: 'Classic V-pattern, elegant',
    image: 'https://images.unsplash.com/photo-1761053130711-2515ef532bb5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZXJyaW5nYm9uZSUyMHdvb2QlMjBmbG9vciUyMHBhdHRlcm58ZW58MXx8fHwxNzY2MDEzODc4fDA&ixlib=rb-4.1.0&q=80&w=1080'
  },
  { 
    id: 'chevron', 
    label: 'Chevron', 
    description: 'Pointed zigzag pattern',
    image: 'https://images.unsplash.com/photo-1687398209712-de4252610814?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGV2cm9uJTIwd29vZCUyMGZsb29yJTIwcGF0dGVybnxlbnwxfHx8fDE3NjYwMTM4Nzl8MA&ixlib=rb-4.1.0&q=80&w=1080'
  },
  { 
    id: 'parquet', 
    label: 'Parquet', 
    description: 'Geometric tile patterns',
    image: 'https://images.unsplash.com/photo-1693722232517-9c19a620258c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJxdWV0JTIwd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NTk5NTUyN3ww&ixlib=rb-4.1.0&q=80&w=1080'
  }
];

const textures = [
  { id: 'smooth', label: 'Smooth', description: 'Flat, polished surface' },
  { id: 'wire-brushed', label: 'Wire Brushed', description: 'Soft texture, recessed grain' },
  { id: 'hand-scraped', label: 'Hand Scraped', description: 'Rustic, handcrafted texture' },
  { id: 'distressed', label: 'Distressed', description: 'Aged, worn appearance' },
  { id: 'sawn', label: 'Saw Marks', description: 'Visible saw texture' }
];

const edgeProfiles = [
  { id: 'square', label: 'Square Edge', description: 'Tight, seamless joints' },
  { id: 'micro-bevel', label: 'Micro Bevel', description: 'Subtle edge definition' },
  { id: 'beveled', label: 'Beveled Edge', description: 'Pronounced edge, plank definition' },
  { id: 'eased', label: 'Eased Edge', description: 'Slightly rounded corners' }
];

export function ProductCustomizer({ hardwoodType, speciesId, onBack, onComplete }: ProductCustomizerProps) {
  const [step, setStep] = useState(1);
  const [plankWidth, setPlankWidth] = useState('5');
  const [plankLength, setPlankLength] = useState('random-long');
  const [thickness, setThickness] = useState('3/4');
  const [finish, setFinish] = useState('satin-poly');
  const [colorTone, setColorTone] = useState('natural');
  const [layoutPattern, setLayoutPattern] = useState('straight');
  const [texture, setTexture] = useState('smooth');
  const [edgeProfile, setEdgeProfile] = useState('square');

  const species = woodSpecies.find(s => s.id === speciesId);

  const availableThicknesses = useMemo(() => {
    return thicknesses.filter(t => !t.available || t.available.includes(hardwoodType));
  }, [hardwoodType]);

  const availableFinishes = useMemo(() => {
    if (hardwoodType === 'unfinished') {
      return finishes.filter(f => f.id === 'unfinished');
    }
    return finishes.filter(f => f.id !== 'unfinished');
  }, [hardwoodType]);

  const totalSteps = 5;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    }
  };

  const handlePrevious = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleComplete = () => {
    const configuration: CustomConfiguration = {
      hardwoodType,
      speciesId,
      plankWidth,
      plankLength,
      thickness,
      finish,
      colorTone,
      layoutPattern,
      texture,
      edgeProfile
    };
    onComplete(configuration);
  };

  if (!species) {
    return null;
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-5xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Species Selection</span>
          </button>
          
          <h1 className="text-neutral-900 mb-2">Customize Your {species.name}</h1>
          <p className="text-neutral-600">
            Step {step} of {totalSteps}: Configure your perfect flooring
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            {['Size', 'Thickness', 'Finish & Color', 'Layout Pattern', 'Texture & Edge'].map((label, idx) => (
              <div key={idx} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                  step > idx + 1 ? 'bg-amber-600 text-white' :
                  step === idx + 1 ? 'bg-amber-600 text-white' :
                  'bg-neutral-200 text-neutral-500'
                }`}>
                  {step > idx + 1 ? '✓' : idx + 1}
                </div>
                {idx < 4 && <div className={`w-12 h-1 mx-2 ${step > idx + 1 ? 'bg-amber-600' : 'bg-neutral-200'}`} />}
              </div>
            ))}
          </div>
        </div>

        {/* Step Content */}
        <div className="bg-white rounded-xl shadow-sm p-8 mb-6">
          {/* Step 1: Plank Size */}
          {step === 1 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Select Plank Size</h2>
              
              <div className="mb-8">
                <h3 className="text-neutral-700 mb-4">Plank Width</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {plankWidths.map((width) => (
                    <button
                      key={width.id}
                      onClick={() => setPlankWidth(width.id)}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        plankWidth === width.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900">{width.label}</span>
                        {plankWidth === width.id && (
                          <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-sm">{width.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-neutral-700 mb-4">Plank Length</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {plankLengths.map((length) => (
                    <button
                      key={length.id}
                      onClick={() => setPlankLength(length.id)}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        plankLength === length.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900">{length.label}</span>
                        {plankLength === length.id && (
                          <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-sm">{length.description}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Thickness */}
          {step === 2 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Select Thickness</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {availableThicknesses.map((thick) => (
                  <button
                    key={thick.id}
                    onClick={() => setThickness(thick.id)}
                    className={`p-4 border-2 rounded-lg text-left transition-all ${
                      thickness === thick.id
                        ? 'border-amber-600 bg-amber-50'
                        : 'border-neutral-200 hover:border-amber-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-neutral-900">{thick.label}</span>
                      {thickness === thick.id && (
                        <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                    <p className="text-neutral-600 text-sm">{thick.description}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 3: Finish & Color */}
          {step === 3 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Select Finish & Color Tone</h2>
              
              <div className="mb-8">
                <h3 className="text-neutral-700 mb-4">Finish Type</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {availableFinishes.map((fin) => (
                    <button
                      key={fin.id}
                      onClick={() => setFinish(fin.id)}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        finish === fin.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900">{fin.label}</span>
                        {finish === fin.id && (
                          <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-sm">{fin.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              {hardwoodType !== 'unfinished' && (
                <div>
                  <h3 className="text-neutral-700 mb-4">Color Tone</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {colorTones.map((color) => (
                      <button
                        key={color.id}
                        onClick={() => setColorTone(color.id)}
                        className={`p-4 border-2 rounded-lg text-left transition-all ${
                          colorTone === color.id
                            ? 'border-amber-600 bg-amber-50'
                            : 'border-neutral-200 hover:border-amber-300'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-neutral-900 text-sm">{color.label}</span>
                          {colorTone === color.id && (
                            <svg className="w-4 h-4 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </div>
                        <p className="text-neutral-600 text-xs">{color.description}</p>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step 4: Layout Pattern */}
          {step === 4 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Select Layout Pattern</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {layoutPatterns.map((pattern) => (
                  <button
                    key={pattern.id}
                    onClick={() => setLayoutPattern(pattern.id)}
                    className={`border-2 rounded-lg overflow-hidden text-left transition-all ${
                      layoutPattern === pattern.id
                        ? 'border-amber-600'
                        : 'border-neutral-200 hover:border-amber-300'
                    }`}
                  >
                    <div className="aspect-video overflow-hidden bg-neutral-100">
                      <img src={pattern.image} alt={pattern.label} className="w-full h-full object-cover" />
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900">{pattern.label}</span>
                        {layoutPattern === pattern.id && (
                          <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-sm">{pattern.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 5: Texture & Edge */}
          {step === 5 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Select Texture & Edge Profile</h2>
              
              <div className="mb-8">
                <h3 className="text-neutral-700 mb-4">Surface Texture</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {textures.map((tex) => (
                    <button
                      key={tex.id}
                      onClick={() => setTexture(tex.id)}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        texture === tex.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900">{tex.label}</span>
                        {texture === tex.id && (
                          <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-sm">{tex.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-neutral-700 mb-4">Edge Profile</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {edgeProfiles.map((edge) => (
                    <button
                      key={edge.id}
                      onClick={() => setEdgeProfile(edge.id)}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        edgeProfile === edge.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900">{edge.label}</span>
                        {edgeProfile === edge.id && (
                          <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-sm">{edge.description}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between">
          <button
            onClick={handlePrevious}
            disabled={step === 1}
            className={`px-6 py-3 border-2 border-neutral-300 rounded-lg transition-colors ${
              step === 1
                ? 'text-neutral-400 cursor-not-allowed'
                : 'text-neutral-700 hover:bg-neutral-50'
            }`}
          >
            Previous
          </button>

          {step < totalSteps ? (
            <button
              onClick={handleNext}
              className="px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
            >
              Next Step
            </button>
          ) : (
            <button
              onClick={handleComplete}
              className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              Complete Configuration
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
