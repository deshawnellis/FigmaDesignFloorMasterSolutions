interface HardwoodType {
  id: string;
  name: string;
  description: string;
  image: string;
  features: string[];
  priceRange: string;
}

const hardwoodTypes: HardwoodType[] = [
  {
    id: 'unfinished',
    name: 'Unfinished Hardwood',
    description: 'Raw solid wood planks that are sanded and finished on-site after installation.',
    image: 'https://images.unsplash.com/photo-1673924968581-c18b53d64e22?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bmZpbmlzaGVkJTIwaGFyZHdvb2QlMjBmbG9vcnxlbnwxfHx8fDE3NjYwMTMxMzF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    features: [
      'Custom stain colors',
      'Seamless finish across entire floor',
      'Can be refinished multiple times',
      'Most authentic wood look'
    ],
    priceRange: '$8-$15 per sq ft'
  },
  {
    id: 'prefinished',
    name: 'Prefinished Hardwood',
    description: 'Solid wood planks with factory-applied finish, ready to walk on immediately after installation.',
    image: 'https://images.unsplash.com/photo-1673924968581-c18b53d64e22?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVmaW5pc2hlZCUyMGhhcmR3b29kJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDEzMTMyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    features: [
      'Factory-finished for durability',
      'Quick installation',
      'Consistent appearance',
      'Immediate use after install'
    ],
    priceRange: '$10-$18 per sq ft'
  },
  {
    id: 'engineered',
    name: 'Engineered Hardwood',
    description: 'Multi-layer construction with real wood veneer top, more stable than solid wood.',
    image: 'https://images.unsplash.com/photo-1761053133165-0f3acdaf1770?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbmdpbmVlcmVkJTIwd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzEzMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    features: [
      'Better moisture resistance',
      'Can install over concrete',
      'Less expansion/contraction',
      'Real wood top layer'
    ],
    priceRange: '$5-$12 per sq ft'
  },
  {
    id: 'lvp',
    name: 'Luxury Vinyl Plank (LVP)',
    description: 'Waterproof synthetic flooring with realistic wood appearance.',
    image: 'https://images.unsplash.com/photo-1678799021566-2e2a748e9dd6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB2aW55bCUyMHBsYW5rfGVufDF8fHx8MTc2NTk5MTU4N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    features: [
      'Completely waterproof',
      'Easy DIY installation',
      'Very low maintenance',
      'Pet and kid friendly'
    ],
    priceRange: '$3-$8 per sq ft'
  }
];

interface HardwoodTypeSelectionProps {
  onSelectType: (typeId: string) => void;
  onBack: () => void;
}

export function HardwoodTypeSelection({ onSelectType, onBack }: HardwoodTypeSelectionProps) {
  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Flooring Options</span>
          </button>
          
          <h1 className="text-neutral-900 mb-2">Choose Your Hardwood Type</h1>
          <p className="text-neutral-600">
            Select the type of hardwood flooring that best fits your needs and budget
          </p>
        </div>

        {/* Types Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {hardwoodTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => onSelectType(type.id)}
              className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden text-left group"
            >
              <div className="aspect-video overflow-hidden bg-neutral-100">
                <img
                  src={type.image}
                  alt={type.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              
              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-neutral-900 mb-1">{type.name}</h3>
                    <span className="text-amber-600 text-sm">{type.priceRange}</span>
                  </div>
                  <svg 
                    className="w-6 h-6 text-amber-600 opacity-0 group-hover:opacity-100 transition-opacity" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
                
                <p className="text-neutral-600 text-sm mb-4">
                  {type.description}
                </p>
                
                <div className="space-y-2">
                  <p className="text-neutral-700 text-sm">Key Features:</p>
                  <ul className="space-y-1">
                    {type.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2 text-neutral-600 text-sm">
                        <svg className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Info Banner */}
        <div className="mt-8 bg-amber-50 border border-amber-200 rounded-xl p-6">
          <div className="flex gap-4">
            <div className="flex-shrink-0">
              <svg className="w-6 h-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h4 className="text-neutral-900 mb-1">Need Help Choosing?</h4>
              <p className="text-neutral-600 text-sm">
                Consider your budget, installation timeline, and room location. Unfinished and prefinished are true solid wood. 
                Engineered offers better moisture resistance. LVP is the most durable and waterproof option.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
