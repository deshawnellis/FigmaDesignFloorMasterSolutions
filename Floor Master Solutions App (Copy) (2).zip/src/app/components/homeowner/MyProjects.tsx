import { useState } from 'react';
import { FloorProject, floorProjects } from '../../data/floorProjects';
import { FloorVisualizer } from './FloorVisualizer';
import { ShareWithContractors } from './ShareWithContractors';
import { ShareProjectModal } from './ShareProjectModal';

type ViewMode = 'list' | 'visualize' | 'share';

export function MyProjects() {
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [selectedProject, setSelectedProject] = useState<FloorProject | null>(null);
  const [projects, setProjects] = useState<FloorProject[]>(floorProjects);
  const [showShareModal, setShowShareModal] = useState(false);
  const [projectToShare, setProjectToShare] = useState<FloorProject | null>(null);

  const handleProjectUpdate = (updatedProject: FloorProject) => {
    setProjects(projects.map(p => p.id === updatedProject.id ? updatedProject : p));
  };

  const handleShareProject = (project: FloorProject, contractorIds: string[], findingContractors: boolean) => {
    const updatedProject = {
      ...project,
      sharedWith: contractorIds.length > 0 ? contractorIds : undefined,
      findingContractors,
      status: 'shared' as const,
      updatedDate: new Date().toISOString().split('T')[0]
    };
    handleProjectUpdate(updatedProject);
    setViewMode('list');
    setSelectedProject(null);
  };

  const handleVisualizeProject = (project: FloorProject) => {
    setSelectedProject(project);
    setViewMode('visualize');
  };

  const handleContinueToShare = () => {
    setViewMode('share');
  };

  const handleBackToList = () => {
    setViewMode('list');
    setSelectedProject(null);
  };

  const handleOpenShareModal = (project: FloorProject) => {
    setProjectToShare(project);
    setShowShareModal(true);
  };

  const handleCloseShareModal = () => {
    setShowShareModal(false);
    setProjectToShare(null);
  };

  // Project List View
  if (viewMode === 'list') {
    return (
      <>
        <div className="min-h-screen bg-neutral-50">
          <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-neutral-900 mb-2">My Floor Projects</h1>
              <p className="text-neutral-600">
                Manage your floor designs, visualizations, and contractor quotes
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-neutral-600">Total Projects</span>
                  <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                    </svg>
                  </div>
                </div>
                <p className="text-neutral-900 text-2xl">{projects.length}</p>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-neutral-600">Designing</span>
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                    </svg>
                  </div>
                </div>
                <p className="text-neutral-900 text-2xl">
                  {projects.filter(p => p.status === 'designing').length}
                </p>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-neutral-600">Shared</span>
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                    </svg>
                  </div>
                </div>
                <p className="text-neutral-900 text-2xl">
                  {projects.filter(p => p.status === 'shared' || p.status === 'quoted').length}
                </p>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-neutral-600">Quotes Received</span>
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                </div>
                <p className="text-neutral-900 text-2xl">
                  {projects.filter(p => p.quotes && p.quotes.length > 0).length}
                </p>
              </div>
            </div>

            {/* Projects List */}
            {projects.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-sm p-12 text-center">
                <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg className="w-10 h-10 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                </div>
                <h2 className="text-neutral-900 mb-2">No Projects Yet</h2>
                <p className="text-neutral-600 mb-6">
                  Start by selecting your flooring type and customizing your specifications
                </p>
                <button className="bg-amber-600 text-white px-6 py-3 rounded-xl hover:bg-amber-700 transition-colors">
                  Browse Flooring Options
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {projects.map((project) => (
                  <div key={project.id} className="bg-white rounded-2xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                    {/* Status Badge */}
                    <div className="p-4 bg-neutral-50 border-b border-neutral-200">
                      <div className="flex items-center justify-between">
                        <span className={`text-xs px-3 py-1 rounded-full ${
                          project.status === 'designing' ? 'bg-blue-100 text-blue-700' :
                          project.status === 'visualizing' ? 'bg-purple-100 text-purple-700' :
                          project.status === 'shared' ? 'bg-amber-100 text-amber-700' :
                          'bg-green-100 text-green-700'
                        }`}>
                          {project.status === 'designing' ? 'Designing' :
                           project.status === 'visualizing' ? 'Visualizing' :
                           project.status === 'shared' ? 'Shared with Contractors' :
                           'Quotes Received'}
                        </span>
                        <span className="text-xs text-neutral-500">
                          {new Date(project.updatedDate).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    {/* Room Photo */}
                    {project.roomPhoto ? (
                      <div className="aspect-video bg-neutral-200">
                        <img src={project.roomPhoto} alt={project.roomType} className="w-full h-full object-cover" />
                      </div>
                    ) : (
                      <div className="aspect-video bg-neutral-100 flex items-center justify-center">
                        <div className="text-center">
                          <svg className="w-12 h-12 text-neutral-400 mx-auto mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                          </svg>
                          <p className="text-sm text-neutral-500">No photo yet</p>
                        </div>
                      </div>
                    )}

                    <div className="p-6">
                      {/* Title */}
                      <h3 className="text-neutral-900 mb-1">{project.roomType}</h3>
                      <p className="text-sm text-neutral-600 mb-4 capitalize">
                        {project.flooringType} • {project.squareFootage || '—'} sq ft
                      </p>

                      {/* Specs Preview */}
                      <div className="bg-neutral-50 rounded-lg p-3 mb-4 text-sm">
                        {project.hardwood && (
                          <p className="text-neutral-700">
                            {project.hardwood.species} • {project.hardwood.color}
                          </p>
                        )}
                        {project.carpet && (
                          <p className="text-neutral-700">
                            {project.carpet.style} • {project.carpet.color}
                          </p>
                        )}
                        {project.tile && (
                          <p className="text-neutral-700">
                            {project.tile.material} • {project.tile.pattern}
                          </p>
                        )}
                      </div>

                      {/* Quotes */}
                      {project.quotes && project.quotes.length > 0 && (
                        <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                          <p className="text-sm text-green-900">
                            🎉 {project.quotes.length} quote{project.quotes.length > 1 ? 's' : ''} received
                          </p>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex gap-2">
                        {!project.roomPhoto ? (
                          <button
                            onClick={() => handleVisualizeProject(project)}
                            className="flex-1 bg-amber-600 text-white py-2 rounded-lg hover:bg-amber-700 transition-colors text-sm"
                          >
                            Add Photo
                          </button>
                        ) : !project.sharedWith && !project.findingContractors ? (
                          <>
                            <button
                              onClick={() => {
                                setSelectedProject(project);
                                setViewMode('share');
                              }}
                              className="flex-1 bg-amber-600 text-white py-2 rounded-lg hover:bg-amber-700 transition-colors text-sm"
                            >
                              Find Contractors
                            </button>
                            <button
                              onClick={() => handleOpenShareModal(project)}
                              className="px-4 py-2 bg-neutral-100 text-neutral-900 rounded-lg hover:bg-neutral-200 transition-colors"
                              title="Share with friends"
                            >
                              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                              </svg>
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              onClick={() => setSelectedProject(project)}
                              className="flex-1 bg-neutral-100 text-neutral-900 py-2 rounded-lg hover:bg-neutral-200 transition-colors text-sm"
                            >
                              View Details
                            </button>
                            <button
                              onClick={() => handleOpenShareModal(project)}
                              className="px-4 py-2 bg-neutral-100 text-neutral-900 rounded-lg hover:bg-neutral-200 transition-colors"
                              title="Share with friends"
                            >
                              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                              </svg>
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Share Modal */}
        {showShareModal && projectToShare && (
          <ShareProjectModal
            project={projectToShare}
            onClose={handleCloseShareModal}
          />
        )}
      </>
    );
  }

  // Visualizer View
  if (viewMode === 'visualize' && selectedProject) {
    return (
      <FloorVisualizer
        project={selectedProject}
        onSave={handleProjectUpdate}
        onNext={handleContinueToShare}
      />
    );
  }

  // Share View
  if (viewMode === 'share' && selectedProject) {
    return (
      <ShareWithContractors
        project={selectedProject}
        onShare={handleShareProject}
        onBack={handleBackToList}
      />
    );
  }

  return null;
}