import { TileConfiguration } from './TileCustomizer';
import { tileMaterials, tileSizes } from '../../data/tileMaterials';

interface TileConfigurationSummaryProps {
  configuration: TileConfiguration;
  onEdit: () => void;
  onRequestQuote: () => void;
}

export function TileConfigurationSummary({ configuration, onEdit, onRequestQuote }: TileConfigurationSummaryProps) {
  const material = tileMaterials.find(m => m.id === configuration.materialId);
  const tileSize = tileSizes.find(s => s.id === configuration.size);

  if (!material || !tileSize) {
    return null;
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-4xl mx-auto px-6 py-8 md:ml-64">
        <div className="mb-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-neutral-900 mb-2">Tile Configuration Complete!</h1>
          <p className="text-neutral-600">
            Review your custom tile specification below
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
          <div className="aspect-video bg-neutral-100">
            <img
              src={material.image}
              alt={material.name}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="p-8">
            <div className="mb-6">
              <h2 className="text-neutral-900 mb-1">Custom {material.name} Tile</h2>
              <p className="text-neutral-600">{material.type} - {tileSize.dimensions}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div>
                <h3 className="text-neutral-900 mb-4">Material & Performance</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Material:</span>
                    <span className="text-neutral-900 text-right">{material.name}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Type:</span>
                    <span className="text-neutral-900 text-right">{material.type}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Durability:</span>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div
                          key={i}
                          className={`w-2 h-2 rounded-full ${
                            i < material.durability ? 'bg-amber-600' : 'bg-neutral-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Water Resist:</span>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div
                          key={i}
                          className={`w-2 h-2 rounded-full ${
                            i < material.waterResistance ? 'bg-blue-600' : 'bg-neutral-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Maintenance:</span>
                    <span className="text-neutral-900 text-right">{material.maintenance}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Porosity:</span>
                    <span className="text-neutral-900 text-right">{material.porosity}</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-neutral-900 mb-4">Tile Specifications</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Size:</span>
                    <span className="text-neutral-900 text-right">{tileSize.dimensions}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Finish:</span>
                    <span className="text-neutral-900 text-right capitalize">{configuration.finish}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Color:</span>
                    <span className="text-neutral-900 text-right capitalize">{configuration.color.replace('-', ' ')}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Pattern:</span>
                    <span className="text-neutral-900 text-right capitalize">{configuration.pattern}</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-neutral-900 mb-4">Grout Details</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Grout Color:</span>
                    <span className="text-neutral-900 text-right capitalize">{configuration.groutColor.replace('-', ' ')}</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Grout Width:</span>
                    <span className="text-neutral-900 text-right">{configuration.groutWidth}</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-neutral-900 mb-4">Finishing Touches</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <span className="text-neutral-600">Edge Trim:</span>
                    <span className="text-neutral-900 text-right capitalize">{configuration.edgeTrim.replace('-', ' ')}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mb-6 p-4 bg-neutral-50 rounded-lg">
              <h4 className="text-neutral-900 mb-2">Best For:</h4>
              <div className="flex flex-wrap gap-2">
                {material.bestFor.map((use, idx) => (
                  <span key={idx} className="px-3 py-1 bg-white border border-neutral-200 rounded-full text-neutral-700 text-sm">
                    {use}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={onEdit}
                className="flex-1 px-6 py-3 border-2 border-neutral-300 text-neutral-700 rounded-lg hover:bg-neutral-50 transition-colors"
              >
                Edit Configuration
              </button>
              <button
                onClick={onRequestQuote}
                className="flex-1 px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
              >
                Request Quote from Contractors
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
              </svg>
            </div>
            <h4 className="text-neutral-900 mb-2">Calculate Amount</h4>
            <p className="text-neutral-600 text-sm mb-4">
              Determine how many tiles you need for your project
            </p>
            <button className="text-blue-600 hover:text-blue-700 text-sm">
              Open Calculator
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
              </svg>
            </div>
            <h4 className="text-neutral-900 mb-2">Request Samples</h4>
            <p className="text-neutral-600 text-sm mb-4">
              Order physical tile samples to see exact colors
            </p>
            <button className="text-purple-600 hover:text-purple-700 text-sm">
              Order Samples
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h4 className="text-neutral-900 mb-2">Save Specification</h4>
            <p className="text-neutral-600 text-sm mb-4">
              Download your tile spec sheet as PDF
            </p>
            <button className="text-green-600 hover:text-green-700 text-sm">
              Download PDF
            </button>
          </div>
        </div>

        {material.type === 'Natural Stone' && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <svg className="w-6 h-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <h4 className="text-neutral-900 mb-1">Natural Stone Maintenance</h4>
                <p className="text-neutral-600 text-sm">
                  Natural stone tiles require sealing to protect against stains and moisture. Plan to reseal every 1-2 years depending on traffic and use. Avoid acidic cleaners which can etch the surface.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
