import { useState } from 'react';
import {
  epoxyStyles,
  epoxyFinishes,
  epoxyColors,
  epoxyThicknesses,
  epoxyAdditives,
  epoxyApplications,
  epoxyBenefits
} from '../../data/epoxyOptions';

export interface EpoxyConfiguration {
  styleId: string;
  finishId: string;
  primaryColorId: string;
  secondaryColorId?: string;
  thicknessId: string;
  additiveId: string;
  application: string;
  squareFootage: number;
}

interface EpoxyCustomizerProps {
  styleId: string;
  onBack: () => void;
  onComplete: (config: EpoxyConfiguration) => void;
}

export function EpoxyCustomizer({ styleId, onBack, onComplete }: EpoxyCustomizerProps) {
  const style = epoxyStyles.find(s => s.id === styleId);
  const [showEducation, setShowEducation] = useState(false);
  const [educationTopic, setEducationTopic] = useState<string>('');

  const [configuration, setConfiguration] = useState<EpoxyConfiguration>({
    styleId,
    finishId: 'high-gloss',
    primaryColorId: 'gray',
    thicknessId: 'standard',
    additiveId: 'no-additive',
    application: 'Residential Garage',
    squareFootage: 400
  });

  const updateConfig = (updates: Partial<EpoxyConfiguration>) => {
    setConfiguration({ ...configuration, ...updates });
  };

  const selectedFinish = epoxyFinishes.find(f => f.id === configuration.finishId);
  const selectedColor = epoxyColors.find(c => c.id === configuration.primaryColorId);
  const selectedThickness = epoxyThicknesses.find(t => t.id === configuration.thicknessId);
  const selectedAdditive = epoxyAdditives.find(a => a.id === configuration.additiveId);

  const calculateEstimate = () => {
    let basePrice = 5; // Base price per sqft
    
    // Style pricing
    if (style?.priceCategory === 'Premium') basePrice += 2;
    if (style?.priceCategory === 'Luxury') basePrice += 4;
    
    // Finish pricing
    if (configuration.finishId === 'matte') basePrice += 0.75;
    if (configuration.finishId === 'textured') basePrice += 1.5;
    
    // Thickness pricing
    if (configuration.thicknessId === 'heavy-duty') basePrice += 2;
    if (configuration.thicknessId === 'industrial') basePrice += 4;
    
    // Additive pricing
    if (configuration.additiveId === 'small-flakes') basePrice += 1;
    if (configuration.additiveId === 'large-flakes') basePrice += 1.5;
    if (configuration.additiveId === 'metallic-pigment') basePrice += 3;
    if (configuration.additiveId === 'quartz-sand') basePrice += 2;
    if (configuration.additiveId === 'glitter') basePrice += 1;
    
    const total = basePrice * configuration.squareFootage;
    return {
      perSqFt: basePrice,
      total: total,
      low: total * 0.85,
      high: total * 1.15
    };
  };

  const estimate = calculateEstimate();

  const openEducation = (topic: string) => {
    setEducationTopic(topic);
    setShowEducation(true);
  };

  if (!style) {
    return <div>Style not found</div>;
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Styles</span>
          </button>
          
          <h1 className="text-neutral-900 mb-2">Customize Your {style.name}</h1>
          <p className="text-neutral-600">
            Design your perfect epoxy floor with our configuration tool
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Configuration Panel */}
          <div className="lg:col-span-2 space-y-6">
            {/* Project Details */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-neutral-900 mb-4">Project Details</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-neutral-700 mb-2 text-sm">Application Type</label>
                  <select
                    value={configuration.application}
                    onChange={(e) => updateConfig({ application: e.target.value })}
                    className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  >
                    {epoxyApplications.map(app => (
                      <option key={app} value={app}>{app}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-neutral-700 mb-2 text-sm">Square Footage</label>
                  <input
                    type="number"
                    value={configuration.squareFootage}
                    onChange={(e) => updateConfig({ squareFootage: parseInt(e.target.value) || 0 })}
                    className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                    min="0"
                  />
                </div>
              </div>
            </div>

            {/* Finish Selection */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-neutral-900">Select Finish</h3>
                <button
                  onClick={() => openEducation('finish')}
                  className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Learn More
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {epoxyFinishes.map(finish => (
                  <button
                    key={finish.id}
                    onClick={() => updateConfig({ finishId: finish.id })}
                    className={`p-4 rounded-lg border-2 text-left transition-all ${
                      configuration.finishId === finish.id
                        ? 'border-blue-600 bg-blue-50'
                        : 'border-neutral-200 hover:border-blue-300'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-neutral-900">{finish.name}</h4>
                      {configuration.finishId === finish.id && (
                        <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                    <p className="text-sm text-neutral-600 mb-2">{finish.description}</p>
                    <div className="flex items-center gap-4 text-xs text-neutral-500">
                      <span>Slip: {finish.slipResistance}</span>
                      <span>{finish.priceImpact}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Color Selection */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-neutral-900">Choose Color</h3>
                <button
                  onClick={() => openEducation('color')}
                  className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Learn More
                </button>
              </div>

              {/* Color categories */}
              {['Neutral', 'Bold', 'Metallic', 'Custom'].map(category => {
                const categoryColors = epoxyColors.filter(c => c.category === category);
                if (categoryColors.length === 0) return null;
                
                return (
                  <div key={category} className="mb-4">
                    <h4 className="text-sm text-neutral-700 mb-3">{category} Colors</h4>
                    <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
                      {categoryColors.map(color => (
                        <button
                          key={color.id}
                          onClick={() => updateConfig({ primaryColorId: color.id })}
                          className={`group relative aspect-square rounded-lg border-2 transition-all ${
                            configuration.primaryColorId === color.id
                              ? 'border-blue-600 scale-110'
                              : 'border-neutral-300 hover:border-blue-400'
                          }`}
                          title={color.name}
                          style={{ backgroundColor: color.hexCode }}
                        >
                          {configuration.primaryColorId === color.id && (
                            <div className="absolute inset-0 flex items-center justify-center">
                              <svg className="w-6 h-6 text-white drop-shadow-lg" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                              </svg>
                            </div>
                          )}
                          <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-neutral-900 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-10">
                            {color.name}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Thickness Selection */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-neutral-900">Coating Thickness</h3>
                <button
                  onClick={() => openEducation('thickness')}
                  className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Learn More
                </button>
              </div>
              
              <div className="space-y-3">
                {epoxyThicknesses.map(thickness => (
                  <button
                    key={thickness.id}
                    onClick={() => updateConfig({ thicknessId: thickness.id })}
                    className={`w-full p-4 rounded-lg border-2 text-left transition-all ${
                      configuration.thicknessId === thickness.id
                        ? 'border-blue-600 bg-blue-50'
                        : 'border-neutral-200 hover:border-blue-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="text-neutral-900">{thickness.name}</h4>
                          <span className="text-xs bg-neutral-100 text-neutral-700 px-2 py-1 rounded">
                            {thickness.priceCategory}
                          </span>
                        </div>
                        <p className="text-sm text-neutral-600 mb-2">{thickness.description}</p>
                        <div className="flex gap-1">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div
                              key={i}
                              className={`w-6 h-2 rounded ${
                                i < thickness.durability ? 'bg-blue-600' : 'bg-neutral-200'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      {configuration.thicknessId === thickness.id && (
                        <svg className="w-6 h-6 text-blue-600 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Decorative Additives */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-neutral-900">Decorative Additives</h3>
                <button
                  onClick={() => openEducation('additives')}
                  className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Learn More
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {epoxyAdditives.map(additive => (
                  <button
                    key={additive.id}
                    onClick={() => updateConfig({ additiveId: additive.id })}
                    className={`relative overflow-hidden rounded-lg border-2 transition-all ${
                      configuration.additiveId === additive.id
                        ? 'border-blue-600'
                        : 'border-neutral-200 hover:border-blue-300'
                    }`}
                  >
                    <div className="aspect-video relative">
                      <img
                        src={additive.image}
                        alt={additive.name}
                        className="w-full h-full object-cover"
                      />
                      {configuration.additiveId === additive.id && (
                        <div className="absolute top-2 right-2">
                          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                            <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="p-3 text-left">
                      <h4 className="text-neutral-900 text-sm mb-1">{additive.name}</h4>
                      <p className="text-xs text-neutral-600 mb-1">{additive.visualEffect}</p>
                      <p className="text-xs text-blue-600">{additive.priceImpact}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Summary Panel */}
          <div className="lg:col-span-1">
            <div className="sticky top-8 space-y-6">
              {/* Preview */}
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <img
                  src={style.image}
                  alt={style.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-neutral-900 mb-2">Your Configuration</h3>
                  
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between py-2 border-b border-neutral-100">
                      <span className="text-neutral-600">Style:</span>
                      <span className="text-neutral-900">{style.name}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-neutral-100">
                      <span className="text-neutral-600">Finish:</span>
                      <span className="text-neutral-900">{selectedFinish?.name}</span>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-neutral-100">
                      <span className="text-neutral-600">Color:</span>
                      <div className="flex items-center gap-2">
                        <div
                          className="w-6 h-6 rounded border border-neutral-300"
                          style={{ backgroundColor: selectedColor?.hexCode }}
                        />
                        <span className="text-neutral-900">{selectedColor?.name}</span>
                      </div>
                    </div>
                    <div className="flex justify-between py-2 border-b border-neutral-100">
                      <span className="text-neutral-600">Thickness:</span>
                      <span className="text-neutral-900">{selectedThickness?.thickness}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-neutral-100">
                      <span className="text-neutral-600">Additive:</span>
                      <span className="text-neutral-900">{selectedAdditive?.name}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-neutral-100">
                      <span className="text-neutral-600">Application:</span>
                      <span className="text-neutral-900">{configuration.application}</span>
                    </div>
                    <div className="flex justify-between py-2">
                      <span className="text-neutral-600">Area:</span>
                      <span className="text-neutral-900">{configuration.squareFootage} sq ft</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Price Estimate */}
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-6 text-white">
                <h3 className="text-white mb-4">Estimated Cost</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-baseline">
                    <span className="text-blue-100">Per Square Foot:</span>
                    <span className="text-2xl">${estimate.perSqFt.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-blue-400 pt-3">
                    <div className="flex justify-between items-baseline mb-2">
                      <span className="text-blue-100">Estimated Range:</span>
                    </div>
                    <div className="text-3xl">
                      ${estimate.low.toLocaleString(undefined, { maximumFractionDigits: 0 })} - ${estimate.high.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </div>
                  </div>
                </div>
                <p className="text-blue-100 text-xs mt-4">
                  *Estimate includes materials and professional installation. Final price may vary based on site conditions.
                </p>
              </div>

              {/* Action Button */}
              <button
                onClick={() => onComplete(configuration)}
                className="w-full py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-center"
              >
                Get Contractor Quotes
              </button>

              {/* Benefits */}
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h3 className="text-neutral-900 mb-4 text-sm">Key Benefits</h3>
                <div className="space-y-3">
                  {epoxyBenefits.slice(0, 4).map((benefit, index) => (
                    <div key={index} className="flex gap-3">
                      <div className="text-2xl flex-shrink-0">{benefit.icon}</div>
                      <div>
                        <h4 className="text-neutral-900 text-sm mb-1">{benefit.title}</h4>
                        <p className="text-xs text-neutral-600">{benefit.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Educational Modal */}
      {showEducation && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowEducation(false)}>
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-neutral-900 text-xl">Learn More</h2>
                <button
                  onClick={() => setShowEducation(false)}
                  className="text-neutral-400 hover:text-neutral-600"
                >
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="prose max-w-none">
                <p className="text-neutral-600">Educational content for {educationTopic} will be displayed here.</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
