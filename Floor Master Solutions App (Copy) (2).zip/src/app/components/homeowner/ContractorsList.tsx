import { contractors } from '../../data/contractors';

interface ContractorsListProps {
  onSelectContractor: (id: string) => void;
}

export function ContractorsList({ onSelectContractor }: ContractorsListProps) {
  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        <div className="mb-8">
          <h1 className="text-neutral-900 mb-2">Find a Contractor</h1>
          <p className="text-neutral-600">
            Connect with verified flooring professionals in your area
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl p-6 shadow-sm mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-neutral-700 mb-2">Location</label>
              <select className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent">
                <option>All Areas</option>
                <option>San Francisco</option>
                <option>Oakland</option>
                <option>San Jose</option>
                <option>Berkeley</option>
              </select>
            </div>
            <div>
              <label className="block text-neutral-700 mb-2">Specialty</label>
              <select className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent">
                <option>All Specialties</option>
                <option>Hardwood</option>
                <option>LVP</option>
                <option>Tile</option>
                <option>Carpet</option>
                <option>Laminate</option>
                <option>Engineered Wood</option>
              </select>
            </div>
            <div>
              <label className="block text-neutral-700 mb-2">Sort By</label>
              <select className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent">
                <option>Highest Rated</option>
                <option>Most Reviews</option>
                <option>Years Experience</option>
                <option>Fastest Response</option>
              </select>
            </div>
          </div>
        </div>

        {/* Contractors List */}
        <div className="space-y-4">
          {contractors.map((contractor) => (
            <button
              key={contractor.id}
              onClick={() => onSelectContractor(contractor.id)}
              className="w-full bg-white rounded-xl shadow-sm hover:shadow-md transition-all p-6 text-left group"
            >
              <div className="flex flex-col md:flex-row gap-6">
                {/* Profile Image */}
                <div className="flex-shrink-0">
                  <div className="w-24 h-24 rounded-full overflow-hidden bg-neutral-100">
                    <img
                      src={contractor.image}
                      alt={contractor.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                {/* Info */}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-neutral-900">{contractor.businessName}</h3>
                        {contractor.verified && (
                          <span className="inline-flex items-center gap-1 px-2 py-1 bg-amber-100 text-amber-700 rounded text-xs">
                            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                            </svg>
                            Verified
                          </span>
                        )}
                      </div>
                      <p className="text-neutral-600 text-sm">{contractor.name}</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 mb-3 text-sm">
                    <div className="flex items-center gap-1">
                      <svg className="w-4 h-4 text-amber-500" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                      <span className="text-neutral-900">{contractor.rating}</span>
                      <span className="text-neutral-500">({contractor.reviewCount} reviews)</span>
                    </div>
                    <span className="text-neutral-600">{contractor.yearsExperience} years experience</span>
                    <span className="text-neutral-600">{contractor.completedProjects} projects</span>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-3">
                    {contractor.specialties.map((specialty) => (
                      <span
                        key={specialty}
                        className="px-3 py-1 bg-neutral-100 text-neutral-700 rounded-full text-sm"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center gap-4 text-sm text-neutral-600">
                    <div className="flex items-center gap-1">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                      {contractor.serviceArea.join(', ')}
                    </div>
                    <div className="flex items-center gap-1">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      Responds {contractor.responseTime.toLowerCase()}
                    </div>
                  </div>
                </div>

                {/* CTA */}
                <div className="flex items-center">
                  <div className="px-6 py-3 bg-amber-600 text-white rounded-lg group-hover:bg-amber-700 transition-colors">
                    View Profile
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
