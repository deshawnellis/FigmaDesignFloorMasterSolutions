import { useState } from 'react';

interface LVPSelectorProps {
  onSelectStyle: (styleId: string) => void;
  onBack: () => void;
}

const lvpStyles = [
  {
    id: 'wood-look',
    name: 'Wood-Look LVP',
    description: 'Realistic wood grain textures with waterproof durability',
    image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=800&q=80',
    benefits: [
      'Authentic wood appearance',
      '100% waterproof',
      'Warm, natural aesthetics',
      'Pet and kid-friendly'
    ],
    subcategories: [
      {
        id: 'wood-oak',
        name: 'Oak Designs',
        count: 24,
        image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=400&q=80'
      },
      {
        id: 'wood-maple',
        name: 'Maple Designs',
        count: 18,
        image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=400&q=80'
      },
      {
        id: 'wood-walnut',
        name: 'Walnut Designs',
        count: 15,
        image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=400&q=80'
      },
      {
        id: 'wood-pine',
        name: 'Pine & Rustic',
        count: 12,
        image: 'https://images.unsplash.com/photo-1615876234886-fd9a39fda97f?w=400&q=80'
      }
    ]
  },
  {
    id: 'stone-look',
    name: 'Stone-Look LVP',
    description: 'Elegant stone and tile aesthetics without the cold, hard surface',
    image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=800&q=80',
    benefits: [
      'Luxurious stone appearance',
      'Warmer than real stone',
      'Softer underfoot',
      'Easy maintenance'
    ],
    subcategories: [
      {
        id: 'stone-marble',
        name: 'Marble Look',
        count: 16,
        image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=400&q=80'
      },
      {
        id: 'stone-slate',
        name: 'Slate & Concrete',
        count: 14,
        image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=400&q=80'
      },
      {
        id: 'stone-travertine',
        name: 'Travertine',
        count: 10,
        image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=400&q=80'
      },
      {
        id: 'stone-limestone',
        name: 'Limestone',
        count: 8,
        image: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=400&q=80'
      }
    ]
  },
  {
    id: 'abstract-pattern',
    name: 'Abstract & Pattern LVP',
    description: 'Modern geometric and artistic designs for unique spaces',
    image: 'https://images.unsplash.com/photo-1600566753151-384129cf4e3e?w=800&q=80',
    benefits: [
      'Unique modern designs',
      'Bold visual statements',
      'Contemporary aesthetics',
      'Conversation starters'
    ],
    subcategories: [
      {
        id: 'abstract-geometric',
        name: 'Geometric Patterns',
        count: 12,
        image: 'https://images.unsplash.com/photo-1600566753151-384129cf4e3e?w=400&q=80'
      },
      {
        id: 'abstract-mosaic',
        name: 'Mosaic Designs',
        count: 9,
        image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=400&q=80'
      },
      {
        id: 'abstract-metallic',
        name: 'Metallic Finishes',
        count: 7,
        image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=400&q=80'
      },
      {
        id: 'abstract-textile',
        name: 'Textile Inspired',
        count: 6,
        image: 'https://images.unsplash.com/photo-1615876234886-fd9a39fda97f?w=400&q=80'
      }
    ]
  }
];

export function LVPSelector({ onSelectStyle, onBack }: LVPSelectorProps) {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const handleSelectSubcategory = (subcategoryId: string) => {
    onSelectStyle(subcategoryId);
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:ml-32">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Flooring Types
          </button>
          
          <h1 className="text-neutral-900 mb-3">Choose Your LVP Style</h1>
          <p className="text-neutral-600 text-lg">
            Luxury Vinyl Plank (LVP) offers the beauty of natural materials with unbeatable durability and 100% waterproof protection.
          </p>
        </div>

        {/* Why LVP Section */}
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-6 mb-8">
          <h3 className="text-neutral-900 mb-4 flex items-center gap-2">
            <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Why Choose LVP?
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white rounded-xl p-4">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mb-3">
                <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                </svg>
              </div>
              <h4 className="text-neutral-900 mb-1">100% Waterproof</h4>
              <p className="text-sm text-neutral-600">Perfect for kitchens, bathrooms, basements, and laundry rooms</p>
            </div>
            <div className="bg-white rounded-xl p-4">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mb-3">
                <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h4 className="text-neutral-900 mb-1">Cost Effective</h4>
              <p className="text-sm text-neutral-600">$3-8/sq ft installed, much less than hardwood or tile</p>
            </div>
            <div className="bg-white rounded-xl p-4">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mb-3">
                <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2 1m2-1l-2-1m2 1v2.5M14 4l-2-1-2 1M4 7l2-1M4 7l2 1M4 7v2.5M12 21l-2-1m2 1l2-1m-2 1v-2.5M6 18l-2-1v-2.5M18 18l2-1v-2.5" />
                </svg>
              </div>
              <h4 className="text-neutral-900 mb-1">Easy Installation</h4>
              <p className="text-sm text-neutral-600">Click-lock system, DIY-friendly, faster install times</p>
            </div>
            <div className="bg-white rounded-xl p-4">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mb-3">
                <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
              <h4 className="text-neutral-900 mb-1">Low Maintenance</h4>
              <p className="text-sm text-neutral-600">Simple sweep and mop, no refinishing needed</p>
            </div>
          </div>
        </div>

        {/* Main Style Categories */}
        <div className="space-y-8">
          {lvpStyles.map((style) => (
            <div key={style.id} className="bg-white rounded-2xl overflow-hidden shadow-sm">
              {/* Category Header */}
              <div className="p-6 border-b border-neutral-200">
                <div className="flex flex-col md:flex-row gap-6">
                  <img
                    src={style.image}
                    alt={style.name}
                    className="w-full md:w-48 h-48 object-cover rounded-xl"
                  />
                  <div className="flex-1">
                    <h2 className="text-neutral-900 mb-2">{style.name}</h2>
                    <p className="text-neutral-600 mb-4">{style.description}</p>
                    <div className="grid grid-cols-2 gap-3">
                      {style.benefits.map((benefit, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm text-neutral-700">
                          <svg className="w-4 h-4 text-green-600 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          {benefit}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Subcategories */}
              <div className="p-6">
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {style.subcategories.map((subcategory) => (
                    <button
                      key={subcategory.id}
                      onClick={() => handleSelectSubcategory(subcategory.id)}
                      className="group text-left bg-neutral-50 rounded-xl overflow-hidden hover:shadow-md transition-all hover:-translate-y-1"
                    >
                      <div className="aspect-square bg-neutral-200 overflow-hidden">
                        <img
                          src={subcategory.image}
                          alt={subcategory.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="text-neutral-900 mb-1">{subcategory.name}</h3>
                        <p className="text-sm text-neutral-600">{subcategory.count} options available</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-8 bg-amber-50 border border-amber-200 rounded-2xl p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center flex-shrink-0">
              <svg className="w-6 h-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div className="flex-1">
              <h3 className="text-neutral-900 mb-2">Need Help Choosing?</h3>
              <p className="text-neutral-700 mb-4">
                Not sure which LVP style is right for your space? Our AI assistant can help you choose based on your room type, lifestyle, and design preferences.
              </p>
              <button className="text-amber-600 hover:text-amber-700 transition-colors flex items-center gap-2">
                Chat with AI Assistant
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
