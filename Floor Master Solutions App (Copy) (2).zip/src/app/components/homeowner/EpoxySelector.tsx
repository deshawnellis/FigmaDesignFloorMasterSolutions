import { useState } from 'react';
import { epoxyStyles, EpoxyStyle } from '../../data/epoxyOptions';

interface EpoxySelectorProps {
  onSelectStyle: (styleId: string) => void;
  onBack: () => void;
}

export function EpoxySelector({ onSelectStyle, onBack }: EpoxySelectorProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPriceRange, setSelectedPriceRange] = useState<string>('all');

  const filteredStyles = epoxyStyles.filter(style => {
    const matchesCategory = selectedCategory === 'all' || style.priceCategory === selectedCategory;
    const matchesPrice = selectedPriceRange === 'all' || style.priceCategory === selectedPriceRange;
    return matchesCategory && matchesPrice;
  });

  const getPriceBadgeColor = (category: string) => {
    switch (category) {
      case 'Budget':
        return 'bg-green-100 text-green-800';
      case 'Mid-Range':
        return 'bg-blue-100 text-blue-800';
      case 'Premium':
        return 'bg-purple-100 text-purple-800';
      case 'Luxury':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-neutral-100 text-neutral-800';
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Flooring Types</span>
          </button>
          
          <h1 className="text-neutral-900 mb-2">Choose Your Epoxy Style</h1>
          <p className="text-neutral-600">
            Select from {epoxyStyles.length} professional epoxy flooring styles
          </p>
        </div>

        {/* Info Banner */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl p-6 mb-8 text-white">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center flex-shrink-0">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h3 className="text-white mb-2">What is Epoxy Flooring?</h3>
              <p className="text-blue-100 mb-3">
                Epoxy flooring is a high-performance coating system applied directly over concrete. It creates a seamless, 
                durable surface that's resistant to chemicals, moisture, and heavy traffic. Popular in garages, basements, 
                and commercial spaces.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                <div className="bg-white/10 rounded-lg p-3">
                  <div className="text-2xl mb-1">🛡️</div>
                  <div className="text-sm">Extreme Durability</div>
                </div>
                <div className="bg-white/10 rounded-lg p-3">
                  <div className="text-2xl mb-1">💧</div>
                  <div className="text-sm">Waterproof</div>
                </div>
                <div className="bg-white/10 rounded-lg p-3">
                  <div className="text-2xl mb-1">🎨</div>
                  <div className="text-sm">Customizable</div>
                </div>
                <div className="bg-white/10 rounded-lg p-3">
                  <div className="text-2xl mb-1">🧹</div>
                  <div className="text-sm">Easy to Clean</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-neutral-900 text-sm">Filter Styles</h3>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSelectedPriceRange('all');
              }}
              className="text-blue-600 hover:text-blue-700 text-sm transition-colors"
            >
              Reset Filters
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="priceRange" className="block text-neutral-700 mb-2 text-sm">
                Price Category
              </label>
              <select
                id="priceRange"
                value={selectedPriceRange}
                onChange={(e) => setSelectedPriceRange(e.target.value)}
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              >
                <option value="all">All Price Ranges</option>
                <option value="Budget">Budget</option>
                <option value="Mid-Range">Mid-Range</option>
                <option value="Premium">Premium</option>
                <option value="Luxury">Luxury</option>
              </select>
            </div>
          </div>
        </div>

        {/* Epoxy Styles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredStyles.map((style) => (
            <div
              key={style.id}
              className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-neutral-200 hover:border-blue-300 group"
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={style.image}
                  alt={style.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3">
                  <span className={`inline-block px-3 py-1 rounded-full text-xs ${getPriceBadgeColor(style.priceCategory)}`}>
                    {style.priceCategory}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-neutral-900 mb-2">{style.name}</h3>
                <p className="text-sm text-neutral-600 mb-4 line-clamp-2">
                  {style.description}
                </p>

                {/* Characteristics */}
                <div className="mb-4">
                  <p className="text-xs text-neutral-600 mb-2">Key Features:</p>
                  <div className="flex flex-wrap gap-1">
                    {style.characteristics.slice(0, 3).map((char, index) => (
                      <span
                        key={index}
                        className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded"
                      >
                        {char}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Best For */}
                <div className="mb-4">
                  <p className="text-xs text-neutral-600 mb-2">Best For:</p>
                  <ul className="text-xs text-neutral-700 space-y-1">
                    {style.bestFor.slice(0, 3).map((use, index) => (
                      <li key={index} className="flex items-start gap-1">
                        <span className="text-blue-600">•</span>
                        <span>{use}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Select Button */}
                <button
                  onClick={() => onSelectStyle(style.id)}
                  className="w-full py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Customize This Style
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Info Section */}
        <div className="mt-12 bg-white rounded-xl p-8 shadow-sm">
          <h2 className="text-neutral-900 mb-6">Why Choose Epoxy Flooring?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <div>
                <h3 className="text-neutral-900 mb-2">Unmatched Durability</h3>
                <p className="text-sm text-neutral-600">
                  Epoxy floors can withstand heavy machinery, impacts, and chemical spills without damage.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <svg className="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <h3 className="text-neutral-900 mb-2">Cost Effective</h3>
                <p className="text-sm text-neutral-600">
                  Long lifespan and low maintenance costs make epoxy an excellent investment.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <svg className="w-6 h-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
                </svg>
              </div>
              <div>
                <h3 className="text-neutral-900 mb-2">Endless Customization</h3>
                <p className="text-sm text-neutral-600">
                  Choose from countless colors, patterns, and finishes to match your vision.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
