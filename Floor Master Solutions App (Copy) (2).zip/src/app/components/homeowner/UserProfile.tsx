interface UserProfileProps {
  userType: 'homeowner' | 'contractor';
  onLogout: () => void;
}

export function UserProfile({ userType, onLogout }: UserProfileProps) {
  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-4xl mx-auto px-6 py-8 md:ml-64">
        <h1 className="text-neutral-900 mb-8">Profile Settings</h1>

        {/* Profile Info */}
        <div className="bg-white rounded-2xl shadow-sm p-8 mb-6">
          <div className="flex items-center gap-6 mb-8">
            <div className="w-24 h-24 rounded-full bg-amber-100 flex items-center justify-center">
              <svg className="w-12 h-12 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </div>
            <div>
              <h2 className="text-neutral-900 mb-1">
                {userType === 'homeowner' ? 'Homeowner Account' : 'Contractor Account'}
              </h2>
              <p className="text-neutral-600">Manage your account settings and preferences</p>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-neutral-700 mb-2">Full Name</label>
              <input
                type="text"
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                placeholder="John Doe"
                defaultValue="John Doe"
              />
            </div>

            {userType === 'contractor' && (
              <div>
                <label className="block text-neutral-700 mb-2">Business Name</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                  placeholder="Your Business LLC"
                  defaultValue="Premier Flooring Solutions"
                />
              </div>
            )}

            <div>
              <label className="block text-neutral-700 mb-2">Email</label>
              <input
                type="email"
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                placeholder="you@example.com"
                defaultValue="john@example.com"
              />
            </div>

            <div>
              <label className="block text-neutral-700 mb-2">Phone Number</label>
              <input
                type="tel"
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                placeholder="(555) 123-4567"
                defaultValue="(555) 123-4567"
              />
            </div>

            {userType === 'homeowner' && (
              <div>
                <label className="block text-neutral-700 mb-2">Address</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                  placeholder="123 Main St, City, State, ZIP"
                />
              </div>
            )}

            {userType === 'contractor' && (
              <>
                <div>
                  <label className="block text-neutral-700 mb-2">Service Areas</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                    placeholder="San Francisco, Oakland, San Jose"
                    defaultValue="San Francisco, Oakland, San Jose"
                  />
                </div>

                <div>
                  <label className="block text-neutral-700 mb-2">Years of Experience</label>
                  <input
                    type="number"
                    className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                    defaultValue="15"
                  />
                </div>

                <div>
                  <label className="block text-neutral-700 mb-2">Specialties</label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {['Hardwood', 'LVP', 'Tile', 'Carpet', 'Laminate', 'Engineered Wood'].map((specialty) => (
                      <label key={specialty} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          className="w-4 h-4 text-amber-600 border-neutral-300 rounded focus:ring-amber-600"
                          defaultChecked={['Hardwood', 'LVP', 'Tile'].includes(specialty)}
                        />
                        <span className="text-neutral-700">{specialty}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </>
            )}

            <div className="pt-4">
              <button className="bg-amber-600 text-white px-8 py-3 rounded-lg hover:bg-amber-700 transition-colors">
                Save Changes
              </button>
            </div>
          </div>
        </div>

        {/* Password */}
        <div className="bg-white rounded-2xl shadow-sm p-8 mb-6">
          <h3 className="text-neutral-900 mb-6">Change Password</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-neutral-700 mb-2">Current Password</label>
              <input
                type="password"
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-neutral-700 mb-2">New Password</label>
              <input
                type="password"
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-neutral-700 mb-2">Confirm New Password</label>
              <input
                type="password"
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              />
            </div>
            <button className="bg-neutral-900 text-white px-8 py-3 rounded-lg hover:bg-neutral-800 transition-colors">
              Update Password
            </button>
          </div>
        </div>

        {/* Logout */}
        <div className="bg-white rounded-2xl shadow-sm p-8">
          <h3 className="text-neutral-900 mb-4">Account Actions</h3>
          <button
            onClick={onLogout}
            className="bg-red-600 text-white px-8 py-3 rounded-lg hover:bg-red-700 transition-colors"
          >
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}
