import { useState } from 'react';

interface SimplifiedDashboardProps {
  onNavigate: (page: 'flooring' | 'visualizer' | 'chat' | 'contractors' | 'projects') => void;
  onSelectFlooring: (id: string) => void;
  userName?: string;
}

export function SimplifiedDashboard({ onNavigate, onSelectFlooring, userName = 'there' }: SimplifiedDashboardProps) {
  const [showComparison, setShowComparison] = useState(false);

  const quickActions = [
    {
      id: 'explore',
      title: 'Explore Flooring',
      description: 'Browse 7 flooring types',
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      ),
      color: 'from-blue-500 to-blue-600',
      action: () => onNavigate('flooring')
    },
    {
      id: 'visualize',
      title: 'Visualize Your Space',
      description: 'See floors in your room',
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
      ),
      color: 'from-purple-500 to-purple-600',
      action: () => onNavigate('visualizer')
    },
    {
      id: 'chat',
      title: 'Ask AI Assistant',
      description: 'Get instant answers',
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
        </svg>
      ),
      color: 'from-green-500 to-green-600',
      action: () => onNavigate('chat')
    },
    {
      id: 'contractors',
      title: 'Find Contractors',
      description: 'Get professional quotes',
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      ),
      color: 'from-amber-500 to-amber-600',
      action: () => onNavigate('contractors')
    }
  ];

  const popularChoices = [
    {
      id: 'lvp',
      name: 'LVP',
      subtitle: 'Most Popular',
      icon: '💧',
      description: '100% Waterproof',
      color: 'bg-blue-500',
      image: 'https://images.unsplash.com/photo-1604410880766-737427d11b70?w=400&q=80'
    },
    {
      id: 'hardwood',
      name: 'Hardwood',
      subtitle: 'Premium',
      icon: '🌳',
      description: 'Timeless Beauty',
      color: 'bg-amber-600',
      image: 'https://images.unsplash.com/photo-1631669394390-baf737ef47de?w=400&q=80'
    },
    {
      id: 'tile',
      name: 'Tile',
      subtitle: 'Durable',
      icon: '⬜',
      description: 'Easy to Clean',
      color: 'bg-purple-500',
      image: 'https://images.unsplash.com/photo-1719782758766-f0a4a3808afe?w=400&q=80'
    },
    {
      id: 'epoxy',
      name: 'Epoxy',
      subtitle: 'Modern',
      icon: '✨',
      description: 'Ultra Durable',
      color: 'bg-teal-500',
      image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=400&q=80'
    }
  ];

  const stats = [
    { label: 'Flooring Options', value: '7+', icon: '🏠', color: 'text-blue-600' },
    { label: 'Verified Contractors', value: '500+', icon: '👷', color: 'text-green-600' },
    { label: 'Happy Customers', value: '1000+', icon: '⭐', color: 'text-amber-600' },
    { label: 'AI Support', value: '24/7', icon: '💬', color: 'text-purple-600' }
  ];

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64 space-y-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
          <div className="relative z-10">
            <h1 className="text-white text-4xl md:text-5xl mb-3">
              Welcome{userName !== 'there' && `, ${userName}`}! 👋
            </h1>
            <p className="text-blue-100 text-xl mb-8">
              Let's find the perfect flooring for your space
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {stats.map((stat, index) => (
                <div key={index} className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
                  <div className="text-3xl mb-2">{stat.icon}</div>
                  <div className="text-2xl mb-1">{stat.value}</div>
                  <div className="text-blue-100 text-sm">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-neutral-900 mb-4 flex items-center gap-2">
            <span>🚀</span>
            <span>Quick Actions</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action) => (
              <button
                key={action.id}
                onClick={action.action}
                className="group bg-white rounded-2xl p-6 hover:shadow-xl transition-all border-2 border-transparent hover:border-blue-200 text-left"
              >
                <div className={`w-16 h-16 bg-gradient-to-br ${action.color} rounded-2xl flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform`}>
                  {action.icon}
                </div>
                <h3 className="text-neutral-900 mb-2">{action.title}</h3>
                <p className="text-neutral-600 text-sm">{action.description}</p>
                <div className="flex items-center gap-2 text-blue-600 mt-4 group-hover:gap-3 transition-all">
                  <span className="text-sm">Get Started</span>
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Popular Flooring Choices */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-neutral-900 flex items-center gap-2">
              <span>🔥</span>
              <span>Most Popular Choices</span>
            </h2>
            <button
              onClick={() => onNavigate('flooring')}
              className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1 transition-colors"
            >
              <span>View All</span>
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {popularChoices.map((choice) => (
              <button
                key={choice.id}
                onClick={() => onSelectFlooring(choice.id)}
                className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-2xl transition-all border border-neutral-200 hover:border-blue-300"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={choice.image}
                    alt={choice.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className={`absolute top-3 left-3 ${choice.color} text-white text-xs px-3 py-1 rounded-full`}>
                    {choice.subtitle}
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <div className="flex items-center gap-2 text-white mb-1">
                      <span className="text-2xl">{choice.icon}</span>
                      <h3 className="text-white text-xl">{choice.name}</h3>
                    </div>
                    <p className="text-white text-sm">{choice.description}</p>
                  </div>
                </div>
                <div className="p-4 bg-gradient-to-r from-neutral-50 to-white">
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-600 text-sm">Learn More</span>
                    <svg className="w-5 h-5 text-blue-600 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* How It Works */}
        <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-neutral-200">
          <h2 className="text-neutral-900 text-center mb-8 flex items-center justify-center gap-2">
            <span>📋</span>
            <span>How It Works - Simple 4 Steps</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              {
                number: '1',
                title: 'Browse',
                description: 'Explore flooring options and compare specs',
                icon: '🔍',
                color: 'from-blue-500 to-blue-600'
              },
              {
                number: '2',
                title: 'Customize',
                description: 'Design your perfect floor with our tools',
                icon: '🎨',
                color: 'from-purple-500 to-purple-600'
              },
              {
                number: '3',
                title: 'Visualize',
                description: 'See how it looks in your actual space',
                icon: '📸',
                color: 'from-green-500 to-green-600'
              },
              {
                number: '4',
                title: 'Install',
                description: 'Connect with pros and get it installed',
                icon: '✅',
                color: 'from-amber-500 to-amber-600'
              }
            ].map((step) => (
              <div key={step.number} className="text-center relative">
                <div className={`w-16 h-16 bg-gradient-to-br ${step.color} rounded-2xl flex items-center justify-center text-white text-2xl mx-auto mb-4 shadow-lg`}>
                  {step.icon}
                </div>
                <div className={`absolute top-2 -right-2 w-8 h-8 bg-gradient-to-br ${step.color} rounded-full flex items-center justify-center text-white text-sm`}>
                  {step.number}
                </div>
                <h3 className="text-neutral-900 mb-2">{step.title}</h3>
                <p className="text-neutral-600 text-sm">{step.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Help Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-2xl p-6 border-2 border-green-200">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center text-white flex-shrink-0">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
              </div>
              <div>
                <h3 className="text-neutral-900 mb-2">Need Help Deciding?</h3>
                <p className="text-neutral-600 text-sm mb-3">
                  Our AI assistant can recommend the best flooring for your needs, budget, and lifestyle.
                </p>
                <button
                  onClick={() => onNavigate('chat')}
                  className="text-green-600 hover:text-green-700 text-sm flex items-center gap-1 transition-colors"
                >
                  <span>Chat with AI</span>
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 border-2 border-purple-200">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center text-white flex-shrink-0">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <div>
                <h3 className="text-neutral-900 mb-2">Learning Resources</h3>
                <p className="text-neutral-600 text-sm mb-3">
                  Access our comprehensive guides, comparisons, and tutorials to make informed decisions.
                </p>
                <button className="text-purple-600 hover:text-purple-700 text-sm flex items-center gap-1 transition-colors">
                  <span>Browse Guides</span>
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
