import { useState } from 'react';
import { LVPEducationalModal } from './LVPEducationalModal';

export interface LVPConfiguration {
  styleId: string;
  styleName: string;
  wearLayer: string;
  thickness: string;
  plankWidth: string;
  plankLength: string;
  texture: string;
  color: string;
  finish: string;
  backing: string;
  installation: string;
  underpadIncluded: boolean;
  price: number;
}

interface LVPCustomizerProps {
  styleId: string;
  onBack: () => void;
  onComplete: (configuration: LVPConfiguration) => void;
}

const styleNames: { [key: string]: string } = {
  'wood-oak': 'Oak Wood-Look LVP',
  'wood-maple': 'Maple Wood-Look LVP',
  'wood-walnut': 'Walnut Wood-Look LVP',
  'wood-pine': 'Pine & Rustic Wood-Look LVP',
  'stone-marble': 'Marble Stone-Look LVP',
  'stone-slate': 'Slate & Concrete LVP',
  'stone-travertine': 'Travertine Stone-Look LVP',
  'stone-limestone': 'Limestone Stone-Look LVP',
  'abstract-geometric': 'Geometric Pattern LVP',
  'abstract-mosaic': 'Mosaic Design LVP',
  'abstract-metallic': 'Metallic Finish LVP',
  'abstract-textile': 'Textile-Inspired LVP'
};

export function LVPCustomizer({ styleId, onBack, onComplete }: LVPCustomizerProps) {
  const [wearLayer, setWearLayer] = useState('12mil');
  const [thickness, setThickness] = useState('6mm');
  const [plankWidth, setPlankWidth] = useState('7inch');
  const [plankLength, setPlankLength] = useState('48inch');
  const [texture, setTexture] = useState('embossed');
  const [color, setColor] = useState('natural');
  const [finish, setFinish] = useState('matte');
  const [backing, setBacking] = useState('rigid-core');
  const [installation, setInstallation] = useState('click-lock');
  const [underpadIncluded, setUnderpadIncluded] = useState(true);
  const [showEducation, setShowEducation] = useState<string | null>(null);

  const wearLayerOptions = [
    { 
      value: '6mil', 
      label: '6 mil Wear Layer',
      description: 'Residential light traffic',
      price: 3.50,
      warranty: '10 years'
    },
    { 
      value: '12mil', 
      label: '12 mil Wear Layer',
      description: 'Residential moderate traffic',
      price: 4.50,
      warranty: '15 years',
      recommended: true
    },
    { 
      value: '20mil', 
      label: '20 mil Wear Layer',
      description: 'Residential heavy / Light commercial',
      price: 5.50,
      warranty: '20 years'
    },
    { 
      value: '30mil', 
      label: '30 mil Wear Layer',
      description: 'Commercial grade',
      price: 7.00,
      warranty: '25 years'
    }
  ];

  const thicknessOptions = [
    { value: '4mm', label: '4mm Total Thickness', description: 'Standard, economical' },
    { value: '6mm', label: '6mm Total Thickness', description: 'Most popular choice', recommended: true },
    { value: '8mm', label: '8mm Total Thickness', description: 'Premium, sturdy feel' }
  ];

  const widthOptions = [
    { value: '5inch', label: '5" Wide Planks', description: 'Traditional look' },
    { value: '7inch', label: '7" Wide Planks', description: 'Modern standard', recommended: true },
    { value: '9inch', label: '9" Wide Planks', description: 'Contemporary wide' }
  ];

  const lengthOptions = [
    { value: '36inch', label: '36" Long Planks', description: 'Standard length' },
    { value: '48inch', label: '48" Long Planks', description: 'Popular choice', recommended: true },
    { value: '60inch', label: '60" Long Planks', description: 'Fewer seams' }
  ];

  const textureOptions = [
    {
      value: 'smooth',
      label: 'Smooth Surface',
      description: 'Clean, modern look',
      image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=400&q=80'
    },
    {
      value: 'embossed',
      label: 'Embossed Texture',
      description: 'Realistic wood grain feel',
      image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=400&q=80',
      recommended: true
    },
    {
      value: 'hand-scraped',
      label: 'Hand-Scraped',
      description: 'Rustic, textured appearance',
      image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=400&q=80'
    },
    {
      value: 'wire-brushed',
      label: 'Wire-Brushed',
      description: 'Subtle texture, hides scratches',
      image: 'https://images.unsplash.com/photo-1615876234886-fd9a39fda97f?w=400&q=80'
    }
  ];

  const colorOptions = [
    { value: 'light', label: 'Light Tones', hex: '#E8DCC4', description: 'Bright, airy spaces' },
    { value: 'natural', label: 'Natural Tones', hex: '#B8956A', description: 'Versatile, classic', recommended: true },
    { value: 'medium', label: 'Medium Tones', hex: '#8B6F47', description: 'Warm, inviting' },
    { value: 'dark', label: 'Dark Tones', hex: '#4A3728', description: 'Bold, dramatic' },
    { value: 'grey', label: 'Grey Tones', hex: '#A0A0A0', description: 'Modern, contemporary' },
    { value: 'whitewash', label: 'Whitewashed', hex: '#F5F3ED', description: 'Coastal, farmhouse' }
  ];

  const finishOptions = [
    { value: 'matte', label: 'Matte Finish', description: 'No glare, hides imperfections', recommended: true },
    { value: 'satin', label: 'Satin Finish', description: 'Slight sheen, elegant look' },
    { value: 'gloss', label: 'Gloss Finish', description: 'High shine, modern aesthetic' }
  ];

  const backingOptions = [
    { 
      value: 'standard', 
      label: 'Standard Backing',
      description: 'Flexible, good for level floors',
      price: 0
    },
    { 
      value: 'rigid-core', 
      label: 'Rigid Core (SPC/WPC)',
      description: 'Most stable, forgiving installation',
      price: 0.50,
      recommended: true
    },
    { 
      value: 'enhanced', 
      label: 'Enhanced Backing',
      description: 'Extra sound dampening',
      price: 0.75
    }
  ];

  const installationOptions = [
    { value: 'click-lock', label: 'Click-Lock System', description: 'Easy DIY, floating floor', recommended: true },
    { value: 'glue-down', label: 'Glue-Down', description: 'Permanent, commercial grade' },
    { value: 'loose-lay', label: 'Loose-Lay', description: 'No adhesive, easy removal' }
  ];

  const calculatePrice = (): number => {
    const wearLayerPrice = wearLayerOptions.find(o => o.value === wearLayer)?.price || 4.50;
    const backingPrice = backingOptions.find(o => o.value === backing)?.price || 0;
    const thicknessMultiplier = thickness === '8mm' ? 1.15 : thickness === '4mm' ? 0.85 : 1.0;
    const finishMultiplier = finish === 'gloss' ? 1.1 : 1.0;
    
    return Number(((wearLayerPrice + backingPrice) * thicknessMultiplier * finishMultiplier).toFixed(2));
  };

  const handleComplete = () => {
    const configuration: LVPConfiguration = {
      styleId,
      styleName: styleNames[styleId] || 'Custom LVP',
      wearLayer,
      thickness,
      plankWidth,
      plankLength,
      texture,
      color,
      finish,
      backing,
      installation,
      underpadIncluded,
      price: calculatePrice()
    };
    onComplete(configuration);
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      {showEducation && (
        <LVPEducationalModal topic={showEducation} onClose={() => setShowEducation(null)} />
      )}
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:ml-32">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Style Selection
          </button>
          
          <h1 className="text-neutral-900 mb-3">Customize Your LVP</h1>
          <p className="text-neutral-600 text-lg">
            {styleNames[styleId] || 'Custom LVP'} - Choose specifications for your perfect floor
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Configuration Options */}
          <div className="lg:col-span-2 space-y-8">
            {/* Wear Layer */}
            <div className="bg-white rounded-2xl p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-neutral-900 mb-2">Wear Layer Thickness</h2>
                  <p className="text-sm text-neutral-600">
                    The wear layer determines durability and warranty. Thicker = longer lasting.
                  </p>
                </div>
                <button
                  onClick={() => setShowEducation('wear-layer')}
                  className="flex items-center gap-1 text-blue-600 hover:text-blue-700 text-sm transition-colors flex-shrink-0 ml-4"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Learn More
                </button>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                {wearLayerOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setWearLayer(option.value)}
                    className={`relative text-left p-4 rounded-xl border-2 transition-all ${
                      wearLayer === option.value
                        ? 'border-amber-600 bg-amber-50'
                        : 'border-neutral-200 hover:border-neutral-300'
                    }`}
                  >
                    {option.recommended && (
                      <span className="absolute -top-2 -right-2 bg-green-600 text-white text-xs px-2 py-1 rounded-full">
                        Popular
                      </span>
                    )}
                    <h3 className="text-neutral-900 mb-1">{option.label}</h3>
                    <p className="text-sm text-neutral-600 mb-2">{option.description}</p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-amber-600">${option.price}/sq ft</span>
                      <span className="text-neutral-500">{option.warranty} warranty</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Total Thickness */}
            <div className="bg-white rounded-2xl p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-neutral-900 mb-2">Total Thickness</h2>
                  <p className="text-sm text-neutral-600">
                    Thicker planks feel more substantial and provide better sound dampening.
                  </p>
                </div>
                <button
                  onClick={() => setShowEducation('total-thickness')}
                  className="flex items-center gap-1 text-blue-600 hover:text-blue-700 text-sm transition-colors flex-shrink-0 ml-4"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Learn More
                </button>
              </div>
              <div className="grid sm:grid-cols-3 gap-4">
                {thicknessOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setThickness(option.value)}
                    className={`relative text-center p-4 rounded-xl border-2 transition-all ${
                      thickness === option.value
                        ? 'border-amber-600 bg-amber-50'
                        : 'border-neutral-200 hover:border-neutral-300'
                    }`}
                  >
                    {option.recommended && (
                      <span className="absolute -top-2 right-2 bg-green-600 text-white text-xs px-2 py-1 rounded-full">
                        Most Popular
                      </span>
                    )}
                    <h3 className="text-neutral-900 mb-1">{option.label}</h3>
                    <p className="text-sm text-neutral-600">{option.description}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Plank Dimensions */}
            <div className="bg-white rounded-2xl p-6">
              <h2 className="text-neutral-900 mb-4">Plank Dimensions</h2>
              
              {/* Width */}
              <div className="mb-6">
                <h3 className="text-neutral-900 mb-3">Width</h3>
                <div className="grid sm:grid-cols-3 gap-3">
                  {widthOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => setPlankWidth(option.value)}
                      className={`text-center p-3 rounded-xl border-2 transition-all ${
                        plankWidth === option.value
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-neutral-300'
                      }`}
                    >
                      <p className="text-neutral-900 mb-1">{option.label}</p>
                      <p className="text-xs text-neutral-600">{option.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Length */}
              <div>
                <h3 className="text-neutral-900 mb-3">Length</h3>
                <div className="grid sm:grid-cols-3 gap-3">
                  {lengthOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => setPlankLength(option.value)}
                      className={`text-center p-3 rounded-xl border-2 transition-all ${
                        plankLength === option.value
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-neutral-300'
                      }`}
                    >
                      <p className="text-neutral-900 mb-1">{option.label}</p>
                      <p className="text-xs text-neutral-600">{option.description}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Surface Texture */}
            <div className="bg-white rounded-2xl p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-neutral-900 mb-2">Surface Texture</h2>
                  <p className="text-sm text-neutral-600">
                    Texture adds realism and helps hide minor scratches and wear.
                  </p>
                </div>
                <button
                  onClick={() => setShowEducation('surface-texture')}
                  className="flex items-center gap-1 text-blue-600 hover:text-blue-700 text-sm transition-colors flex-shrink-0 ml-4"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Learn More
                </button>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                {textureOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setTexture(option.value)}
                    className={`relative text-left rounded-xl border-2 overflow-hidden transition-all ${
                      texture === option.value
                        ? 'border-amber-600'
                        : 'border-neutral-200 hover:border-neutral-300'
                    }`}
                  >
                    {option.recommended && (
                      <span className="absolute top-2 right-2 bg-green-600 text-white text-xs px-2 py-1 rounded-full z-10">
                        Popular
                      </span>
                    )}
                    <div className="aspect-video bg-neutral-200">
                      <img src={option.image} alt={option.label} className="w-full h-full object-cover" />
                    </div>
                    <div className="p-4">
                      <h3 className="text-neutral-900 mb-1">{option.label}</h3>
                      <p className="text-sm text-neutral-600">{option.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Color */}
            <div className="bg-white rounded-2xl p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-neutral-900 mb-2">Color Tone</h2>
                  <p className="text-sm text-neutral-600">
                    Choose a color that complements your room's decor.
                  </p>
                </div>
                <button
                  onClick={() => setShowEducation('color-tone')}
                  className="flex items-center gap-1 text-blue-600 hover:text-blue-700 text-sm transition-colors flex-shrink-0 ml-4"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Learn More
                </button>
              </div>
              <div className="grid sm:grid-cols-3 gap-3">
                {colorOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setColor(option.value)}
                    className={`relative text-center p-4 rounded-xl border-2 transition-all ${
                      color === option.value
                        ? 'border-amber-600 bg-amber-50'
                        : 'border-neutral-200 hover:border-neutral-300'
                    }`}
                  >
                    {option.recommended && (
                      <span className="absolute -top-2 right-2 bg-green-600 text-white text-xs px-2 py-1 rounded-full">
                        Popular
                      </span>
                    )}
                    <div
                      className="w-full h-16 rounded-lg mb-2 border border-neutral-300"
                      style={{ backgroundColor: option.hex }}
                    />
                    <h3 className="text-neutral-900 mb-1">{option.label}</h3>
                    <p className="text-xs text-neutral-600">{option.description}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Finish */}
            <div className="bg-white rounded-2xl p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-neutral-900 mb-2">Surface Finish</h2>
                  <p className="text-sm text-neutral-600">
                    Finish affects the look and feel of the surface.
                  </p>
                </div>
                <button
                  onClick={() => setShowEducation('surface-finish')}
                  className="flex items-center gap-1 text-blue-600 hover:text-blue-700 text-sm transition-colors flex-shrink-0 ml-4"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Learn More
                </button>
              </div>
              <div className="grid sm:grid-cols-3 gap-4">
                {finishOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setFinish(option.value)}
                    className={`relative text-center p-4 rounded-xl border-2 transition-all ${
                      finish === option.value
                        ? 'border-amber-600 bg-amber-50'
                        : 'border-neutral-200 hover:border-neutral-300'
                    }`}
                  >
                    {option.recommended && (
                      <span className="absolute -top-2 right-2 bg-green-600 text-white text-xs px-2 py-1 rounded-full">
                        Popular
                      </span>
                    )}
                    <h3 className="text-neutral-900 mb-1">{option.label}</h3>
                    <p className="text-sm text-neutral-600">{option.description}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Core/Backing */}
            <div className="bg-white rounded-2xl p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-neutral-900 mb-2">Core Construction</h2>
                  <p className="text-sm text-neutral-600">
                    The core affects stability, water resistance, and ease of installation.
                  </p>
                </div>
                <button
                  onClick={() => setShowEducation('core-construction')}
                  className="flex items-center gap-1 text-blue-600 hover:text-blue-700 text-sm transition-colors flex-shrink-0 ml-4"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Learn More
                </button>
              </div>
              <div className="space-y-3">
                {backingOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setBacking(option.value)}
                    className={`relative w-full text-left p-4 rounded-xl border-2 transition-all ${
                      backing === option.value
                        ? 'border-amber-600 bg-amber-50'
                        : 'border-neutral-200 hover:border-neutral-300'
                    }`}
                  >
                    {option.recommended && (
                      <span className="absolute top-4 right-4 bg-green-600 text-white text-xs px-2 py-1 rounded-full">
                        Recommended
                      </span>
                    )}
                    <h3 className="text-neutral-900 mb-1">{option.label}</h3>
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-neutral-600">{option.description}</p>
                      {option.price > 0 && (
                        <span className="text-amber-600">+${option.price}/sq ft</span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Installation Method */}
            <div className="bg-white rounded-2xl p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-neutral-900 mb-2">Installation Method</h2>
                  <p className="text-sm text-neutral-600">
                    Choose the installation method that best suits your needs.
                  </p>
                </div>
                <button
                  onClick={() => setShowEducation('installation-method')}
                  className="flex items-center gap-1 text-blue-600 hover:text-blue-700 text-sm transition-colors flex-shrink-0 ml-4"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Learn More
                </button>
              </div>
              <div className="space-y-3">
                {installationOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setInstallation(option.value)}
                    className={`relative w-full text-left p-4 rounded-xl border-2 transition-all ${
                      installation === option.value
                        ? 'border-amber-600 bg-amber-50'
                        : 'border-neutral-200 hover:border-neutral-300'
                    }`}
                  >
                    {option.recommended && (
                      <span className="absolute top-4 right-4 bg-green-600 text-white text-xs px-2 py-1 rounded-full">
                        Most Common
                      </span>
                    )}
                    <h3 className="text-neutral-900 mb-1">{option.label}</h3>
                    <p className="text-sm text-neutral-600">{option.description}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Attached Underpad */}
            <div className="bg-white rounded-2xl p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h2 className="text-neutral-900 mb-2">Attached Underpad</h2>
                  <p className="text-sm text-neutral-600">
                    Pre-attached underpad provides cushioning, sound dampening, and easier installation.
                  </p>
                </div>
                <button
                  onClick={() => setUnderpadIncluded(!underpadIncluded)}
                  className={`relative w-14 h-7 rounded-full transition-colors ${
                    underpadIncluded ? 'bg-green-600' : 'bg-neutral-300'
                  }`}
                >
                  <div
                    className={`absolute top-0.5 w-6 h-6 bg-white rounded-full transition-transform ${
                      underpadIncluded ? 'translate-x-7' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>

          {/* Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-8 bg-white rounded-2xl p-6 shadow-lg">
              <h2 className="text-neutral-900 mb-4">Configuration Summary</h2>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-600">Wear Layer:</span>
                  <span className="text-neutral-900">{wearLayer}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-600">Thickness:</span>
                  <span className="text-neutral-900">{thickness}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-600">Dimensions:</span>
                  <span className="text-neutral-900">{plankWidth} × {plankLength}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-600">Texture:</span>
                  <span className="text-neutral-900 capitalize">{texture.replace('-', ' ')}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-600">Color:</span>
                  <span className="text-neutral-900 capitalize">{color.replace('-', ' ')}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-600">Finish:</span>
                  <span className="text-neutral-900 capitalize">{finish}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-600">Core:</span>
                  <span className="text-neutral-900 capitalize">{backing.replace('-', ' ')}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-600">Installation:</span>
                  <span className="text-neutral-900 capitalize">{installation.replace('-', ' ')}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-600">Underpad:</span>
                  <span className="text-neutral-900">{underpadIncluded ? 'Included' : 'Separate'}</span>
                </div>
              </div>

              <div className="border-t border-neutral-200 pt-4 mb-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-neutral-600">Material Cost:</span>
                  <span className="text-neutral-900">${calculatePrice()}/sq ft</span>
                </div>
                <div className="flex justify-between items-center text-sm text-neutral-500">
                  <span>Installation:</span>
                  <span>~$2-4/sq ft</span>
                </div>
              </div>

              <button
                onClick={handleComplete}
                className="w-full bg-amber-600 text-white py-3 rounded-xl hover:bg-amber-700 transition-colors"
              >
                Continue to Summary
              </button>

              {/* Benefits */}
              <div className="mt-6 pt-6 border-t border-neutral-200">
                <h3 className="text-sm text-neutral-900 mb-3">Your Configuration Includes:</h3>
                <ul className="space-y-2 text-sm text-neutral-600">
                  <li className="flex items-start gap-2">
                    <svg className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    100% waterproof protection
                  </li>
                  <li className="flex items-start gap-2">
                    <svg className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    Scratch & stain resistant surface
                  </li>
                  <li className="flex items-start gap-2">
                    <svg className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    Pet & kid-friendly durability
                  </li>
                  <li className="flex items-start gap-2">
                    <svg className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    Easy maintenance & cleaning
                  </li>
                  <li className="flex items-start gap-2">
                    <svg className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    {wearLayerOptions.find(o => o.value === wearLayer)?.warranty} manufacturer warranty
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}