import { useState, useRef, useEffect } from 'react';
import { FloorProject } from '../../data/floorProjects';
import { Camera, Upload, X, Share2, RotateCcw } from 'lucide-react';

interface FloorVisualizerProps {
  project: FloorProject;
  onSave: (project: FloorProject) => void;
  onNext: () => void;
}

// Flooring texture library with real images
const flooringTextures = {
  hardwood: {
    'White Oak': 'https://images.unsplash.com/photo-1686056040167-1e3dead46d9a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aGl0ZSUyMG9hayUyMGZsb29yfGVufDF8fHx8MTc2NjI1NzYzN3ww&ixlib=rb-4.1.0&q=80&w=1080',
    'Red Oak': 'https://images.unsplash.com/photo-1711915442858-2a5bb7ba67d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvYWslMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjI1NzYzN3ww&ixlib=rb-4.1.0&q=80&w=1080',
    'Maple': 'https://images.unsplash.com/photo-1688274165311-15de2165d686?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXBsZSUyMHdvb2QlMjBmbG9vcnxlbnwxfHx8fDE3NjYyNTc2Mzd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    'Walnut': 'https://images.unsplash.com/photo-1642935264339-694e0fb27b0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YWxudXQlMjBoYXJkd29vZCUyMGZsb29yaW5nfGVufDF8fHx8MTc2NjI1NzYzN3ww&ixlib=rb-4.1.0&q=80&w=1080',
    'Cherry': 'https://images.unsplash.com/photo-1673924968581-c18b53d64e22?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVycnklMjB3b29kJTIwZmxvb3Jpbmd8ZW58MXx8fHwxNzY2MjU3NjM4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'Brazilian Cherry': 'https://images.unsplash.com/photo-1673924968581-c18b53d64e22?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVycnklMjB3b29kJTIwZmxvb3Jpbmd8ZW58MXx8fHwxNzY2MjU3NjM4fDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  carpet: {
    'Gray': 'https://images.unsplash.com/photo-1594922234613-4fc080e54b6d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmF5JTIwY2FycGV0JTIwdGV4dHVyZXxlbnwxfHx8fDE3NjYyNTc2Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    'Beige': 'https://images.unsplash.com/photo-1560448204-603b3fc33ddc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWlnZSUyMGNhcnBldCUyMGZsb29yfGVufDF8fHx8MTc2NjI1NzYzOHww&ixlib=rb-4.1.0&q=80&w=1080',
    'Soft Beige': 'https://images.unsplash.com/photo-1560448204-603b3fc33ddc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWlnZSUyMGNhcnBldCUyMGZsb29yfGVufDF8fHx8MTc2NjI1NzYzOHww&ixlib=rb-4.1.0&q=80&w=1080',
  },
  tile: {
    'Porcelain': 'https://images.unsplash.com/photo-1642678751244-296d18c4cab3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3JjZWxhaW4lMjB0aWxlJTIwZmxvb3J8ZW58MXx8fHwxNzY2MjU3NjM5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'Marble': 'https://images.unsplash.com/photo-1693773511442-8f2787a2c89e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJibGUlMjB0aWxlJTIwZmxvb3Jpbmd8ZW58MXx8fHwxNzY2MjQ1MTEzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    'Ceramic': 'https://images.unsplash.com/photo-1642678751244-296d18c4cab3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3JjZWxhaW4lMjB0aWxlJTIwZmxvb3J8ZW58MXx8fHwxNzY2MjU3NjM5fDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  lvp: {
    'default': 'https://images.unsplash.com/photo-1678799021566-2e2a748e9dd6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB2aW55bCUyMHBsYW5rfGVufDF8fHx8MTc2NjI1NzYzOXww&ixlib=rb-4.1.0&q=80&w=1080',
  },
  epoxy: {
    'default': 'https://images.unsplash.com/photo-1564041531732-d8cac2097910?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlcG94eSUyMGdhcmFnZSUyMGZsb29yfGVufDF8fHx8MTc2NjIxMzIzOHww&ixlib=rb-4.1.0&q=80&w=1080',
  }
};

// Available options for filtering
const hardwoodSpecies = ['White Oak', 'Red Oak', 'Maple', 'Walnut', 'Cherry', 'Brazilian Cherry', 'Hickory', 'Ash'];
const hardwoodColors = ['Natural', 'Light', 'Medium', 'Dark', 'Gray', 'White Wash', 'Ebony'];
const hardwoodFinishes = ['Matte', 'Semi-Gloss', 'Gloss', 'Oil-Rubbed', 'Hand-Scraped'];
const carpetColors = ['Beige', 'Gray', 'Soft Beige', 'Charcoal', 'Cream', 'Brown', 'Taupe'];
const carpetStyles = ['Plush', 'Berber', 'Frieze', 'Saxony', 'Textured', 'Cut Pile'];
const tileMaterials = ['Porcelain', 'Ceramic', 'Marble', 'Travertine', 'Slate', 'Granite'];
const tileColors = ['White', 'Light Gray', 'Dark Gray', 'Beige', 'Black', 'Blue', 'Green'];
const tilePatterns = ['Straight', 'Herringbone', 'Diagonal', 'Basketweave', 'Chevron', 'Brick'];

export function FloorVisualizer({ project, onSave, onNext }: FloorVisualizerProps) {
  const [uploadedImage, setUploadedImage] = useState<string | null>(project.roomPhoto || null);
  const [showFloorOverlay, setShowFloorOverlay] = useState(false);
  const [overlayOpacity, setOverlayOpacity] = useState(0.85);
  const [overlayPosition, setOverlayPosition] = useState({ x: 50, y: 70 });
  const [overlaySize, setOverlaySize] = useState({ width: 85, height: 45 });
  const [captureMode, setCaptureMode] = useState<'upload' | 'camera'>('upload');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [showShareModal, setShowShareModal] = useState(false);
  
  // Filter states
  const [selectedSpecies, setSelectedSpecies] = useState(project.hardwood?.species || 'White Oak');
  const [selectedColor, setSelectedColor] = useState(project.hardwood?.color || project.carpet?.color || project.tile?.color || 'Natural');
  const [selectedFinish, setSelectedFinish] = useState(project.hardwood?.finish || 'Matte');
  const [selectedStyle, setSelectedStyle] = useState(project.carpet?.style || 'Plush');
  const [selectedMaterial, setSelectedMaterial] = useState(project.tile?.material || 'Porcelain');
  const [selectedPattern, setSelectedPattern] = useState(project.tile?.pattern || 'Straight');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Start camera
  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } // Use back camera on mobile
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setCaptureMode('camera');
    } catch (err) {
      console.error('Error accessing camera:', err);
      alert('Unable to access camera. Please upload a photo instead.');
    }
  };

  // Stop camera
  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setCaptureMode('upload');
  };

  // Capture photo from camera
  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        const imageData = canvas.toDataURL('image/jpeg');
        setUploadedImage(imageData);
        stopCamera();
      }
    }
  };

  // Cleanup camera on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
        setShowFloorOverlay(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const getFloorTexture = () => {
    // Get the appropriate texture based on flooring type and selection
    if (project.flooringType === 'hardwood') {
      const texture = flooringTextures.hardwood[selectedSpecies as keyof typeof flooringTextures.hardwood];
      return texture || flooringTextures.hardwood['White Oak'];
    } else if (project.flooringType === 'carpet') {
      const texture = flooringTextures.carpet[selectedColor as keyof typeof flooringTextures.carpet];
      return texture || flooringTextures.carpet['Beige'];
    } else if (project.flooringType === 'tile') {
      const texture = flooringTextures.tile[selectedMaterial as keyof typeof flooringTextures.tile];
      return texture || flooringTextures.tile['Porcelain'];
    } else if (project.flooringType === 'lvp') {
      return flooringTextures.lvp.default;
    } else if (project.flooringType === 'epoxy') {
      return flooringTextures.epoxy.default;
    }
    return flooringTextures.hardwood['White Oak'];
  };

  const handleSaveVisualization = () => {
    const updatedProject = {
      ...project,
      roomPhoto: uploadedImage || undefined,
      visualizedDesign: uploadedImage || undefined,
      status: 'visualizing' as const,
      updatedDate: new Date().toISOString().split('T')[0],
      // Update with selected options
      hardwood: project.flooringType === 'hardwood' ? {
        ...project.hardwood!,
        species: selectedSpecies,
        color: selectedColor,
        finish: selectedFinish
      } : project.hardwood,
      carpet: project.flooringType === 'carpet' ? {
        ...project.carpet!,
        style: selectedStyle,
        color: selectedColor
      } : project.carpet,
      tile: project.flooringType === 'tile' ? {
        ...project.tile!,
        material: selectedMaterial,
        color: selectedColor,
        pattern: selectedPattern
      } : project.tile
    };
    onSave(updatedProject);
  };

  const handleContinue = () => {
    handleSaveVisualization();
    onNext();
  };

  const handleShareToContractor = () => {
    handleSaveVisualization();
    setShowShareModal(true);
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-neutral-900 mb-2">Visualize Your Floor</h1>
          <p className="text-neutral-600">
            Capture or upload a photo of your room to see how your flooring will look
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 lg:gap-6">
          {/* Left Sidebar: Filters */}
          <div className="lg:col-span-1 order-2 lg:order-1">
            <div className="bg-white rounded-2xl shadow-sm p-4 lg:sticky lg:top-4">
              <h3 className="text-neutral-900 mb-4 flex items-center gap-2">
                <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                </svg>
                Flooring Options
              </h3>
              
              <div className="space-y-4 max-h-[calc(100vh-200px)] overflow-y-auto pr-2">
                {/* Hardwood Filters */}
                {project.flooringType === 'hardwood' && (
                  <>
                    <div>
                      <label className="text-sm text-neutral-700 mb-2 block">Species</label>
                      <select 
                        value={selectedSpecies}
                        onChange={(e) => setSelectedSpecies(e.target.value)}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                      >
                        {hardwoodSpecies.map(species => (
                          <option key={species} value={species}>{species}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-sm text-neutral-700 mb-2 block">Color</label>
                      <select 
                        value={selectedColor}
                        onChange={(e) => setSelectedColor(e.target.value)}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                      >
                        {hardwoodColors.map(color => (
                          <option key={color} value={color}>{color}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-sm text-neutral-700 mb-2 block">Finish</label>
                      <select 
                        value={selectedFinish}
                        onChange={(e) => setSelectedFinish(e.target.value)}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                      >
                        {hardwoodFinishes.map(finish => (
                          <option key={finish} value={finish}>{finish}</option>
                        ))}
                      </select>
                    </div>
                  </>
                )}

                {/* Carpet Filters */}
                {project.flooringType === 'carpet' && (
                  <>
                    <div>
                      <label className="text-sm text-neutral-700 mb-2 block">Style</label>
                      <select 
                        value={selectedStyle}
                        onChange={(e) => setSelectedStyle(e.target.value)}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                      >
                        {carpetStyles.map(style => (
                          <option key={style} value={style}>{style}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-sm text-neutral-700 mb-2 block">Color</label>
                      <select 
                        value={selectedColor}
                        onChange={(e) => setSelectedColor(e.target.value)}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                      >
                        {carpetColors.map(color => (
                          <option key={color} value={color}>{color}</option>
                        ))}
                      </select>
                    </div>
                  </>
                )}

                {/* Tile Filters */}
                {project.flooringType === 'tile' && (
                  <>
                    <div>
                      <label className="text-sm text-neutral-700 mb-2 block">Material</label>
                      <select 
                        value={selectedMaterial}
                        onChange={(e) => setSelectedMaterial(e.target.value)}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                      >
                        {tileMaterials.map(material => (
                          <option key={material} value={material}>{material}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-sm text-neutral-700 mb-2 block">Color</label>
                      <select 
                        value={selectedColor}
                        onChange={(e) => setSelectedColor(e.target.value)}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                      >
                        {tileColors.map(color => (
                          <option key={color} value={color}>{color}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-sm text-neutral-700 mb-2 block">Pattern</label>
                      <select 
                        value={selectedPattern}
                        onChange={(e) => setSelectedPattern(e.target.value)}
                        className="w-full border border-neutral-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                      >
                        {tilePatterns.map(pattern => (
                          <option key={pattern} value={pattern}>{pattern}</option>
                        ))}
                      </select>
                    </div>
                  </>
                )}

                {/* LVP and Epoxy info */}
                {(project.flooringType === 'lvp' || project.flooringType === 'epoxy') && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                    <p className="text-sm text-blue-900">
                      {project.flooringType === 'lvp' 
                        ? 'Luxury Vinyl Plank offers realistic wood appearance with waterproof protection.'
                        : 'Epoxy flooring provides a durable, seamless finish perfect for garages and industrial spaces.'}
                    </p>
                  </div>
                )}

                {/* Overlay Controls */}
                {uploadedImage && (
                  <div className="pt-4 border-t border-neutral-200 space-y-4">
                    <div>
                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={showFloorOverlay}
                          onChange={(e) => setShowFloorOverlay(e.target.checked)}
                          className="w-5 h-5 text-amber-600 rounded"
                        />
                        <span className="text-sm text-neutral-900">Show Floor Preview</span>
                      </label>
                    </div>

                    {showFloorOverlay && (
                      <div>
                        <label className="text-sm text-neutral-700 mb-2 block">
                          Opacity: {Math.round(overlayOpacity * 100)}%
                        </label>
                        <input
                          type="range"
                          min="0"
                          max="1"
                          step="0.05"
                          value={overlayOpacity}
                          onChange={(e) => setOverlayOpacity(parseFloat(e.target.value))}
                          className="w-full"
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Center: Main Visualizer */}
          <div className="lg:col-span-2 order-1 lg:order-2">
            <div className="bg-white rounded-2xl shadow-sm p-4 sm:p-6">
              {!uploadedImage ? (
                <div>
                  {/* Camera/Upload Toggle */}
                  <div className="flex gap-2 mb-6">
                    <button
                      onClick={() => {
                        if (captureMode === 'camera') {
                          stopCamera();
                        } else {
                          fileInputRef.current?.click();
                        }
                      }}
                      className={`flex-1 py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all ${
                        captureMode === 'upload'
                          ? 'bg-amber-600 text-white'
                          : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                      }`}
                    >
                      <Upload className="w-5 h-5" />
                      Upload Photo
                    </button>
                    <button
                      onClick={captureMode === 'camera' ? stopCamera : startCamera}
                      className={`flex-1 py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all ${
                        captureMode === 'camera'
                          ? 'bg-amber-600 text-white'
                          : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                      }`}
                    >
                      <Camera className="w-5 h-5" />
                      Use Camera
                    </button>
                  </div>

                  {/* Camera View */}
                  {captureMode === 'camera' && stream ? (
                    <div className="space-y-4">
                      <div className="relative rounded-xl overflow-hidden bg-neutral-900">
                        <video
                          ref={videoRef}
                          autoPlay
                          playsInline
                          className="w-full h-auto"
                        />
                      </div>
                      <button
                        onClick={capturePhoto}
                        className="w-full bg-amber-600 text-white py-4 rounded-xl hover:bg-amber-700 transition-colors flex items-center justify-center gap-2"
                      >
                        <Camera className="w-5 h-5" />
                        Capture Photo
                      </button>
                    </div>
                  ) : captureMode === 'upload' ? (
                    <div className="text-center py-12">
                      <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6">
                        <Upload className="w-10 h-10 text-amber-600" />
                      </div>
                      <h3 className="text-neutral-900 mb-2">Upload Room Photo</h3>
                      <p className="text-neutral-600 mb-6">
                        Choose a photo showing your floor area
                      </p>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="bg-amber-600 text-white px-6 py-3 rounded-xl hover:bg-amber-700 transition-colors"
                      >
                        Choose Photo
                      </button>
                      <p className="text-sm text-neutral-500 mt-4">
                        Tip: Take photo from the doorway showing the floor area
                      </p>
                    </div>
                  ) : null}
                </div>
              ) : (
                <div>
                  <div className="mb-4 flex items-center justify-between flex-wrap gap-2">
                    <h3 className="text-neutral-900">Room Preview</h3>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setUploadedImage(null);
                          setShowFloorOverlay(false);
                        }}
                        className="text-neutral-600 hover:text-neutral-900 text-sm flex items-center gap-1 px-3 py-1.5 rounded-lg hover:bg-neutral-100"
                      >
                        <RotateCcw className="w-4 h-4" />
                        Change Photo
                      </button>
                    </div>
                  </div>

                  {/* Image Preview with Floor Overlay */}
                  <div className="relative rounded-xl overflow-hidden bg-neutral-900 mb-6">
                    <img
                      src={uploadedImage}
                      alt="Room"
                      className="w-full h-auto"
                    />
                    {showFloorOverlay && (
                      <div
                        className="absolute transition-opacity duration-300 pointer-events-none"
                        style={{
                          left: `${overlayPosition.x}%`,
                          top: `${overlayPosition.y}%`,
                          width: `${overlaySize.width}%`,
                          height: `${overlaySize.height}%`,
                          transform: 'translate(-50%, -50%) perspective(600px) rotateX(65deg)',
                          backgroundImage: `url(${getFloorTexture()})`,
                          backgroundSize: 'cover',
                          backgroundPosition: 'center',
                          opacity: overlayOpacity,
                          border: '2px dashed rgba(251, 191, 36, 0.6)',
                          boxShadow: '0 20px 60px rgba(0,0,0,0.4)',
                          mixBlendMode: 'multiply'
                        }}
                      />
                    )}
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                    <div className="flex items-start gap-3">
                      <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <p className="text-sm text-blue-900">
                        This is a preview visualization. Actual appearance may vary based on lighting, room layout, and installation. Use the filters on the left to customize your flooring.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Sidebar: Project Info & Actions */}
          <div className="lg:col-span-1 order-3">
            <div className="space-y-4">
              {/* Project Summary */}
              <div className="bg-white rounded-2xl shadow-sm p-4">
                <h3 className="text-neutral-900 mb-4">Your Selection</h3>
                <div className="space-y-3">
                  <div className="pb-3 border-b border-neutral-200">
                    <p className="text-xs text-neutral-600 mb-1">Room</p>
                    <p className="text-sm text-neutral-900">{project.roomType}</p>
                  </div>
                  <div className="pb-3 border-b border-neutral-200">
                    <p className="text-xs text-neutral-600 mb-1">Flooring</p>
                    <p className="text-sm text-neutral-900 capitalize">{project.flooringType}</p>
                  </div>
                  <div className="pb-3 border-b border-neutral-200">
                    <p className="text-xs text-neutral-600 mb-1">Size</p>
                    <p className="text-sm text-neutral-900">{project.squareFootage || 'Not specified'} sq ft</p>
                  </div>

                  {/* Current Specifications */}
                  {project.flooringType === 'hardwood' && (
                    <>
                      <div className="pb-3 border-b border-neutral-200">
                        <p className="text-xs text-neutral-600 mb-1">Species</p>
                        <p className="text-sm text-neutral-900">{selectedSpecies}</p>
                      </div>
                      <div className="pb-3 border-b border-neutral-200">
                        <p className="text-xs text-neutral-600 mb-1">Color</p>
                        <p className="text-sm text-neutral-900">{selectedColor}</p>
                      </div>
                      <div>
                        <p className="text-xs text-neutral-600 mb-1">Finish</p>
                        <p className="text-sm text-neutral-900">{selectedFinish}</p>
                      </div>
                    </>
                  )}
                  {project.flooringType === 'carpet' && (
                    <>
                      <div className="pb-3 border-b border-neutral-200">
                        <p className="text-xs text-neutral-600 mb-1">Style</p>
                        <p className="text-sm text-neutral-900">{selectedStyle}</p>
                      </div>
                      <div>
                        <p className="text-xs text-neutral-600 mb-1">Color</p>
                        <p className="text-sm text-neutral-900">{selectedColor}</p>
                      </div>
                    </>
                  )}
                  {project.flooringType === 'tile' && (
                    <>
                      <div className="pb-3 border-b border-neutral-200">
                        <p className="text-xs text-neutral-600 mb-1">Material</p>
                        <p className="text-sm text-neutral-900">{selectedMaterial}</p>
                      </div>
                      <div className="pb-3 border-b border-neutral-200">
                        <p className="text-xs text-neutral-600 mb-1">Color</p>
                        <p className="text-sm text-neutral-900">{selectedColor}</p>
                      </div>
                      <div>
                        <p className="text-xs text-neutral-600 mb-1">Pattern</p>
                        <p className="text-sm text-neutral-900">{selectedPattern}</p>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="bg-white rounded-2xl shadow-sm p-4">
                <h3 className="text-neutral-900 mb-4">Next Steps</h3>
                <div className="space-y-2">
                  <button
                    onClick={handleSaveVisualization}
                    disabled={!uploadedImage}
                    className="w-full bg-neutral-100 text-neutral-900 py-3 rounded-xl hover:bg-neutral-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
                    </svg>
                    Save Design
                  </button>
                  <button
                    onClick={handleShareToContractor}
                    disabled={!uploadedImage}
                    className="w-full bg-green-600 text-white py-3 rounded-xl hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm"
                  >
                    <Share2 className="w-4 h-4" />
                    Share to Contractor
                  </button>
                  <button
                    onClick={handleContinue}
                    disabled={!uploadedImage}
                    className="w-full bg-amber-600 text-white py-3 rounded-xl hover:bg-amber-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm"
                  >
                    Find Contractors
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Tips */}
              <div className="bg-white rounded-2xl shadow-sm p-4">
                <h3 className="text-neutral-900 mb-3">Tips</h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-amber-600 text-xs">1</span>
                    </div>
                    <p className="text-xs text-neutral-700">Take photo from doorway</p>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-amber-600 text-xs">2</span>
                    </div>
                    <p className="text-xs text-neutral-700">Ensure good lighting</p>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-amber-600 text-xs">3</span>
                    </div>
                    <p className="text-xs text-neutral-700">Show the floor area clearly</p>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-amber-600 text-xs">4</span>
                    </div>
                    <p className="text-xs text-neutral-700">Use filters to customize</p>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Hidden canvas for camera capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-neutral-900">Share with Contractor</h3>
              <button
                onClick={() => setShowShareModal(false)}
                className="text-neutral-400 hover:text-neutral-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mb-6">
              <p className="text-neutral-600 mb-4">
                Your visualization has been saved. You can now share it with contractors to get quotes.
              </p>
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-sm text-green-900">
                  ✓ Design saved successfully
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowShareModal(false)}
                className="flex-1 bg-neutral-100 text-neutral-900 py-3 rounded-xl hover:bg-neutral-200 transition-colors"
              >
                Close
              </button>
              <button
                onClick={handleContinue}
                className="flex-1 bg-amber-600 text-white py-3 rounded-xl hover:bg-amber-700 transition-colors"
              >
                Find Contractors
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}