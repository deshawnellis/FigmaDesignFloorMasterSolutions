import { useState } from 'react';
import { carpetStyles, fiberTypes } from '../../data/carpetStyles';

interface CarpetCustomizerProps {
  styleId: string;
  onBack: () => void;
  onComplete: (configuration: CarpetConfiguration) => void;
}

export interface CarpetConfiguration {
  styleId: string;
  fiberType: string;
  pileHeight: string;
  colorFamily: string;
  specificColor: string;
  pattern: string;
  backing: string;
  padding: string;
  width: string;
}

const pileHeights = [
  { id: 'low', label: 'Low Pile (1/4" - 1/2")', description: 'Easy to clean, commercial look' },
  { id: 'medium', label: 'Medium Pile (1/2" - 3/4")', description: 'Balance of comfort and practicality' },
  { id: 'high', label: 'High Pile (3/4" - 1")', description: 'Plush, luxurious feel' },
  { id: 'ultra', label: 'Ultra/Shag (1"+)', description: 'Maximum softness and comfort' }
];

const colorFamilies = [
  { id: 'neutral', label: 'Neutrals', colors: ['Ivory', 'Cream', 'Beige', 'Tan', 'Taupe', 'Gray', 'Charcoal'] },
  { id: 'warm', label: 'Warm Tones', colors: ['Wheat', 'Caramel', 'Honey', 'Rust', 'Terracotta', 'Cinnamon'] },
  { id: 'cool', label: 'Cool Tones', colors: ['Silver', 'Slate', 'Blue-Gray', 'Pewter', 'Graphite'] },
  { id: 'earth', label: 'Earth Tones', colors: ['Brown', 'Mocha', 'Coffee', 'Chocolate', 'Walnut', 'Espresso'] },
  { id: 'bold', label: 'Bold Colors', colors: ['Navy', 'Forest Green', 'Burgundy', 'Teal', 'Plum'] }
];

const patterns = [
  { id: 'solid', label: 'Solid Color', description: 'Single uniform color' },
  { id: 'textured', label: 'Textured/Heathered', description: 'Multiple shades blended' },
  { id: 'flecked', label: 'Flecked/Speckled', description: 'Small color variations throughout' },
  { id: 'striped', label: 'Striped', description: 'Linear pattern design' },
  { id: 'geometric', label: 'Geometric', description: 'Shapes and patterns' },
  { id: 'custom', label: 'Custom Pattern', description: 'Unique design or logo' }
];

const backingTypes = [
  { id: 'action-back', label: 'Action Back', description: 'Standard unattached backing' },
  { id: 'attached-pad', label: 'Attached Pad', description: 'Built-in cushion backing' },
  { id: 'double-stick', label: 'Double Stick', description: 'For direct glue-down' },
  { id: 'moisture-barrier', label: 'Moisture Barrier', description: 'Protection from spills' }
];

const paddingTypes = [
  { id: 'rebond', label: 'Rebond (Standard)', description: 'Most common, good value', density: '6-8 lbs' },
  { id: 'memory-foam', label: 'Memory Foam', description: 'Soft, conforms to feet', density: '3-5 lbs' },
  { id: 'frothed-foam', label: 'Frothed Foam', description: 'Firm support', density: '8-10 lbs' },
  { id: 'rubber', label: 'Rubber/Waffle', description: 'Maximum durability', density: '10-12 lbs' },
  { id: 'premium', label: 'Premium Dense', description: 'High-end performance', density: '12+ lbs' }
];

const carpetWidths = [
  { id: '12', label: '12 feet', description: 'Most common, fewer seams' },
  { id: '13.5', label: '13.5 feet', description: 'Wide rooms, minimal seams' },
  { id: '15', label: '15 feet', description: 'Extra wide, seamless install' }
];

export function CarpetCustomizer({ styleId, onBack, onComplete }: CarpetCustomizerProps) {
  const [step, setStep] = useState(1);
  const [fiberType, setFiberType] = useState('nylon');
  const [pileHeight, setPileHeight] = useState('medium');
  const [colorFamily, setColorFamily] = useState('neutral');
  const [specificColor, setSpecificColor] = useState('Beige');
  const [pattern, setPattern] = useState('solid');
  const [backing, setBacking] = useState('action-back');
  const [padding, setPadding] = useState('rebond');
  const [width, setWidth] = useState('12');

  const style = carpetStyles.find(s => s.id === styleId);
  const totalSteps = 5;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    }
  };

  const handlePrevious = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleComplete = () => {
    const configuration: CarpetConfiguration = {
      styleId,
      fiberType,
      pileHeight,
      colorFamily,
      specificColor,
      pattern,
      backing,
      padding,
      width
    };
    onComplete(configuration);
  };

  if (!style) {
    return null;
  }

  const selectedColorFamily = colorFamilies.find(cf => cf.id === colorFamily);

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-5xl mx-auto px-6 py-8 md:ml-64">
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Style Selection</span>
          </button>
          
          <h1 className="text-neutral-900 mb-2">Customize Your {style.name} Carpet</h1>
          <p className="text-neutral-600">
            Step {step} of {totalSteps}: Configure your perfect carpet
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            {['Fiber', 'Pile & Color', 'Pattern', 'Backing & Pad', 'Width'].map((label, idx) => (
              <div key={idx} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                  step > idx + 1 ? 'bg-amber-600 text-white' :
                  step === idx + 1 ? 'bg-amber-600 text-white' :
                  'bg-neutral-200 text-neutral-500'
                }`}>
                  {step > idx + 1 ? '✓' : idx + 1}
                </div>
                {idx < 4 && <div className={`w-12 h-1 mx-2 ${step > idx + 1 ? 'bg-amber-600' : 'bg-neutral-200'}`} />}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-8 mb-6">
          {/* Step 1: Fiber Type */}
          {step === 1 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Select Carpet Fiber</h2>
              <div className="space-y-4">
                {fiberTypes.map((fiber) => (
                  <button
                    key={fiber.id}
                    onClick={() => setFiberType(fiber.id)}
                    className={`w-full p-6 border-2 rounded-lg text-left transition-all ${
                      fiberType === fiber.id
                        ? 'border-amber-600 bg-amber-50'
                        : 'border-neutral-200 hover:border-amber-300'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="text-neutral-900 mb-1">{fiber.name}</h3>
                        <p className="text-neutral-600 text-sm">{fiber.description}</p>
                      </div>
                      {fiberType === fiber.id && (
                        <svg className="w-6 h-6 text-amber-600 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4 mt-4 text-sm">
                      <div>
                        <div className="text-neutral-500 mb-1">Durability</div>
                        <div className="flex items-center gap-1">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div
                              key={i}
                              className={`w-2 h-2 rounded-full ${
                                i < fiber.durability ? 'bg-amber-600' : 'bg-neutral-300'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <div>
                        <div className="text-neutral-500 mb-1">Stain Resist</div>
                        <div className="flex items-center gap-1">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div
                              key={i}
                              className={`w-2 h-2 rounded-full ${
                                i < fiber.stainResistance ? 'bg-blue-600' : 'bg-neutral-300'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <div>
                        <div className="text-neutral-500 mb-1">Softness</div>
                        <div className="flex items-center gap-1">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div
                              key={i}
                              className={`w-2 h-2 rounded-full ${
                                i < fiber.softness ? 'bg-purple-600' : 'bg-neutral-300'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-4 border-t border-neutral-200">
                      <div className="text-neutral-500 text-sm mb-2">Key Benefits:</div>
                      <div className="flex flex-wrap gap-2">
                        {fiber.characteristics.slice(0, 3).map((char, idx) => (
                          <span key={idx} className="px-2 py-1 bg-white border border-neutral-200 rounded text-xs text-neutral-600">
                            {char}
                          </span>
                        ))}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Pile Height & Color Family */}
          {step === 2 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Select Pile Height & Color</h2>
              
              <div className="mb-8">
                <h3 className="text-neutral-700 mb-4">Pile Height</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {pileHeights.map((height) => (
                    <button
                      key={height.id}
                      onClick={() => setPileHeight(height.id)}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        pileHeight === height.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900">{height.label}</span>
                        {pileHeight === height.id && (
                          <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-sm">{height.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-neutral-700 mb-4">Color Family</h3>
                <div className="space-y-3">
                  {colorFamilies.map((family) => (
                    <button
                      key={family.id}
                      onClick={() => {
                        setColorFamily(family.id);
                        setSpecificColor(family.colors[0]);
                      }}
                      className={`w-full p-4 border-2 rounded-lg text-left transition-all ${
                        colorFamily === family.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-neutral-900">{family.label}</span>
                        {colorFamily === family.id && (
                          <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {family.colors.map((color) => (
                          <span key={color} className="px-2 py-1 bg-white border border-neutral-200 rounded text-xs text-neutral-600">
                            {color}
                          </span>
                        ))}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Specific Color & Pattern */}
          {step === 3 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Choose Specific Color & Pattern</h2>
              
              <div className="mb-8">
                <h3 className="text-neutral-700 mb-4">Specific Color ({selectedColorFamily?.label})</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {selectedColorFamily?.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSpecificColor(color)}
                      className={`p-3 border-2 rounded-lg transition-all ${
                        specificColor === color
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-neutral-900 text-sm">{color}</span>
                        {specificColor === color && (
                          <svg className="w-4 h-4 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-neutral-700 mb-4">Pattern Style</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {patterns.map((pat) => (
                    <button
                      key={pat.id}
                      onClick={() => setPattern(pat.id)}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        pattern === pat.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900">{pat.label}</span>
                        {pattern === pat.id && (
                          <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-sm">{pat.description}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Backing & Padding */}
          {step === 4 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Select Backing & Padding</h2>
              
              <div className="mb-8">
                <h3 className="text-neutral-700 mb-4">Carpet Backing</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {backingTypes.map((back) => (
                    <button
                      key={back.id}
                      onClick={() => setBacking(back.id)}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        backing === back.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-neutral-900">{back.label}</span>
                        {backing === back.id && (
                          <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <p className="text-neutral-600 text-sm">{back.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-neutral-700 mb-4">Carpet Padding</h3>
                <div className="space-y-3">
                  {paddingTypes.map((pad) => (
                    <button
                      key={pad.id}
                      onClick={() => setPadding(pad.id)}
                      className={`w-full p-4 border-2 rounded-lg text-left transition-all ${
                        padding === pad.id
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-3 mb-1">
                            <span className="text-neutral-900">{pad.label}</span>
                            <span className="text-xs text-neutral-500 bg-neutral-100 px-2 py-0.5 rounded">
                              {pad.density}
                            </span>
                          </div>
                          <p className="text-neutral-600 text-sm">{pad.description}</p>
                        </div>
                        {padding === pad.id && (
                          <svg className="w-5 h-5 text-amber-600 flex-shrink-0 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 5: Carpet Width */}
          {step === 5 && (
            <div>
              <h2 className="text-neutral-900 mb-6">Select Carpet Width</h2>
              <div className="space-y-4">
                {carpetWidths.map((w) => (
                  <button
                    key={w.id}
                    onClick={() => setWidth(w.id)}
                    className={`w-full p-6 border-2 rounded-lg text-left transition-all ${
                      width === w.id
                        ? 'border-amber-600 bg-amber-50'
                        : 'border-neutral-200 hover:border-amber-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-neutral-900 mb-1">{w.label}</h3>
                        <p className="text-neutral-600 text-sm">{w.description}</p>
                      </div>
                      {width === w.id && (
                        <svg className="w-6 h-6 text-amber-600 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                  </button>
                ))}
              </div>

              <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex gap-3">
                  <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div>
                    <h4 className="text-neutral-900 text-sm mb-1">Carpet Width Note</h4>
                    <p className="text-neutral-600 text-sm">
                      Wider carpets mean fewer seams in your room. Your installer will help determine the best width based on your room dimensions.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={handlePrevious}
            disabled={step === 1}
            className={`px-6 py-3 border-2 border-neutral-300 rounded-lg transition-colors ${
              step === 1
                ? 'text-neutral-400 cursor-not-allowed'
                : 'text-neutral-700 hover:bg-neutral-50'
            }`}
          >
            Previous
          </button>

          {step < totalSteps ? (
            <button
              onClick={handleNext}
              className="px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
            >
              Next Step
            </button>
          ) : (
            <button
              onClick={handleComplete}
              className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              Complete Configuration
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
