import { useState } from 'react';
import { HomeownerLayout } from './HomeownerLayout';
import { HomeownerHome } from './HomeownerHome';
import { FlooringList } from './FlooringList';
import { FlooringDetail } from './FlooringDetail';
import { Visualizer } from './Visualizer';
import { AIChat } from './AIChat';
import { ContractorsList } from './ContractorsList';
import { ContractorProfile } from './ContractorProfile';
import { UserProfile } from './UserProfile';
import { HardwoodTypeSelection } from './HardwoodTypeSelection';
import { HardwoodProductBrowser } from './HardwoodProductBrowser';
import { HardwoodProductDetail } from './HardwoodProductDetail';
import { WoodSpeciesSelector } from './WoodSpeciesSelector';
import { ProductCustomizer, CustomConfiguration } from './ProductCustomizer';
import { ConfigurationSummary } from './ConfigurationSummary';
import { CarpetSelector } from './CarpetSelector';
import { CarpetCustomizer, CarpetConfiguration } from './CarpetCustomizer';
import { CarpetConfigurationSummary } from './CarpetConfigurationSummary';
import { TileSelector } from './TileSelector';
import { TileCustomizer, TileConfiguration } from './TileCustomizer';
import { TileConfigurationSummary } from './TileConfigurationSummary';
import { LVPSelector } from './LVPSelector';
import { LVPCustomizer, LVPConfiguration } from './LVPCustomizer';
import { LVPConfigurationSummary } from './LVPConfigurationSummary';
import { EpoxySelector } from './EpoxySelector';
import { EpoxyCustomizer, EpoxyConfiguration } from './EpoxyCustomizer';
import { EpoxyConfigurationSummary } from './EpoxyConfigurationSummary';
import { EngineeredWoodSelector } from './EngineeredWoodSelector';
import { EngineeredWoodCustomizer, EngineeredWoodConfiguration } from './EngineeredWoodCustomizer';
import { EngineeredWoodConfigurationSummary } from './EngineeredWoodConfigurationSummary';
import { MyProjects } from './MyProjects';
import { FloatingChat } from '../FloatingChat';

type Page = 'home' | 'flooring' | 'flooringDetail' | 'hardwoodTypes' | 'hardwoodProducts' | 'hardwoodProductDetail' | 'speciesSelector' | 'productCustomizer' | 'configurationSummary' | 'carpetSelector' | 'carpetCustomizer' | 'carpetConfigurationSummary' | 'tileSelector' | 'tileCustomizer' | 'tileConfigurationSummary' | 'lvpSelector' | 'lvpCustomizer' | 'lvpConfigurationSummary' | 'epoxySelector' | 'epoxyCustomizer' | 'epoxyConfigurationSummary' | 'engineeredSelector' | 'engineeredCustomizer' | 'engineeredConfigurationSummary' | 'visualizer' | 'chat' | 'contractors' | 'contractorProfile' | 'projects' | 'profile';

interface HomeownerDashboardProps {
  onLogout: () => void;
}

export function HomeownerDashboard({ onLogout }: HomeownerDashboardProps) {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedFlooringId, setSelectedFlooringId] = useState<string | null>(null);
  const [selectedContractorId, setSelectedContractorId] = useState<string | null>(null);
  const [selectedHardwoodType, setSelectedHardwoodType] = useState<string | null>(null);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedSpeciesId, setSelectedSpeciesId] = useState<string | null>(null);
  const [currentConfiguration, setCurrentConfiguration] = useState<CustomConfiguration | null>(null);
  const [selectedCarpetStyle, setSelectedCarpetStyle] = useState<string | null>(null);
  const [currentCarpetConfiguration, setCurrentCarpetConfiguration] = useState<CarpetConfiguration | null>(null);
  const [selectedTileMaterial, setSelectedTileMaterial] = useState<string | null>(null);
  const [currentTileConfiguration, setCurrentTileConfiguration] = useState<TileConfiguration | null>(null);
  const [selectedLVPStyle, setSelectedLVPStyle] = useState<string | null>(null);
  const [currentLVPConfiguration, setCurrentLVPConfiguration] = useState<LVPConfiguration | null>(null);
  const [selectedEpoxyStyle, setSelectedEpoxyStyle] = useState<string | null>(null);
  const [currentEpoxyConfiguration, setCurrentEpoxyConfiguration] = useState<EpoxyConfiguration | null>(null);
  const [selectedEngineeredStyle, setSelectedEngineeredStyle] = useState<string | null>(null);
  const [currentEngineeredConfiguration, setCurrentEngineeredConfiguration] = useState<EngineeredWoodConfiguration | null>(null);

  const handleNavigate = (page: 'home' | 'flooring' | 'visualizer' | 'chat' | 'contractors' | 'profile') => {
    setCurrentPage(page);
    setSelectedFlooringId(null);
    setSelectedContractorId(null);
    setSelectedHardwoodType(null);
    setSelectedProductId(null);
    setSelectedSpeciesId(null);
    setCurrentConfiguration(null);
    setSelectedCarpetStyle(null);
    setCurrentCarpetConfiguration(null);
    setSelectedTileMaterial(null);
    setCurrentTileConfiguration(null);
    setSelectedLVPStyle(null);
    setCurrentLVPConfiguration(null);
    setSelectedEpoxyStyle(null);
    setCurrentEpoxyConfiguration(null);
    setSelectedEngineeredStyle(null);
    setCurrentEngineeredConfiguration(null);
  };

  const handleSelectFlooring = (id: string) => {
    // Route to different customization flows based on flooring type
    if (id === 'hardwood') {
      setCurrentPage('hardwoodTypes');
    } else if (id === 'carpet') {
      setCurrentPage('carpetSelector');
    } else if (id === 'tile') {
      setCurrentPage('tileSelector');
    } else if (id === 'lvp') {
      setCurrentPage('lvpSelector');
    } else if (id === 'epoxy') {
      setCurrentPage('epoxySelector');
    } else if (id === 'engineered') {
      setCurrentPage('engineeredSelector');
    } else {
      setSelectedFlooringId(id);
      setCurrentPage('flooringDetail');
    }
  };

  const handleSelectHardwoodType = (typeId: string) => {
    setSelectedHardwoodType(typeId);
    setCurrentPage('speciesSelector');
  };

  const handleSelectSpecies = (speciesId: string) => {
    setSelectedSpeciesId(speciesId);
    setCurrentPage('productCustomizer');
  };

  const handleCompleteCustomization = (configuration: CustomConfiguration) => {
    setCurrentConfiguration(configuration);
    setCurrentPage('configurationSummary');
  };

  const handleEditConfiguration = () => {
    setCurrentPage('productCustomizer');
  };

  // Carpet handlers
  const handleSelectCarpetStyle = (styleId: string) => {
    setSelectedCarpetStyle(styleId);
    setCurrentPage('carpetCustomizer');
  };

  const handleCompleteCarpetCustomization = (configuration: CarpetConfiguration) => {
    setCurrentCarpetConfiguration(configuration);
    setCurrentPage('carpetConfigurationSummary');
  };

  const handleEditCarpetConfiguration = () => {
    setCurrentPage('carpetCustomizer');
  };

  // Tile handlers
  const handleSelectTileMaterial = (materialId: string) => {
    setSelectedTileMaterial(materialId);
    setCurrentPage('tileCustomizer');
  };

  const handleCompleteTileCustomization = (configuration: TileConfiguration) => {
    setCurrentTileConfiguration(configuration);
    setCurrentPage('tileConfigurationSummary');
  };

  const handleEditTileConfiguration = () => {
    setCurrentPage('tileCustomizer');
  };

  // LVP handlers
  const handleSelectLVPStyle = (styleId: string) => {
    setSelectedLVPStyle(styleId);
    setCurrentPage('lvpCustomizer');
  };

  const handleCompleteLVPCustomization = (configuration: LVPConfiguration) => {
    setCurrentLVPConfiguration(configuration);
    setCurrentPage('lvpConfigurationSummary');
  };

  const handleEditLVPCustomization = () => {
    setCurrentPage('lvpCustomizer');
  };

  // Epoxy handlers
  const handleSelectEpoxyStyle = (styleId: string) => {
    setSelectedEpoxyStyle(styleId);
    setCurrentPage('epoxyCustomizer');
  };

  const handleCompleteEpoxyCustomization = (configuration: EpoxyConfiguration) => {
    setCurrentEpoxyConfiguration(configuration);
    setCurrentPage('epoxyConfigurationSummary');
  };

  const handleEditEpoxyConfiguration = () => {
    setCurrentPage('epoxyCustomizer');
  };

  // Engineered Wood handlers
  const handleSelectEngineeredStyle = (styleId: string) => {
    setSelectedEngineeredStyle(styleId);
    setCurrentPage('engineeredCustomizer');
  };

  const handleCompleteEngineeredCustomization = (configuration: EngineeredWoodConfiguration) => {
    setCurrentEngineeredConfiguration(configuration);
    setCurrentPage('engineeredConfigurationSummary');
  };

  const handleEditEngineeredConfiguration = () => {
    setCurrentPage('engineeredCustomizer');
  };

  const handleRequestQuote = () => {
    setCurrentPage('contractors');
  };

  const handleSelectHardwoodProduct = (productId: string) => {
    setSelectedProductId(productId);
    setCurrentPage('hardwoodProductDetail');
  };

  const handleSelectContractor = (id: string) => {
    setSelectedContractorId(id);
    setCurrentPage('contractorProfile');
  };

  const handleBackFromDetail = () => {
    setCurrentPage('flooring');
    setSelectedFlooringId(null);
  };

  const handleBackFromHardwoodTypes = () => {
    setCurrentPage('flooring');
  };

  const handleBackFromSpeciesSelector = () => {
    setCurrentPage('hardwoodTypes');
  };

  const handleBackFromCustomizer = () => {
    setCurrentPage('speciesSelector');
    setSelectedSpeciesId(null);
  };

  const handleBackFromCarpetSelector = () => {
    setCurrentPage('flooring');
  };

  const handleBackFromCarpetCustomizer = () => {
    setCurrentPage('carpetSelector');
    setSelectedCarpetStyle(null);
  };

  const handleBackFromTileSelector = () => {
    setCurrentPage('flooring');
  };

  const handleBackFromTileCustomizer = () => {
    setCurrentPage('tileSelector');
    setSelectedTileMaterial(null);
  };

  const handleBackFromLVPSelector = () => {
    setCurrentPage('flooring');
  };

  const handleBackFromLVPCustomizer = () => {
    setCurrentPage('lvpSelector');
    setSelectedLVPStyle(null);
  };

  const handleBackFromEpoxySelector = () => {
    setCurrentPage('flooring');
  };

  const handleBackFromEpoxyCustomizer = () => {
    setCurrentPage('epoxySelector');
    setSelectedEpoxyStyle(null);
  };

  const handleBackFromEngineeredSelector = () => {
    setCurrentPage('flooring');
  };

  const handleBackFromEngineeredCustomizer = () => {
    setCurrentPage('engineeredSelector');
    setSelectedEngineeredStyle(null);
  };

  const handleBackFromHardwoodProducts = () => {
    setCurrentPage('hardwoodTypes');
  };

  const handleBackFromProductDetail = () => {
    setCurrentPage('hardwoodProducts');
    setSelectedProductId(null);
  };

  const handleBackFromContractorProfile = () => {
    setCurrentPage('contractors');
    setSelectedContractorId(null);
  };

  const renderContent = () => {
    switch (currentPage) {
      case 'home':
        return <HomeownerHome onNavigate={handleNavigate} onSelectFlooring={handleSelectFlooring} />;
      case 'flooring':
        return <FlooringList onSelectFlooring={handleSelectFlooring} />;
      case 'flooringDetail':
        return selectedFlooringId ? (
          <FlooringDetail flooringId={selectedFlooringId} onBack={handleBackFromDetail} />
        ) : null;
      case 'hardwoodTypes':
        return <HardwoodTypeSelection onSelectType={handleSelectHardwoodType} onBack={handleBackFromHardwoodTypes} />;
      case 'speciesSelector':
        return selectedHardwoodType ? (
          <WoodSpeciesSelector 
            hardwoodType={selectedHardwoodType}
            onSelectSpecies={handleSelectSpecies}
            onBack={handleBackFromSpeciesSelector}
          />
        ) : null;
      case 'productCustomizer':
        return selectedHardwoodType && selectedSpeciesId ? (
          <ProductCustomizer
            hardwoodType={selectedHardwoodType}
            speciesId={selectedSpeciesId}
            onBack={handleBackFromCustomizer}
            onComplete={handleCompleteCustomization}
          />
        ) : null;
      case 'configurationSummary':
        return currentConfiguration ? (
          <ConfigurationSummary
            configuration={currentConfiguration}
            onEdit={handleEditConfiguration}
            onRequestQuote={handleRequestQuote}
          />
        ) : null;
      case 'carpetSelector':
        return <CarpetSelector onSelectStyle={handleSelectCarpetStyle} onBack={handleBackFromCarpetSelector} />;
      case 'carpetCustomizer':
        return selectedCarpetStyle ? (
          <CarpetCustomizer
            styleId={selectedCarpetStyle}
            onBack={handleBackFromCarpetCustomizer}
            onComplete={handleCompleteCarpetCustomization}
          />
        ) : null;
      case 'carpetConfigurationSummary':
        return currentCarpetConfiguration ? (
          <CarpetConfigurationSummary
            configuration={currentCarpetConfiguration}
            onEdit={handleEditCarpetConfiguration}
            onRequestQuote={handleRequestQuote}
          />
        ) : null;
      case 'tileSelector':
        return <TileSelector onSelectMaterial={handleSelectTileMaterial} onBack={handleBackFromTileSelector} />;
      case 'tileCustomizer':
        return selectedTileMaterial ? (
          <TileCustomizer
            materialId={selectedTileMaterial}
            onBack={handleBackFromTileCustomizer}
            onComplete={handleCompleteTileCustomization}
          />
        ) : null;
      case 'tileConfigurationSummary':
        return currentTileConfiguration ? (
          <TileConfigurationSummary
            configuration={currentTileConfiguration}
            onEdit={handleEditTileConfiguration}
            onRequestQuote={handleRequestQuote}
          />
        ) : null;
      case 'lvpSelector':
        return <LVPSelector onSelectStyle={handleSelectLVPStyle} onBack={handleBackFromLVPSelector} />;
      case 'lvpCustomizer':
        return selectedLVPStyle ? (
          <LVPCustomizer
            styleId={selectedLVPStyle}
            onBack={handleBackFromLVPCustomizer}
            onComplete={handleCompleteLVPCustomization}
          />
        ) : null;
      case 'lvpConfigurationSummary':
        return currentLVPConfiguration ? (
          <LVPConfigurationSummary
            configuration={currentLVPConfiguration}
            onEdit={handleEditLVPCustomization}
            onRequestQuote={handleRequestQuote}
          />
        ) : null;
      case 'epoxySelector':
        return <EpoxySelector onSelectStyle={handleSelectEpoxyStyle} onBack={handleBackFromEpoxySelector} />;
      case 'epoxyCustomizer':
        return selectedEpoxyStyle ? (
          <EpoxyCustomizer
            styleId={selectedEpoxyStyle}
            onBack={handleBackFromEpoxyCustomizer}
            onComplete={handleCompleteEpoxyCustomization}
          />
        ) : null;
      case 'epoxyConfigurationSummary':
        return currentEpoxyConfiguration ? (
          <EpoxyConfigurationSummary
            configuration={currentEpoxyConfiguration}
            onEdit={handleEditEpoxyConfiguration}
            onRequestQuote={handleRequestQuote}
          />
        ) : null;
      case 'engineeredSelector':
        return <EngineeredWoodSelector onSelectStyle={handleSelectEngineeredStyle} onBack={handleBackFromEngineeredSelector} />;
      case 'engineeredCustomizer':
        return selectedEngineeredStyle ? (
          <EngineeredWoodCustomizer
            styleId={selectedEngineeredStyle}
            onBack={handleBackFromEngineeredCustomizer}
            onComplete={handleCompleteEngineeredCustomization}
          />
        ) : null;
      case 'engineeredConfigurationSummary':
        return currentEngineeredConfiguration ? (
          <EngineeredWoodConfigurationSummary
            configuration={currentEngineeredConfiguration}
            onEdit={handleEditEngineeredConfiguration}
            onRequestQuote={handleRequestQuote}
          />
        ) : null;
      case 'hardwoodProducts':
        return selectedHardwoodType ? (
          <HardwoodProductBrowser 
            hardwoodType={selectedHardwoodType} 
            onBack={handleBackFromHardwoodProducts}
            onSelectProduct={handleSelectHardwoodProduct}
          />
        ) : null;
      case 'hardwoodProductDetail':
        return selectedProductId ? (
          <HardwoodProductDetail 
            productId={selectedProductId}
            onBack={handleBackFromProductDetail}
          />
        ) : null;
      case 'visualizer':
        return <Visualizer />;
      case 'chat':
        return <AIChat userType="homeowner" />;
      case 'contractors':
        return <ContractorsList onSelectContractor={handleSelectContractor} />;
      case 'contractorProfile':
        return selectedContractorId ? (
          <ContractorProfile contractorId={selectedContractorId} onBack={handleBackFromContractorProfile} />
        ) : null;
      case 'projects':
        return <MyProjects />;
      case 'profile':
        return <UserProfile userType="homeowner" onLogout={onLogout} />;
      default:
        return <HomeownerHome onNavigate={handleNavigate} onSelectFlooring={handleSelectFlooring} />;
    }
  };

  const layoutPage = 
    currentPage === 'flooringDetail' || 
    currentPage === 'contractorProfile' || 
    currentPage === 'hardwoodTypes' || 
    currentPage === 'hardwoodProducts' || 
    currentPage === 'hardwoodProductDetail' ||
    currentPage === 'speciesSelector' ||
    currentPage === 'productCustomizer' ||
    currentPage === 'configurationSummary' ||
    currentPage === 'carpetSelector' ||
    currentPage === 'carpetCustomizer' ||
    currentPage === 'carpetConfigurationSummary' ||
    currentPage === 'tileSelector' ||
    currentPage === 'tileCustomizer' ||
    currentPage === 'tileConfigurationSummary' ||
    currentPage === 'lvpSelector' ||
    currentPage === 'lvpCustomizer' ||
    currentPage === 'lvpConfigurationSummary' ||
    currentPage === 'epoxySelector' ||
    currentPage === 'epoxyCustomizer' ||
    currentPage === 'epoxyConfigurationSummary' ||
    currentPage === 'engineeredSelector' ||
    currentPage === 'engineeredCustomizer' ||
    currentPage === 'engineeredConfigurationSummary'
      ? 'home' 
      : currentPage;

  return (
    <HomeownerLayout currentPage={layoutPage as any} onNavigate={handleNavigate}>
      {renderContent()}
      <FloatingChat userType="homeowner" />
    </HomeownerLayout>
  );
}