import { useState } from 'react';
import { flooringTypes } from '../../data/flooringTypes';

interface FlooringListProps {
  onSelectFlooring: (id: string) => void;
}

export function FlooringList({ onSelectFlooring }: FlooringListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMaintenance, setSelectedMaintenance] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'price' | 'durability'>('name');

  const filteredFlooring = flooringTypes
    .filter((flooring) => {
      const matchesSearch = flooring.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        flooring.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesMaintenance = selectedMaintenance === 'all' || flooring.maintenance === selectedMaintenance;
      return matchesSearch && matchesMaintenance;
    })
    .sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'durability') return b.durability - a.durability;
      return 0;
    });

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-neutral-900 mb-2">Explore Flooring Options</h1>
          <p className="text-neutral-600">
            Compare different flooring types to find the perfect fit for your home
          </p>
        </div>

        {/* Featured Options - LVP and Engineered Wood */}
        <div className="mb-8">
          <h2 className="text-neutral-900 mb-4 flex items-center gap-2">
            <svg className="w-6 h-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
            </svg>
            Most Popular Choices
          </h2>
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            {/* LVP Featured Card */}
            <button
              onClick={() => onSelectFlooring('lvp')}
              className="group relative bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl overflow-hidden text-left hover:shadow-xl transition-all"
            >
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
              <div className="relative p-8 text-white">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <span className="inline-block bg-white/20 text-white text-xs px-3 py-1 rounded-full mb-3">
                      #1 Most Popular
                    </span>
                    <h3 className="text-white text-2xl mb-2">Luxury Vinyl Plank (LVP)</h3>
                    <p className="text-blue-100 text-lg mb-4">
                      100% Waterproof • Pet-Friendly • Easy Install
                    </p>
                  </div>
                  <svg className="w-12 h-12 text-white/80" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
                    <p className="text-blue-100 text-xs mb-1">Durability</p>
                    <p className="text-white">★★★★★</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
                    <p className="text-blue-100 text-xs mb-1">Maintenance</p>
                    <p className="text-white">Very Low</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
                    <p className="text-blue-100 text-xs mb-1">Price Range</p>
                    <p className="text-white">$3-8/sqft</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-white">
                  <span>Start Customizing</span>
                  <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </div>
              </div>
            </button>

            {/* Engineered Wood Featured Card */}
            <button
              onClick={() => onSelectFlooring('hardwood')}
              className="group relative bg-gradient-to-br from-amber-600 to-amber-700 rounded-2xl overflow-hidden text-left hover:shadow-xl transition-all"
            >
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
              <div className="relative p-8 text-white">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <span className="inline-block bg-white/20 text-white text-xs px-3 py-1 rounded-full mb-3">
                      Premium Choice
                    </span>
                    <h3 className="text-white text-2xl mb-2">Engineered Hardwood</h3>
                    <p className="text-amber-100 text-lg mb-4">
                      Real Wood • Timeless Beauty • Adds Home Value
                    </p>
                  </div>
                  <svg className="w-12 h-12 text-white/80" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
                    <p className="text-amber-100 text-xs mb-1">Durability</p>
                    <p className="text-white">★★★★☆</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
                    <p className="text-amber-100 text-xs mb-1">Maintenance</p>
                    <p className="text-white">Medium</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
                    <p className="text-amber-100 text-xs mb-1">Price Range</p>
                    <p className="text-white">$8-15/sqft</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-white">
                  <span>Browse Wood Types</span>
                  <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Search */}
            <div>
              <label htmlFor="search" className="block text-neutral-700 mb-2 text-sm">
                Search
              </label>
              <input
                type="text"
                id="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search flooring types..."
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              />
            </div>

            {/* Maintenance Filter */}
            <div>
              <label htmlFor="maintenance" className="block text-neutral-700 mb-2 text-sm">
                Maintenance Level
              </label>
              <select
                id="maintenance"
                value={selectedMaintenance}
                onChange={(e) => setSelectedMaintenance(e.target.value)}
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              >
                <option value="all">All Levels</option>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
              </select>
            </div>

            {/* Sort */}
            <div>
              <label htmlFor="sort" className="block text-neutral-700 mb-2 text-sm">
                Sort By
              </label>
              <select
                id="sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'name' | 'price' | 'durability')}
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              >
                <option value="name">Name</option>
                <option value="durability">Durability</option>
              </select>
            </div>
          </div>
        </div>

        {/* Flooring Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredFlooring.map((flooring) => (
            <button
              key={flooring.id}
              onClick={() => onSelectFlooring(flooring.id)}
              className="bg-white rounded-xl shadow-sm hover:shadow-md transition-all overflow-hidden text-left group"
            >
              <div className="aspect-video overflow-hidden bg-neutral-100">
                <img
                  src={flooring.image}
                  alt={flooring.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <h3 className="text-neutral-900 mb-2">{flooring.name}</h3>
                <p className="text-neutral-600 text-sm mb-4 line-clamp-2">
                  {flooring.description}
                </p>
                
                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-neutral-500">Price Range</span>
                    <span className="text-amber-600">{flooring.priceRange}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-neutral-500">Durability</span>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div
                          key={i}
                          className={`w-2 h-2 rounded-full ${
                            i < flooring.durability ? 'bg-amber-600' : 'bg-neutral-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-neutral-500">Maintenance</span>
                    <span className={`px-2 py-1 rounded text-xs ${
                      flooring.maintenance === 'Low' ? 'bg-green-100 text-green-700' :
                      flooring.maintenance === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-orange-100 text-orange-700'
                    }`}>
                      {flooring.maintenance}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-amber-600">
                  <span className="text-sm">Learn More</span>
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </button>
          ))}
        </div>

        {filteredFlooring.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <h3 className="text-neutral-900 mb-2">No flooring found</h3>
            <p className="text-neutral-600">
              Try adjusting your filters or search query
            </p>
          </div>
        )}
      </div>
    </div>
  );
}