import { hardwoodProducts } from '../../data/hardwoodProducts';

interface HardwoodProductDetailProps {
  productId: string;
  onBack: () => void;
}

export function HardwoodProductDetail({ productId, onBack }: HardwoodProductDetailProps) {
  const product = hardwoodProducts.find(p => p.id === productId);

  if (!product) {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-neutral-900 mb-2">Product Not Found</h2>
          <button
            onClick={onBack}
            className="text-amber-600 hover:text-amber-700"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-6xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Products</span>
          </button>
        </div>

        {/* Product Detail */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Image */}
            <div className="aspect-square lg:aspect-auto bg-neutral-100">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Details */}
            <div className="p-8">
              <h1 className="text-neutral-900 mb-2">{product.name}</h1>
              <div className="mb-6">
                <span className="text-amber-600 text-xl">${product.pricePerSqFt.toFixed(2)} /sq ft</span>
              </div>

              <p className="text-neutral-600 mb-6">
                {product.description}
              </p>

              {/* Specifications */}
              <div className="space-y-6 mb-8">
                <div>
                  <h3 className="text-neutral-900 mb-3">Specifications</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-neutral-50 rounded-lg p-4">
                      <div className="text-neutral-500 text-sm mb-1">Species</div>
                      <div className="text-neutral-900">{product.species}</div>
                    </div>
                    <div className="bg-neutral-50 rounded-lg p-4">
                      <div className="text-neutral-500 text-sm mb-1">Color</div>
                      <div className="text-neutral-900">{product.color}</div>
                    </div>
                    <div className="bg-neutral-50 rounded-lg p-4">
                      <div className="text-neutral-500 text-sm mb-1">Plank Width</div>
                      <div className="text-neutral-900">{product.size}</div>
                    </div>
                    <div className="bg-neutral-50 rounded-lg p-4">
                      <div className="text-neutral-500 text-sm mb-1">Thickness</div>
                      <div className="text-neutral-900">{product.thickness}</div>
                    </div>
                    <div className="bg-neutral-50 rounded-lg p-4">
                      <div className="text-neutral-500 text-sm mb-1">Plank Length</div>
                      <div className="text-neutral-900">{product.length}</div>
                    </div>
                    <div className="bg-neutral-50 rounded-lg p-4">
                      <div className="text-neutral-500 text-sm mb-1">Installation</div>
                      <div className="text-neutral-900 text-sm">{product.installMethod}</div>
                    </div>
                    {product.finish && (
                      <div className="bg-neutral-50 rounded-lg p-4 col-span-2">
                        <div className="text-neutral-500 text-sm mb-1">Finish</div>
                        <div className="text-neutral-900">{product.finish}</div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Features */}
                <div>
                  <h3 className="text-neutral-900 mb-3">Key Features</h3>
                  <ul className="space-y-2">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <svg className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span className="text-neutral-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="flex-1 px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors">
                  Request Quote
                </button>
                <button className="flex-1 px-6 py-3 border-2 border-amber-600 text-amber-600 rounded-lg hover:bg-amber-50 transition-colors">
                  View in Visualizer
                </button>
              </div>
            </div>
          </div>

          {/* Additional Info */}
          <div className="border-t border-neutral-200 p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-6 h-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
                <div>
                  <h4 className="text-neutral-900 mb-1">Quality Guaranteed</h4>
                  <p className="text-neutral-600 text-sm">
                    All products backed by manufacturer warranty
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-6 h-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="text-neutral-900 mb-1">Fast Delivery</h4>
                  <p className="text-neutral-600 text-sm">
                    Most orders ship within 3-5 business days
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-6 h-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="text-neutral-900 mb-1">Expert Support</h4>
                  <p className="text-neutral-600 text-sm">
                    Professional installation guidance available
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Installation Note */}
        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-xl p-6">
          <div className="flex gap-4">
            <div className="flex-shrink-0">
              <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h4 className="text-neutral-900 mb-1">Installation Method: {product.installMethod}</h4>
              <p className="text-neutral-600 text-sm">
                {product.installMethod === 'Nail Down' && 
                  'Professional installation recommended. Requires nailing into wood subfloor. Best for solid wood flooring.'}
                {product.installMethod === 'Click-Lock Floating' && 
                  'DIY-friendly! Planks click together and float over underlayment. No glue or nails needed.'}
                {product.installMethod === 'Glue Down' && 
                  'Planks are glued directly to subfloor. Provides stable installation, ideal for concrete or radiant heat.'}
                {product.installMethod === 'Peel and Stick' && 
                  'Easiest installation! Simply peel off backing and stick to clean, flat surface. Perfect for DIY.'}
                {product.installMethod === 'Nail Down or Glue' && 
                  'Versatile installation options. Can be nailed to wood subfloor or glued to any flat surface.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
