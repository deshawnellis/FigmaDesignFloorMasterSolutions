import { EngineeredWoodConfiguration } from './EngineeredWoodCustomizer';

interface EngineeredWoodConfigurationSummaryProps {
  configuration: EngineeredWoodConfiguration;
  onEdit: () => void;
  onRequestQuote: () => void;
  onVisualize?: () => void;
}

export function EngineeredWoodConfigurationSummary({
  configuration,
  onEdit,
  onRequestQuote,
  onVisualize
}: EngineeredWoodConfigurationSummaryProps) {
  const colorOptions: Record<string, { name: string; hex: string }> = {
    'natural-oak': { name: 'Natural Oak', hex: '#D4A574' },
    'honey': { name: 'Honey', hex: '#C8995F' },
    'golden-oak': { name: 'Golden Oak', hex: '#B8860B' },
    'medium-brown': { name: 'Medium Brown', hex: '#8B6F47' },
    'dark-walnut': { name: 'Dark Walnut', hex: '#5C4033' },
    'espresso': { name: 'Espresso', hex: '#3E2723' },
    'gray-wash': { name: 'Gray Wash', hex: '#9E9E9E' },
    'weathered-gray': { name: 'Weathered Gray', hex: '#6D6D6D' },
    'white-oak': { name: 'White Oak', hex: '#F5E6D3' },
    'charcoal': { name: 'Charcoal', hex: '#4A4A4A' }
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-full mb-6 shadow-lg">
            <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-neutral-900 text-4xl mb-4">Configuration Complete!</h1>
          <p className="text-neutral-600 text-lg">
            Your custom engineered wood floor is ready
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Configuration Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Visual Preview */}
            <div className="bg-white rounded-3xl overflow-hidden shadow-xl">
              <div className="relative h-80 bg-gradient-to-br from-orange-100 to-red-100">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div 
                    className="w-full h-full"
                    style={{
                      backgroundColor: colorOptions[configuration.color]?.hex || '#D4A574',
                      backgroundImage: `
                        repeating-linear-gradient(
                          0deg,
                          transparent,
                          transparent 35px,
                          rgba(0,0,0,0.1) 35px,
                          rgba(0,0,0,0.1) 36px
                        ),
                        repeating-linear-gradient(
                          90deg,
                          transparent,
                          transparent ${configuration.plankWidth === '3-inch' ? '60px' : configuration.plankWidth === '5-inch' ? '100px' : configuration.plankWidth === '7-inch' ? '140px' : '180px'},
                          rgba(0,0,0,0.15) ${configuration.plankWidth === '3-inch' ? '60px' : configuration.plankWidth === '5-inch' ? '100px' : configuration.plankWidth === '7-inch' ? '140px' : '180px'},
                          rgba(0,0,0,0.15) ${configuration.plankWidth === '3-inch' ? '61px' : configuration.plankWidth === '5-inch' ? '101px' : configuration.plankWidth === '7-inch' ? '141px' : '181px'}
                        ),
                        linear-gradient(
                          90deg,
                          ${colorOptions[configuration.color]?.hex || '#D4A574'},
                          ${colorOptions[configuration.color]?.hex || '#D4A574'}
                        )
                      `
                    }}
                  />
                </div>
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-neutral-900">Custom Engineered Wood</div>
                        <div className="text-sm text-neutral-600">
                          {colorOptions[configuration.color]?.name}
                        </div>
                      </div>
                      <div className="text-3xl text-neutral-900">
                        ${configuration.totalPrice.toFixed(2)}
                        <span className="text-sm text-neutral-600">/sqft</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Detailed Specifications */}
            <div className="bg-white rounded-3xl p-8 shadow-xl">
              <h2 className="text-neutral-900 text-2xl mb-6">Your Configuration</h2>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-6">
                  <div>
                    <div className="text-sm text-neutral-500 mb-2">Finish Type</div>
                    <div className="text-neutral-900 text-lg capitalize">{configuration.finish.replace('-', ' ')}</div>
                  </div>

                  <div>
                    <div className="text-sm text-neutral-500 mb-2">Color & Stain</div>
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl border-2 border-neutral-200 shadow-sm"
                        style={{ backgroundColor: colorOptions[configuration.color]?.hex }}
                      />
                      <div className="text-neutral-900 text-lg">
                        {colorOptions[configuration.color]?.name}
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-neutral-500 mb-2">Plank Width</div>
                    <div className="text-neutral-900 text-lg capitalize">{configuration.plankWidth.replace('-', ' ')}</div>
                  </div>

                  <div>
                    <div className="text-sm text-neutral-500 mb-2">Plank Length</div>
                    <div className="text-neutral-900 text-lg capitalize">{configuration.plankLength.replace('-', ' ')}</div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <div className="text-sm text-neutral-500 mb-2">Installation Method</div>
                    <div className="text-neutral-900 text-lg capitalize">{configuration.installation.replace('-', ' ')}</div>
                  </div>

                  <div>
                    <div className="text-sm text-neutral-500 mb-2">Gloss Level</div>
                    <div className="text-neutral-900 text-lg capitalize">{configuration.gloss.replace('-', ' ')}</div>
                  </div>

                  <div>
                    <div className="text-sm text-neutral-500 mb-2">Surface Texture</div>
                    <div className="text-neutral-900 text-lg capitalize">{configuration.texture.replace('-', ' ')}</div>
                  </div>

                  <div>
                    <div className="text-sm text-neutral-500 mb-2">Total Price</div>
                    <div className="text-neutral-900 text-3xl">
                      ${configuration.totalPrice.toFixed(2)}
                      <span className="text-lg text-neutral-600">/sqft</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Features & Benefits */}
            <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-3xl p-8">
              <h2 className="text-neutral-900 text-2xl mb-6">Why You'll Love This Floor</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-neutral-900 mb-1">Real Wood Beauty</div>
                    <div className="text-sm text-neutral-600">Genuine wood veneer top layer</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-neutral-900 mb-1">Superior Stability</div>
                    <div className="text-sm text-neutral-600">Multi-layer construction resists warping</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-neutral-900 mb-1">Better Moisture Resistance</div>
                    <div className="text-sm text-neutral-600">Works in basements and humid areas</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-neutral-900 mb-1">Easy Installation</div>
                    <div className="text-sm text-neutral-600">
                      {configuration.installation === 'click-lock' ? 'DIY-friendly click system' : 'Professional installation'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Actions Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-3xl p-6 shadow-xl sticky top-8 space-y-4">
              <h2 className="text-neutral-900 text-xl mb-6">Next Steps</h2>

              <button
                onClick={onVisualize}
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-4 rounded-xl hover:shadow-xl transition-all flex items-center justify-center gap-2"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
                <span>Visualize in Your Room</span>
              </button>

              <button
                onClick={onRequestQuote}
                className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-4 rounded-xl hover:shadow-xl transition-all flex items-center justify-center gap-2"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Request Quote</span>
              </button>

              <button
                onClick={onEdit}
                className="w-full bg-neutral-100 text-neutral-900 py-4 rounded-xl hover:bg-neutral-200 transition-all"
              >
                Edit Configuration
              </button>

              <div className="pt-6 border-t border-neutral-200">
                <h3 className="text-neutral-900 mb-4">Share with Contractors</h3>
                <p className="text-sm text-neutral-600 mb-4">
                  Share your configuration to get accurate quotes from verified contractors
                </p>
                <button className="w-full bg-blue-50 text-blue-700 py-3 rounded-xl hover:bg-blue-100 transition-all">
                  Find Contractors
                </button>
              </div>

              <div className="pt-6 border-t border-neutral-200">
                <h3 className="text-neutral-900 mb-3">Estimated Coverage</h3>
                <div className="bg-neutral-50 rounded-xl p-4 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-neutral-600">500 sq ft</span>
                    <span className="text-neutral-900">${(configuration.totalPrice * 500).toFixed(0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-600">1,000 sq ft</span>
                    <span className="text-neutral-900">${(configuration.totalPrice * 1000).toFixed(0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-600">1,500 sq ft</span>
                    <span className="text-neutral-900">${(configuration.totalPrice * 1500).toFixed(0)}</span>
                  </div>
                </div>
                <p className="text-xs text-neutral-500 mt-2">
                  * Material only. Installation costs vary by location.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}