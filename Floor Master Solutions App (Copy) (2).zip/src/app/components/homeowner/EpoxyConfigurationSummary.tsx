import { EpoxyConfiguration } from './EpoxyCustomizer';
import { epoxyStyles, epoxyFinishes, epoxyColors, epoxyThicknesses, epoxyAdditives } from '../../data/epoxyOptions';

interface EpoxyConfigurationSummaryProps {
  configuration: EpoxyConfiguration;
  onBack: () => void;
  onFindContractors: () => void;
}

export function EpoxyConfigurationSummary({ configuration, onBack, onFindContractors }: EpoxyConfigurationSummaryProps) {
  const style = epoxyStyles.find(s => s.id === configuration.styleId);
  const finish = epoxyFinishes.find(f => f.id === configuration.finishId);
  const color = epoxyColors.find(c => c.id === configuration.primaryColorId);
  const thickness = epoxyThicknesses.find(t => t.id === configuration.thicknessId);
  const additive = epoxyAdditives.find(a => a.id === configuration.additiveId);

  const calculateEstimate = () => {
    let basePrice = 5;
    if (style?.priceCategory === 'Premium') basePrice += 2;
    if (style?.priceCategory === 'Luxury') basePrice += 4;
    if (configuration.finishId === 'matte') basePrice += 0.75;
    if (configuration.finishId === 'textured') basePrice += 1.5;
    if (configuration.thicknessId === 'heavy-duty') basePrice += 2;
    if (configuration.thicknessId === 'industrial') basePrice += 4;
    if (configuration.additiveId === 'small-flakes') basePrice += 1;
    if (configuration.additiveId === 'large-flakes') basePrice += 1.5;
    if (configuration.additiveId === 'metallic-pigment') basePrice += 3;
    if (configuration.additiveId === 'quartz-sand') basePrice += 2;
    if (configuration.additiveId === 'glitter') basePrice += 1;
    
    const total = basePrice * configuration.squareFootage;
    return {
      perSqFt: basePrice,
      total: total,
      low: total * 0.85,
      high: total * 1.15
    };
  };

  const estimate = calculateEstimate();

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-5xl mx-auto px-6 py-8 md:ml-64">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-6 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          <span>Back to Customizer</span>
        </button>

        {/* Success Banner */}
        <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-xl p-8 mb-8 text-white">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <h1 className="text-white text-2xl mb-2">Configuration Complete!</h1>
              <p className="text-green-100">Your custom epoxy floor design is ready</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Configuration Details */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-neutral-900 mb-6">Your Configuration</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Style */}
                <div className="border border-neutral-200 rounded-lg p-4">
                  <p className="text-sm text-neutral-600 mb-2">Epoxy Style</p>
                  <div className="mb-3">
                    <img
                      src={style?.image}
                      alt={style?.name}
                      className="w-full h-32 object-cover rounded-lg mb-2"
                    />
                  </div>
                  <h3 className="text-neutral-900 mb-1">{style?.name}</h3>
                  <p className="text-sm text-neutral-600">{style?.description}</p>
                  <span className={`inline-block px-2 py-1 rounded text-xs mt-2 ${
                    style?.priceCategory === 'Budget' ? 'bg-green-100 text-green-800' :
                    style?.priceCategory === 'Mid-Range' ? 'bg-blue-100 text-blue-800' :
                    style?.priceCategory === 'Premium' ? 'bg-purple-100 text-purple-800' :
                    'bg-amber-100 text-amber-800'
                  }`}>
                    {style?.priceCategory}
                  </span>
                </div>

                {/* Finish */}
                <div className="border border-neutral-200 rounded-lg p-4">
                  <p className="text-sm text-neutral-600 mb-2">Finish Type</p>
                  <h3 className="text-neutral-900 mb-2">{finish?.name}</h3>
                  <p className="text-sm text-neutral-600 mb-3">{finish?.description}</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Appearance:</span>
                      <span className="text-neutral-900">{finish?.appearance}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Slip Resistance:</span>
                      <span className="text-neutral-900">{finish?.slipResistance}</span>
                    </div>
                  </div>
                </div>

                {/* Color */}
                <div className="border border-neutral-200 rounded-lg p-4">
                  <p className="text-sm text-neutral-600 mb-2">Primary Color</p>
                  <div className="flex items-center gap-3 mb-3">
                    <div
                      className="w-16 h-16 rounded-lg border-2 border-neutral-300"
                      style={{ backgroundColor: color?.hexCode }}
                    />
                    <div>
                      <h3 className="text-neutral-900 mb-1">{color?.name}</h3>
                      <p className="text-sm text-neutral-600">{color?.description}</p>
                    </div>
                  </div>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-2 py-1 rounded">
                    {color?.category}
                  </span>
                </div>

                {/* Thickness */}
                <div className="border border-neutral-200 rounded-lg p-4">
                  <p className="text-sm text-neutral-600 mb-2">Coating Thickness</p>
                  <h3 className="text-neutral-900 mb-2">{thickness?.name}</h3>
                  <p className="text-sm text-neutral-600 mb-3">{thickness?.description}</p>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm text-neutral-600">Durability:</span>
                    <div className="flex gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div
                          key={i}
                          className={`w-6 h-2 rounded ${
                            i < (thickness?.durability || 0) ? 'bg-blue-600' : 'bg-neutral-200'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <span className="text-xs bg-neutral-100 text-neutral-700 px-2 py-1 rounded">
                    {thickness?.priceCategory}
                  </span>
                </div>

                {/* Additive */}
                <div className="border border-neutral-200 rounded-lg p-4">
                  <p className="text-sm text-neutral-600 mb-2">Decorative Additive</p>
                  <div className="mb-3">
                    <img
                      src={additive?.image}
                      alt={additive?.name}
                      className="w-full h-24 object-cover rounded-lg mb-2"
                    />
                  </div>
                  <h3 className="text-neutral-900 mb-1">{additive?.name}</h3>
                  <p className="text-sm text-neutral-600 mb-2">{additive?.visualEffect}</p>
                  <p className="text-xs text-blue-600">{additive?.priceImpact}</p>
                </div>

                {/* Project Details */}
                <div className="border border-neutral-200 rounded-lg p-4">
                  <p className="text-sm text-neutral-600 mb-3">Project Details</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Application:</span>
                      <span className="text-neutral-900">{configuration.application}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Square Footage:</span>
                      <span className="text-neutral-900">{configuration.squareFootage} sq ft</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Next Steps */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-neutral-900 mb-4">Next Steps</h2>
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 text-blue-600">
                    1
                  </div>
                  <div>
                    <h3 className="text-neutral-900 mb-1">Connect with Contractors</h3>
                    <p className="text-sm text-neutral-600">
                      Get quotes from verified epoxy flooring professionals in your area
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 text-blue-600">
                    2
                  </div>
                  <div>
                    <h3 className="text-neutral-900 mb-1">Site Inspection</h3>
                    <p className="text-sm text-neutral-600">
                      Contractor will inspect concrete condition and surface preparation needs
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 text-blue-600">
                    3
                  </div>
                  <div>
                    <h3 className="text-neutral-900 mb-1">Installation Timeline</h3>
                    <p className="text-sm text-neutral-600">
                      Typical installation takes 2-3 days with 3-7 days curing time before use
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Pricing Summary */}
          <div className="lg:col-span-1">
            <div className="sticky top-8 space-y-6">
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-6 text-white">
                <h2 className="text-white mb-4">Estimated Investment</h2>
                <div className="space-y-4">
                  <div>
                    <p className="text-blue-100 text-sm mb-1">Per Square Foot</p>
                    <p className="text-3xl">${estimate.perSqFt.toFixed(2)}</p>
                  </div>
                  <div className="border-t border-blue-400 pt-4">
                    <p className="text-blue-100 text-sm mb-2">Total Project Cost</p>
                    <p className="text-4xl mb-1">
                      ${estimate.low.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </p>
                    <p className="text-blue-100 text-sm">
                      to ${estimate.high.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </p>
                  </div>
                  <div className="text-xs text-blue-100 bg-blue-500/30 rounded-lg p-3">
                    Includes materials, surface prep, and professional installation. Actual cost may vary based on site conditions.
                  </div>
                </div>
              </div>

              <button
                onClick={onFindContractors}
                className="w-full py-4 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors text-center text-lg"
              >
                Find Contractors
              </button>

              <div className="bg-white rounded-xl shadow-sm p-6">
                <h3 className="text-neutral-900 mb-4">What's Included</h3>
                <ul className="space-y-3 text-sm text-neutral-600">
                  <li className="flex items-start gap-2">
                    <svg className="w-5 h-5 text-green-600 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Concrete surface preparation</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <svg className="w-5 h-5 text-green-600 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Crack repair and leveling</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <svg className="w-5 h-5 text-green-600 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Primer coat application</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <svg className="w-5 h-5 text-green-600 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Base epoxy layer</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <svg className="w-5 h-5 text-green-600 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Decorative elements</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <svg className="w-5 h-5 text-green-600 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Clear topcoat sealer</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <svg className="w-5 h-5 text-green-600 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Cleanup and disposal</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
