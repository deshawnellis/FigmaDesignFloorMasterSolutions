import { LVPConfiguration } from './LVPCustomizer';

interface LVPConfigurationSummaryProps {
  configuration: LVPConfiguration;
  onEdit: () => void;
  onRequestQuote: () => void;
}

export function LVPConfigurationSummary({ configuration, onEdit, onRequestQuote }: LVPConfigurationSummaryProps) {
  const estimatedInstallation = 3.00; // Average installation cost per sq ft
  const totalCostPerSqFt = configuration.price + estimatedInstallation;
  const typicalRoomSize = 200; // sq ft
  const estimatedTotal = totalCostPerSqFt * typicalRoomSize;

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:ml-32">
        {/* Success Message */}
        <div className="bg-green-50 border border-green-200 rounded-2xl p-6 mb-8">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
              <svg className="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <h2 className="text-green-900 mb-1">Configuration Complete!</h2>
              <p className="text-green-700">
                Your custom LVP flooring specifications are ready. Review the details below and request quotes from local contractors.
              </p>
            </div>
          </div>
        </div>

        {/* Configuration Details */}
        <div className="bg-white rounded-2xl overflow-hidden shadow-sm mb-6">
          <div className="bg-gradient-to-r from-amber-600 to-amber-700 text-white px-6 py-4">
            <h2 className="mb-1">{configuration.styleName}</h2>
            <p className="text-amber-100">Your Custom LVP Configuration</p>
          </div>

          <div className="p-6">
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              {/* Product Specifications */}
              <div>
                <h3 className="text-neutral-900 mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Product Specifications
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between py-2 border-b border-neutral-100">
                    <span className="text-neutral-600">Wear Layer:</span>
                    <span className="text-neutral-900">{configuration.wearLayer}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-neutral-100">
                    <span className="text-neutral-600">Total Thickness:</span>
                    <span className="text-neutral-900">{configuration.thickness}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-neutral-100">
                    <span className="text-neutral-600">Plank Width:</span>
                    <span className="text-neutral-900">{configuration.plankWidth}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-neutral-100">
                    <span className="text-neutral-600">Plank Length:</span>
                    <span className="text-neutral-900">{configuration.plankLength}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-neutral-100">
                    <span className="text-neutral-600">Surface Texture:</span>
                    <span className="text-neutral-900 capitalize">{configuration.texture.replace('-', ' ')}</span>
                  </div>
                </div>
              </div>

              {/* Finish & Installation */}
              <div>
                <h3 className="text-neutral-900 mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
                  </svg>
                  Finish & Installation
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between py-2 border-b border-neutral-100">
                    <span className="text-neutral-600">Color Tone:</span>
                    <span className="text-neutral-900 capitalize">{configuration.color.replace('-', ' ')}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-neutral-100">
                    <span className="text-neutral-600">Surface Finish:</span>
                    <span className="text-neutral-900 capitalize">{configuration.finish}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-neutral-100">
                    <span className="text-neutral-600">Core Type:</span>
                    <span className="text-neutral-900 capitalize">{configuration.backing.replace('-', ' ')}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-neutral-100">
                    <span className="text-neutral-600">Installation:</span>
                    <span className="text-neutral-900 capitalize">{configuration.installation.replace('-', ' ')}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-neutral-100">
                    <span className="text-neutral-600">Underpad:</span>
                    <span className="text-neutral-900">{configuration.underpadIncluded ? 'Included' : 'Separate'}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Features & Benefits */}
            <div className="bg-blue-50 rounded-xl p-6 mb-6">
              <h3 className="text-neutral-900 mb-4">Features & Benefits</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <p className="text-neutral-900">100% Waterproof</p>
                    <p className="text-sm text-neutral-600">Perfect for any room including bathrooms and kitchens</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <p className="text-neutral-900">Scratch Resistant</p>
                    <p className="text-sm text-neutral-600">Durable wear layer protects against daily wear</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <p className="text-neutral-900">Pet Friendly</p>
                    <p className="text-sm text-neutral-600">Resists scratches and accidents from pets</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <p className="text-neutral-900">Easy Maintenance</p>
                    <p className="text-sm text-neutral-600">Simple sweep and mop cleaning</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <p className="text-neutral-900">Sound Dampening</p>
                    <p className="text-sm text-neutral-600">Quieter than hardwood or tile</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <p className="text-neutral-900">Realistic Look</p>
                    <p className="text-sm text-neutral-600">Advanced printing technology mimics natural materials</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Pricing Estimate */}
            <div className="bg-gradient-to-br from-amber-50 to-amber-100 rounded-xl p-6">
              <h3 className="text-neutral-900 mb-4">Estimated Pricing</h3>
              <div className="space-y-3 mb-4">
                <div className="flex justify-between">
                  <span className="text-neutral-700">Material Cost:</span>
                  <span className="text-neutral-900">${configuration.price.toFixed(2)}/sq ft</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-700">Installation (estimated):</span>
                  <span className="text-neutral-900">${estimatedInstallation.toFixed(2)}/sq ft</span>
                </div>
                <div className="border-t-2 border-amber-300 pt-3 flex justify-between">
                  <span className="text-neutral-900">Total Per Sq Ft:</span>
                  <span className="text-neutral-900">${totalCostPerSqFt.toFixed(2)}/sq ft</span>
                </div>
              </div>
              <div className="bg-white rounded-lg p-4 border-2 border-amber-300">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-neutral-600 mb-1">Estimated Total (200 sq ft room)</p>
                    <p className="text-2xl text-neutral-900">${estimatedTotal.toFixed(0)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-neutral-500">Material + Labor</p>
                    <p className="text-xs text-neutral-500">Varies by location</p>
                  </div>
                </div>
              </div>
              <p className="text-xs text-neutral-600 mt-3">
                * Prices are estimates and may vary based on location, room complexity, subfloor condition, and contractor rates. Request quotes for accurate pricing.
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={onEdit}
            className="flex-1 bg-neutral-100 text-neutral-900 py-4 rounded-xl hover:bg-neutral-200 transition-colors flex items-center justify-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
            Edit Configuration
          </button>
          <button
            onClick={onRequestQuote}
            className="flex-1 bg-amber-600 text-white py-4 rounded-xl hover:bg-amber-700 transition-colors flex items-center justify-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            Request Contractor Quotes
          </button>
        </div>

        {/* Next Steps */}
        <div className="mt-8 bg-white rounded-2xl p-6">
          <h3 className="text-neutral-900 mb-4">Next Steps</h3>
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="w-8 h-8 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center flex-shrink-0">1</div>
              <div>
                <h4 className="text-neutral-900 mb-1">Request Quotes</h4>
                <p className="text-sm text-neutral-600">Get estimates from vetted local contractors who specialize in LVP installation.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-8 h-8 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center flex-shrink-0">2</div>
              <div>
                <h4 className="text-neutral-900 mb-1">Compare & Choose</h4>
                <p className="text-sm text-neutral-600">Review contractor profiles, ratings, and detailed quotes to find the best fit.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-8 h-8 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center flex-shrink-0">3</div>
              <div>
                <h4 className="text-neutral-900 mb-1">Schedule Installation</h4>
                <p className="text-sm text-neutral-600">Work with your chosen contractor to schedule and complete your floor installation.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-8 h-8 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center flex-shrink-0">4</div>
              <div>
                <h4 className="text-neutral-900 mb-1">Enjoy Your New Floor</h4>
                <p className="text-sm text-neutral-600">Experience the beauty and durability of your custom LVP flooring!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
