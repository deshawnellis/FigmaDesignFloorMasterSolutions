import { useState } from 'react';
import { flooringTypes } from '../../data/flooringTypes';

export function Visualizer() {
  const [selectedFlooringId, setSelectedFlooringId] = useState(flooringTypes[0].id);
  const [selectedRoom, setSelectedRoom] = useState<'living' | 'kitchen' | 'bedroom' | 'bathroom'>('living');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  const selectedFlooring = flooringTypes.find((f) => f.id === selectedFlooringId);

  const roomImages = {
    living: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbXB0eSUyMGxpdmluZyUyMHJvb218ZW58MXx8fHwxNzY1OTkxNDMyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    kitchen: 'https://images.unsplash.com/photo-1556912172-45b7abe8b7e1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbXB0eSUyMGtpdGNoZW58ZW58MXx8fHwxNzY1OTkxNDMzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    bedroom: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbXB0eSUyMGJlZHJvb218ZW58MXx8fHwxNzY1OTkxNDMzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    bathroom: 'https://images.unsplash.com/photo-1507652313519-d4e9174996dd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbXB0eSUyMGJhdGhyb29tfGVufDF8fHx8MTc2NTk5MTQzM3ww&ixlib=rb-4.1.0&q=80&w=1080',
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const displayImage = uploadedImage || roomImages[selectedRoom];

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-neutral-900 mb-2">Floor Visualizer</h1>
          <p className="text-neutral-600">
            Preview different flooring options in your space
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Preview Area */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
              {/* Image Display */}
              <div className="aspect-video bg-neutral-100 relative">
                <img
                  src={displayImage}
                  alt="Room preview"
                  className="w-full h-full object-cover"
                />
                {selectedFlooring && (
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-6">
                    <div className="text-white">
                      <div className="text-sm opacity-80 mb-1">Currently Previewing</div>
                      <div>{selectedFlooring.name}</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Room Selection */}
              <div className="p-6 border-b border-neutral-200">
                <h3 className="text-neutral-900 mb-4">Select Room Type</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {(['living', 'kitchen', 'bedroom', 'bathroom'] as const).map((room) => (
                    <button
                      key={room}
                      onClick={() => {
                        setSelectedRoom(room);
                        setUploadedImage(null);
                      }}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        selectedRoom === room && !uploadedImage
                          ? 'border-amber-600 bg-amber-50'
                          : 'border-neutral-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="text-neutral-900 capitalize">{room}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Upload Option */}
              <div className="p-6">
                <h3 className="text-neutral-900 mb-4">Or Upload Your Room Photo</h3>
                <label className="flex flex-col items-center gap-3 p-6 border-2 border-dashed border-neutral-300 rounded-lg hover:border-amber-600 transition-colors cursor-pointer">
                  <svg className="w-12 h-12 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                  </svg>
                  <div className="text-center">
                    <div className="text-neutral-900 mb-1">Click to upload an image</div>
                    <div className="text-neutral-500 text-sm">PNG, JPG up to 10MB</div>
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
                {uploadedImage && (
                  <button
                    onClick={() => setUploadedImage(null)}
                    className="mt-3 text-amber-600 hover:text-amber-700 text-sm"
                  >
                    Remove uploaded image
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Flooring Selection Sidebar */}
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-sm p-6">
              <h3 className="text-neutral-900 mb-4">Select Flooring</h3>
              <div className="space-y-3">
                {flooringTypes.map((flooring) => (
                  <button
                    key={flooring.id}
                    onClick={() => setSelectedFlooringId(flooring.id)}
                    className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                      selectedFlooringId === flooring.id
                        ? 'border-amber-600 bg-amber-50'
                        : 'border-neutral-200 hover:border-amber-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-16 h-16 rounded-lg overflow-hidden bg-neutral-100 flex-shrink-0">
                        <img
                          src={flooring.image}
                          alt={flooring.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-neutral-900 mb-1 truncate">{flooring.name}</div>
                        <div className="text-neutral-500 text-sm">{flooring.priceRange}</div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {selectedFlooring && (
              <div className="bg-white rounded-2xl shadow-sm p-6">
                <h3 className="text-neutral-900 mb-4">Details</h3>
                <div className="space-y-3">
                  <div>
                    <div className="text-neutral-500 text-sm mb-1">Price Range</div>
                    <div className="text-neutral-900">{selectedFlooring.priceRange}</div>
                  </div>
                  <div>
                    <div className="text-neutral-500 text-sm mb-1">Durability</div>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div
                          key={i}
                          className={`w-2 h-2 rounded-full ${
                            i < selectedFlooring.durability ? 'bg-amber-600' : 'bg-neutral-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <div>
                    <div className="text-neutral-500 text-sm mb-1">Maintenance</div>
                    <span className={`inline-block px-2 py-1 rounded text-xs ${
                      selectedFlooring.maintenance === 'Low' ? 'bg-green-100 text-green-700' :
                      selectedFlooring.maintenance === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-orange-100 text-orange-700'
                    }`}>
                      {selectedFlooring.maintenance}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
