import { useState, useMemo } from 'react';
import { getProductsByType, getUniqueColors, getUniqueSizes, getUniqueInstallMethods, getUniqueSpecies, HardwoodProduct } from '../../data/hardwoodProducts';

interface HardwoodProductBrowserProps {
  hardwoodType: string;
  onBack: () => void;
  onSelectProduct: (productId: string) => void;
}

export function HardwoodProductBrowser({ hardwoodType, onBack, onSelectProduct }: HardwoodProductBrowserProps) {
  const [selectedColor, setSelectedColor] = useState<string>('all');
  const [selectedSize, setSelectedSize] = useState<string>('all');
  const [selectedInstallMethod, setSelectedInstallMethod] = useState<string>('all');
  const [selectedSpecies, setSelectedSpecies] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'price-low' | 'price-high'>('name');

  const typeLabel = useMemo(() => {
    const labels: Record<string, string> = {
      unfinished: 'Unfinished Hardwood',
      prefinished: 'Prefinished Hardwood',
      engineered: 'Engineered Hardwood',
      lvp: 'Luxury Vinyl Plank (LVP)'
    };
    return labels[hardwoodType] || 'Hardwood';
  }, [hardwoodType]);

  const allProducts = useMemo(() => getProductsByType(hardwoodType), [hardwoodType]);
  const colors = useMemo(() => getUniqueColors(hardwoodType), [hardwoodType]);
  const sizes = useMemo(() => getUniqueSizes(hardwoodType), [hardwoodType]);
  const installMethods = useMemo(() => getUniqueInstallMethods(hardwoodType), [hardwoodType]);
  const species = useMemo(() => getUniqueSpecies(hardwoodType), [hardwoodType]);

  const filteredProducts = useMemo(() => {
    let products = allProducts.filter((product) => {
      const matchesColor = selectedColor === 'all' || product.color === selectedColor;
      const matchesSize = selectedSize === 'all' || product.size === selectedSize;
      const matchesInstall = selectedInstallMethod === 'all' || product.installMethod === selectedInstallMethod;
      const matchesSpecies = selectedSpecies === 'all' || product.species === selectedSpecies;
      return matchesColor && matchesSize && matchesInstall && matchesSpecies;
    });

    // Sort products
    if (sortBy === 'price-low') {
      products = [...products].sort((a, b) => a.pricePerSqFt - b.pricePerSqFt);
    } else if (sortBy === 'price-high') {
      products = [...products].sort((a, b) => b.pricePerSqFt - a.pricePerSqFt);
    } else {
      products = [...products].sort((a, b) => a.name.localeCompare(b.name));
    }

    return products;
  }, [allProducts, selectedColor, selectedSize, selectedInstallMethod, selectedSpecies, sortBy]);

  const handleReset = () => {
    setSelectedColor('all');
    setSelectedSize('all');
    setSelectedInstallMethod('all');
    setSelectedSpecies('all');
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6 py-8 md:ml-64">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Type Selection</span>
          </button>
          
          <h1 className="text-neutral-900 mb-2">{typeLabel} Products</h1>
          <p className="text-neutral-600">
            Browse and filter products to find your perfect match
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-neutral-900 text-sm">Filter Products</h3>
            <button
              onClick={handleReset}
              className="text-amber-600 hover:text-amber-700 text-sm transition-colors"
            >
              Reset Filters
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            {/* Species Filter */}
            {species.length > 1 && (
              <div>
                <label htmlFor="species" className="block text-neutral-700 mb-2 text-sm">
                  Wood Species
                </label>
                <select
                  id="species"
                  value={selectedSpecies}
                  onChange={(e) => setSelectedSpecies(e.target.value)}
                  className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
                >
                  <option value="all">All Species</option>
                  {species.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
            )}

            {/* Color Filter */}
            <div>
              <label htmlFor="color" className="block text-neutral-700 mb-2 text-sm">
                Color
              </label>
              <select
                id="color"
                value={selectedColor}
                onChange={(e) => setSelectedColor(e.target.value)}
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              >
                <option value="all">All Colors</option>
                {colors.map((color) => (
                  <option key={color} value={color}>{color}</option>
                ))}
              </select>
            </div>

            {/* Size Filter */}
            <div>
              <label htmlFor="size" className="block text-neutral-700 mb-2 text-sm">
                Plank Width
              </label>
              <select
                id="size"
                value={selectedSize}
                onChange={(e) => setSelectedSize(e.target.value)}
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              >
                <option value="all">All Sizes</option>
                {sizes.map((size) => (
                  <option key={size} value={size}>{size}</option>
                ))}
              </select>
            </div>

            {/* Installation Method Filter */}
            <div>
              <label htmlFor="install" className="block text-neutral-700 mb-2 text-sm">
                Installation Method
              </label>
              <select
                id="install"
                value={selectedInstallMethod}
                onChange={(e) => setSelectedInstallMethod(e.target.value)}
                className="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              >
                <option value="all">All Methods</option>
                {installMethods.map((method) => (
                  <option key={method} value={method}>{method}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Sort */}
          <div className="flex items-center justify-between pt-4 border-t border-neutral-200">
            <div className="text-neutral-600 text-sm">
              Showing {filteredProducts.length} of {allProducts.length} products
            </div>
            <div className="flex items-center gap-2">
              <label htmlFor="sort" className="text-neutral-700 text-sm">
                Sort by:
              </label>
              <select
                id="sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'name' | 'price-low' | 'price-high')}
                className="px-3 py-1 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent text-sm"
              >
                <option value="name">Name</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
              </select>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <button
                key={product.id}
                onClick={() => onSelectProduct(product.id)}
                className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden text-left group"
              >
                <div className="aspect-video overflow-hidden bg-neutral-100">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                
                <div className="p-6">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-neutral-900 pr-2">{product.name}</h3>
                    <svg 
                      className="w-5 h-5 text-amber-600 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>

                  <div className="mb-4">
                    <span className="text-amber-600">${product.pricePerSqFt.toFixed(2)} /sq ft</span>
                  </div>
                  
                  <p className="text-neutral-600 text-sm mb-4 line-clamp-2">
                    {product.description}
                  </p>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500">Species:</span>
                      <span className="text-neutral-700">{product.species}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500">Color:</span>
                      <span className="text-neutral-700">{product.color}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500">Width:</span>
                      <span className="text-neutral-700">{product.size}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500">Install:</span>
                      <span className="text-neutral-700 text-xs">{product.installMethod}</span>
                    </div>
                  </div>

                  {product.features.length > 0 && (
                    <div className="mt-4 pt-4 border-t border-neutral-100">
                      <ul className="space-y-1">
                        {product.features.slice(0, 2).map((feature, index) => (
                          <li key={index} className="flex items-start gap-2 text-neutral-600 text-xs">
                            <svg className="w-3 h-3 text-amber-600 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-xl">
            <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <h3 className="text-neutral-900 mb-2">No products found</h3>
            <p className="text-neutral-600 mb-4">
              Try adjusting your filters to see more options
            </p>
            <button
              onClick={handleReset}
              className="px-6 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
