import { useState } from 'react';
import { FloorProject } from '../../data/floorProjects';
import { contractors } from '../../data/contractors';

interface ShareWithContractorsProps {
  project: FloorProject;
  onShare: (project: FloorProject, contractorIds: string[], findingContractors: boolean) => void;
  onBack: () => void;
}

export function ShareWithContractors({ project, onShare, onBack }: ShareWithContractorsProps) {
  const [selectedTab, setSelectedTab] = useState<'specific' | 'find'>('find');
  const [selectedContractors, setSelectedContractors] = useState<string[]>([]);
  const [message, setMessage] = useState('');
  const [shared, setShared] = useState(false);

  const toggleContractor = (contractorId: string) => {
    if (selectedContractors.includes(contractorId)) {
      setSelectedContractors(selectedContractors.filter(id => id !== contractorId));
    } else {
      setSelectedContractors([...selectedContractors, contractorId]);
    }
  };

  const handleShare = () => {
    if (selectedTab === 'find') {
      onShare(project, [], true);
    } else {
      onShare(project, selectedContractors, false);
    }
    setShared(true);
  };

  if (shared) {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center p-6">
        <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-neutral-900 mb-3">Design Shared!</h2>
          <p className="text-neutral-600 mb-6">
            {selectedTab === 'find' 
              ? 'Your floor design is now visible to contractors. They can view your photo and specifications and send you quotes.'
              : `Your floor design has been sent to ${selectedContractors.length} contractor${selectedContractors.length > 1 ? 's' : ''}. You'll be notified when they respond with quotes.`
            }
          </p>
          <button
            onClick={onBack}
            className="w-full bg-amber-600 text-white py-3 rounded-xl hover:bg-amber-700 transition-colors"
          >
            View My Projects
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-900 mb-4"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back
          </button>
          <h1 className="text-neutral-900 mb-2">Share Your Design</h1>
          <p className="text-neutral-600">
            Connect with contractors who can bring your vision to life
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Design Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-sm p-6 sticky top-6">
              <h3 className="text-neutral-900 mb-4">Your Design</h3>
              
              {project.roomPhoto && (
                <div className="rounded-xl overflow-hidden mb-4">
                  <img src={project.roomPhoto} alt="Room" className="w-full" />
                </div>
              )}

              <div className="space-y-3 mb-6">
                <div className="pb-3 border-b border-neutral-200">
                  <p className="text-xs text-neutral-600 mb-1">Room</p>
                  <p className="text-neutral-900">{project.roomType}</p>
                </div>
                <div className="pb-3 border-b border-neutral-200">
                  <p className="text-xs text-neutral-600 mb-1">Flooring</p>
                  <p className="text-neutral-900 capitalize">{project.flooringType}</p>
                </div>
                <div className="pb-3 border-b border-neutral-200">
                  <p className="text-xs text-neutral-600 mb-1">Size</p>
                  <p className="text-neutral-900">{project.squareFootage} sq ft</p>
                </div>
                {project.budget && (
                  <div>
                    <p className="text-xs text-neutral-600 mb-1">Budget</p>
                    <p className="text-neutral-900">
                      ${project.budget.min.toLocaleString()} - ${project.budget.max.toLocaleString()}
                    </p>
                  </div>
                )}
              </div>

              {/* Specifications */}
              <div className="bg-neutral-50 rounded-xl p-4">
                <p className="text-xs text-neutral-600 mb-2">Full Specifications</p>
                <div className="space-y-2 text-sm">
                  {project.hardwood && (
                    <>
                      <p className="text-neutral-700"><span className="text-neutral-500">Species:</span> {project.hardwood.species}</p>
                      <p className="text-neutral-700"><span className="text-neutral-500">Color:</span> {project.hardwood.color}</p>
                      <p className="text-neutral-700"><span className="text-neutral-500">Finish:</span> {project.hardwood.finish}</p>
                    </>
                  )}
                  {project.carpet && (
                    <>
                      <p className="text-neutral-700"><span className="text-neutral-500">Style:</span> {project.carpet.style}</p>
                      <p className="text-neutral-700"><span className="text-neutral-500">Fiber:</span> {project.carpet.fiber}</p>
                      <p className="text-neutral-700"><span className="text-neutral-500">Color:</span> {project.carpet.color}</p>
                    </>
                  )}
                  {project.tile && (
                    <>
                      <p className="text-neutral-700"><span className="text-neutral-500">Material:</span> {project.tile.material}</p>
                      <p className="text-neutral-700"><span className="text-neutral-500">Size:</span> {project.tile.size}</p>
                      <p className="text-neutral-700"><span className="text-neutral-500">Pattern:</span> {project.tile.pattern}</p>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Right: Contractor Options */}
          <div className="lg:col-span-2">
            {/* Tabs */}
            <div className="bg-white rounded-2xl shadow-sm mb-6">
              <div className="flex border-b border-neutral-200">
                <button
                  onClick={() => setSelectedTab('find')}
                  className={`flex-1 py-4 px-6 transition-colors ${
                    selectedTab === 'find'
                      ? 'border-b-2 border-amber-600 text-amber-600'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  <div className="flex items-center justify-center gap-2">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                    <span>Find Contractors</span>
                  </div>
                </button>
                <button
                  onClick={() => setSelectedTab('specific')}
                  className={`flex-1 py-4 px-6 transition-colors ${
                    selectedTab === 'specific'
                      ? 'border-b-2 border-amber-600 text-amber-600'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  <div className="flex items-center justify-center gap-2">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    </svg>
                    <span>Send to Specific Contractor</span>
                  </div>
                </button>
              </div>
            </div>

            {/* Find Contractors Tab */}
            {selectedTab === 'find' && (
              <div className="space-y-6">
                <div className="bg-white rounded-2xl shadow-sm p-6">
                  <div className="flex items-start gap-4 mb-6">
                    <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center flex-shrink-0">
                      <svg className="w-6 h-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-neutral-900 mb-2">How It Works</h3>
                      <ol className="space-y-2 text-neutral-700">
                        <li className="flex items-start gap-2">
                          <span className="text-amber-600">1.</span>
                          <span>Your design is shared with qualified contractors in your area</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-amber-600">2.</span>
                          <span>Contractors can view your room photo and all flooring specifications</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-amber-600">3.</span>
                          <span>Interested contractors send you quotes and can schedule estimates</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-amber-600">4.</span>
                          <span>You review quotes and choose the best contractor for your project</span>
                        </li>
                      </ol>
                    </div>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
                    <div className="flex items-start gap-3">
                      <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <div className="text-sm text-blue-900">
                        <p className="mb-2">Your contact information will only be shared with contractors you choose to work with.</p>
                        <p>Contractors can see your design specifications and room photo to provide accurate quotes.</p>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handleShare}
                    className="w-full bg-amber-600 text-white py-4 rounded-xl hover:bg-amber-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                    </svg>
                    Share Design & Find Contractors
                  </button>
                </div>
              </div>
            )}

            {/* Send to Specific Contractor Tab */}
            {selectedTab === 'specific' && (
              <div className="space-y-6">
                <div className="bg-white rounded-2xl shadow-sm p-6">
                  <h3 className="text-neutral-900 mb-4">Select Contractors</h3>
                  <p className="text-neutral-600 mb-6">
                    Choose contractors to send your design to. They'll receive your room photo and all specifications.
                  </p>

                  <div className="space-y-4 mb-6">
                    {contractors.map((contractor) => (
                      <label
                        key={contractor.id}
                        className={`flex items-start gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                          selectedContractors.includes(contractor.id)
                            ? 'border-amber-600 bg-amber-50'
                            : 'border-neutral-200 hover:border-neutral-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={selectedContractors.includes(contractor.id)}
                          onChange={() => toggleContractor(contractor.id)}
                          className="w-5 h-5 text-amber-600 rounded mt-1"
                        />
                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h4 className="text-neutral-900">{contractor.name}</h4>
                              <p className="text-sm text-neutral-600">{contractor.location}</p>
                            </div>
                            <div className="flex items-center gap-1">
                              <svg className="w-4 h-4 text-amber-400 fill-amber-400" viewBox="0 0 24 24">
                                <path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                              </svg>
                              <span className="text-sm text-neutral-900">{contractor.rating}</span>
                              <span className="text-xs text-neutral-500">({contractor.reviews})</span>
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {contractor.specialties.slice(0, 3).map((specialty, i) => (
                              <span key={i} className="text-xs bg-neutral-100 text-neutral-700 px-2 py-1 rounded">
                                {specialty}
                              </span>
                            ))}
                          </div>
                        </div>
                      </label>
                    ))}
                  </div>

                  <div className="mb-6">
                    <label className="text-neutral-900 mb-2 block">
                      Add a message (optional)
                    </label>
                    <textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="w-full border border-neutral-200 rounded-xl p-4 min-h-[100px] focus:outline-none focus:ring-2 focus:ring-amber-600"
                      placeholder="Hi! I'm interested in getting a quote for this flooring project. Please let me know your availability..."
                    />
                  </div>

                  <button
                    onClick={handleShare}
                    disabled={selectedContractors.length === 0}
                    className="w-full bg-amber-600 text-white py-4 rounded-xl hover:bg-amber-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    Send to {selectedContractors.length || 0} Contractor{selectedContractors.length !== 1 ? 's' : ''}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
