export interface WoodSpecies {
  id: string;
  name: string;
  scientificName: string;
  image: string;
  description: string;
  hardness: number; // Janka hardness rating
  colorRange: string;
  grainPattern: string;
  durability: 1 | 2 | 3 | 4 | 5;
  priceCategory: 'Budget' | 'Mid-Range' | 'Premium' | 'Luxury';
  origin: string;
  characteristics: string[];
  bestFor: string[];
  category: 'Domestic Hardwood' | 'Exotic Hardwood' | 'Softwood' | 'Bamboo';
}

export const woodSpecies: WoodSpecies[] = [
  // Domestic Hardwoods
  {
    id: 'red-oak',
    name: 'Red Oak',
    scientificName: 'Quercus rubra',
    image: 'https://images.unsplash.com/photo-1711915442858-2a5bb7ba67d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvYWslMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE1OXww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'The most popular hardwood flooring in America. Known for its prominent grain pattern and warm tones.',
    hardness: 1290,
    colorRange: 'Light tan to reddish brown',
    grainPattern: 'Open grain with prominent cathedral patterns',
    durability: 4,
    priceCategory: 'Mid-Range',
    origin: 'Eastern North America',
    characteristics: [
      'Takes stain very well',
      'Highly versatile',
      'Readily available',
      'Classic American look',
      'Moderate hardness'
    ],
    bestFor: ['Living rooms', 'Bedrooms', 'Dining rooms', 'Traditional homes'],
    category: 'Domestic Hardwood'
  },
  {
    id: 'white-oak',
    name: 'White Oak',
    scientificName: 'Quercus alba',
    image: 'https://images.unsplash.com/photo-1711915442858-2a5bb7ba67d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvYWslMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE1OXww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Premium oak with tighter grain and superior water resistance. Increasingly popular in modern designs.',
    hardness: 1360,
    colorRange: 'Light tan to medium brown',
    grainPattern: 'Tighter grain than red oak with subtle rays',
    durability: 4,
    priceCategory: 'Mid-Range',
    origin: 'Eastern North America',
    characteristics: [
      'More water resistant than red oak',
      'Harder and more durable',
      'Tighter grain pattern',
      'Modern or traditional',
      'Excellent for gray stains'
    ],
    bestFor: ['Kitchens', 'High-traffic areas', 'Contemporary homes', 'Gray-toned interiors'],
    category: 'Domestic Hardwood'
  },
  {
    id: 'hard-maple',
    name: 'Hard Maple',
    scientificName: 'Acer saccharum',
    image: 'https://images.unsplash.com/photo-1677912997249-ad4bfbc3f1e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXBsZSUyMGhhcmR3b29kJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDEzMTU5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Very hard, light-colored wood with fine, uniform grain. Extremely durable.',
    hardness: 1450,
    colorRange: 'Creamy white to light reddish brown',
    grainPattern: 'Fine, even grain with occasional curly or birds eye figure',
    durability: 5,
    priceCategory: 'Mid-Range',
    origin: 'Northern United States and Canada',
    characteristics: [
      'Very hard and durable',
      'Light natural color',
      'Fine, smooth texture',
      'Resists wear exceptionally well',
      'Can be difficult to stain evenly'
    ],
    bestFor: ['Gyms', 'Basketball courts', 'High-traffic commercial', 'Modern light interiors'],
    category: 'Domestic Hardwood'
  },
  {
    id: 'hickory',
    name: 'Hickory',
    scientificName: 'Carya spp.',
    image: 'https://images.unsplash.com/photo-1617262869522-6740e6450f27?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWNrb3J5JTIwaGFyZHdvb2QlMjBmbG9vcnxlbnwxfHx8fDE3NjYwMTMxNjB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'The hardest domestic wood. Features dramatic color variation for rustic appeal.',
    hardness: 1820,
    colorRange: 'Pale blonde to dark brown (high variation)',
    grainPattern: 'Wavy, irregular with dramatic color shifts',
    durability: 5,
    priceCategory: 'Mid-Range',
    origin: 'Eastern United States',
    characteristics: [
      'Hardest domestic wood',
      'Dramatic color variation',
      'Rustic, natural character',
      'Extremely durable',
      'Bold visual impact'
    ],
    bestFor: ['Rustic homes', 'Cabins', 'High-traffic areas', 'Statement floors'],
    category: 'Domestic Hardwood'
  },
  {
    id: 'ash',
    name: 'Ash',
    scientificName: 'Fraxinus americana',
    image: 'https://images.unsplash.com/photo-1608702529091-f3b4fab4b97e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2glMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Light-colored wood with prominent grain similar to oak. Strong and elastic.',
    hardness: 1320,
    colorRange: 'Light tan to pale blonde',
    grainPattern: 'Straight grain with occasional waves',
    durability: 4,
    priceCategory: 'Mid-Range',
    origin: 'Eastern North America',
    characteristics: [
      'Light, neutral color',
      'Similar to oak in appearance',
      'Good shock resistance',
      'Takes stain well',
      'Affordable alternative to oak'
    ],
    bestFor: ['Contemporary interiors', 'Scandinavian designs', 'Living rooms', 'Bedrooms'],
    category: 'Domestic Hardwood'
  },
  {
    id: 'american-cherry',
    name: 'American Cherry',
    scientificName: 'Prunus serotina',
    image: 'https://images.unsplash.com/photo-1607683647175-62bfc63a8cbe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVycnklMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Luxurious wood with rich reddish-brown color that deepens with age and light exposure.',
    hardness: 950,
    colorRange: 'Light pink to rich reddish brown',
    grainPattern: 'Fine, straight grain with smooth texture',
    durability: 3,
    priceCategory: 'Premium',
    origin: 'Eastern United States',
    characteristics: [
      'Rich, warm color',
      'Darkens beautifully with age',
      'Smooth, fine texture',
      'Formal, elegant appearance',
      'Softer than oak'
    ],
    bestFor: ['Formal dining rooms', 'Studies', 'Luxury homes', 'Traditional interiors'],
    category: 'Domestic Hardwood'
  },
  {
    id: 'walnut',
    name: 'American Walnut',
    scientificName: 'Juglans nigra',
    image: 'https://images.unsplash.com/photo-1642935264339-694e0fb27b0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YWxudXQlMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Premium dark chocolate brown wood. Highly prized for its rich color and figure.',
    hardness: 1010,
    colorRange: 'Rich chocolate brown with darker streaks',
    grainPattern: 'Straight grain, sometimes wavy with beautiful figure',
    durability: 4,
    priceCategory: 'Luxury',
    origin: 'Eastern United States',
    characteristics: [
      'Luxurious dark color',
      'Premium appearance',
      'Excellent stability',
      'Distinctive grain patterns',
      'High-end appeal'
    ],
    bestFor: ['Luxury homes', 'Executive offices', 'Modern interiors', 'Statement spaces'],
    category: 'Domestic Hardwood'
  },
  {
    id: 'birch',
    name: 'Birch',
    scientificName: 'Betula alleghaniensis',
    image: 'https://images.unsplash.com/photo-1677912997249-ad4bfbc3f1e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaXJjaCUyMHdvb2QlMjBmbG9vcnxlbnwxfHx8fDE3NjYwMTM2MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Light, creamy wood with fine grain. Budget-friendly alternative to maple.',
    hardness: 1260,
    colorRange: 'Creamy white to light reddish brown',
    grainPattern: 'Fine, even grain with occasional waves',
    durability: 4,
    priceCategory: 'Budget',
    origin: 'Northern United States and Canada',
    characteristics: [
      'Affordable',
      'Light, neutral color',
      'Similar to maple',
      'Good durability',
      'Easy to work with'
    ],
    bestFor: ['Budget-conscious projects', 'Light interiors', 'Scandinavian style', 'Rental properties'],
    category: 'Domestic Hardwood'
  },

  // Exotic Hardwoods
  {
    id: 'brazilian-cherry',
    name: 'Brazilian Cherry (Jatoba)',
    scientificName: 'Hymenaea courbaril',
    image: 'https://images.unsplash.com/photo-1607683647175-62bfc63a8cbe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVycnklMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Extremely hard exotic wood with rich reddish-brown color. Very durable and stable.',
    hardness: 2350,
    colorRange: 'Salmon pink to deep reddish brown',
    grainPattern: 'Interlocked, medium to coarse texture',
    durability: 5,
    priceCategory: 'Premium',
    origin: 'Central and South America',
    characteristics: [
      'Exceptionally hard',
      'Rich red tones',
      'Highly durable',
      'Deepens with age',
      'Exotic appeal'
    ],
    bestFor: ['High-traffic areas', 'Luxury homes', 'Tropical style', 'Long-lasting floors'],
    category: 'Exotic Hardwood'
  },
  {
    id: 'brazilian-walnut',
    name: 'Brazilian Walnut (Ipe)',
    scientificName: 'Tabebuia spp.',
    image: 'https://images.unsplash.com/photo-1642935264339-694e0fb27b0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YWxudXQlMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'One of the hardest woods in the world. Dense, durable, and naturally resistant to decay.',
    hardness: 3680,
    colorRange: 'Olive brown to blackish with lighter streaks',
    grainPattern: 'Fine to medium texture, interlocked grain',
    durability: 5,
    priceCategory: 'Luxury',
    origin: 'South America',
    characteristics: [
      'Hardest flooring wood',
      'Naturally rot resistant',
      'Extremely durable',
      'Dense and stable',
      'Premium exotic choice'
    ],
    bestFor: ['High-end homes', 'Commercial spaces', 'Outdoor decking', 'Extreme durability needs'],
    category: 'Exotic Hardwood'
  },
  {
    id: 'tigerwood',
    name: 'Tigerwood',
    scientificName: 'Astronium spp.',
    image: 'https://images.unsplash.com/photo-1617262869522-6740e6450f27?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWNrb3J5JTIwaGFyZHdvb2QlMjBmbG9vcnxlbnwxfHx8fDE3NjYwMTMxNjB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Exotic wood with dramatic striping pattern resembling a tiger. Bold and unique.',
    hardness: 1850,
    colorRange: 'Golden orange to reddish brown with black stripes',
    grainPattern: 'Irregular with dramatic color contrast',
    durability: 5,
    priceCategory: 'Premium',
    origin: 'South America',
    characteristics: [
      'Dramatic tiger striping',
      'Unique appearance',
      'Very hard and durable',
      'Natural luster',
      'Conversation piece'
    ],
    bestFor: ['Statement floors', 'Modern designs', 'Accent areas', 'Bold interiors'],
    category: 'Exotic Hardwood'
  },
  {
    id: 'santos-mahogany',
    name: 'Santos Mahogany',
    scientificName: 'Myroxylon balsamum',
    image: 'https://images.unsplash.com/photo-1617262869522-6740e6450f27?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWhvZ2FueSUyMHdvb2QlMjBmbG9vcnxlbnwxfHx8fDE3NjYwMTM2MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Rich reddish-brown exotic wood with excellent stability and hardness.',
    hardness: 2200,
    colorRange: 'Reddish brown to deep purple-brown',
    grainPattern: 'Interlocked, medium to fine texture',
    durability: 5,
    priceCategory: 'Premium',
    origin: 'South America',
    characteristics: [
      'Rich red tones',
      'Very hard and stable',
      'Minimal expansion',
      'Exotic appearance',
      'Long-lasting'
    ],
    bestFor: ['Luxury homes', 'High-traffic areas', 'Traditional elegance', 'Investment flooring'],
    category: 'Exotic Hardwood'
  },
  {
    id: 'acacia',
    name: 'Acacia',
    scientificName: 'Acacia spp.',
    image: 'https://images.unsplash.com/photo-1578208896106-f20b2482208d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY2FjaWElMjB3b29kJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDEzNzI5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Fast-growing sustainable hardwood with beautiful color variation and durability.',
    hardness: 1750,
    colorRange: 'Golden brown to medium brown with color variation',
    grainPattern: 'Wavy, interlocked with natural character',
    durability: 5,
    priceCategory: 'Mid-Range',
    origin: 'Asia, Australia, Africa',
    characteristics: [
      'Eco-friendly and sustainable',
      'Natural color variation',
      'Very durable',
      'Water resistant',
      'Affordable exotic option'
    ],
    bestFor: ['Eco-conscious homes', 'Modern rustic', 'High-traffic areas', 'Budget exotics'],
    category: 'Exotic Hardwood'
  },
  {
    id: 'teak',
    name: 'Teak',
    scientificName: 'Tectona grandis',
    image: 'https://images.unsplash.com/photo-1601063936640-a0e4e4ed081c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFrJTIwd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzYzNXww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Premium wood with natural oils making it highly water and insect resistant.',
    hardness: 1070,
    colorRange: 'Golden tan to rich honey brown',
    grainPattern: 'Straight grain with coarse, uneven texture',
    durability: 5,
    priceCategory: 'Luxury',
    origin: 'Southeast Asia',
    characteristics: [
      'Natural water resistance',
      'Insect resistant',
      'Rich golden color',
      'Natural oils',
      'Prestigious wood'
    ],
    bestFor: ['Bathrooms', 'Luxury yachts', 'High-end homes', 'Moisture-prone areas'],
    category: 'Exotic Hardwood'
  },
  {
    id: 'koa',
    name: 'Koa',
    scientificName: 'Acacia koa',
    image: 'https://images.unsplash.com/photo-1578208896106-f20b2482208d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY2FjaWElMjB3b29kJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDEzNzI5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Rare Hawaiian wood with stunning figure and chatoyance. Highly prized and expensive.',
    hardness: 1170,
    colorRange: 'Golden to reddish brown with figure',
    grainPattern: 'Interlocked, wavy with curly or fiddleback figure',
    durability: 4,
    priceCategory: 'Luxury',
    origin: 'Hawaii',
    characteristics: [
      'Extremely rare',
      'Beautiful figure',
      'Lustrous finish',
      'Hawaiian heritage',
      'Investment grade'
    ],
    bestFor: ['Ultra-luxury homes', 'Showcase spaces', 'Hawaiian style', 'Collectors'],
    category: 'Exotic Hardwood'
  },

  // Softwoods
  {
    id: 'pine',
    name: 'Pine',
    scientificName: 'Pinus spp.',
    image: 'https://images.unsplash.com/photo-1681457551985-a606d11ea7fa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaW5lJTIwd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzYzNnww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Classic softwood with rustic charm. Affordable and full of character with knots.',
    hardness: 690,
    colorRange: 'Pale yellow to light brown',
    grainPattern: 'Prominent grain with knots and character marks',
    durability: 2,
    priceCategory: 'Budget',
    origin: 'North America',
    characteristics: [
      'Very affordable',
      'Rustic character',
      'Easy to work with',
      'Develops patina',
      'Shows wear beautifully'
    ],
    bestFor: ['Rustic homes', 'Cabins', 'Country style', 'Budget projects'],
    category: 'Softwood'
  },
  {
    id: 'douglas-fir',
    name: 'Douglas Fir',
    scientificName: 'Pseudotsuga menziesii',
    image: 'https://images.unsplash.com/photo-1681457551985-a606d11ea7fa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaW5lJTIwd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzYzNnww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Stronger softwood with attractive grain. Popular for craftsman-style homes.',
    hardness: 660,
    colorRange: 'Light tan to reddish brown',
    grainPattern: 'Straight grain with prominent growth rings',
    durability: 2,
    priceCategory: 'Budget',
    origin: 'Pacific Northwest',
    characteristics: [
      'Affordable',
      'Strong for a softwood',
      'Attractive grain',
      'Craftsman appeal',
      'Develops character'
    ],
    bestFor: ['Craftsman homes', 'Rustic interiors', 'Historic renovations', 'Budget floors'],
    category: 'Softwood'
  },

  // Bamboo
  {
    id: 'bamboo',
    name: 'Bamboo',
    scientificName: 'Bambusoideae',
    image: 'https://images.unsplash.com/photo-1686887907058-aad594d4ce01?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYW1ib28lMjBmbG9vcmluZ3xlbnwxfHx8fDE3NjYwMTM2MzV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Sustainable grass that performs like hardwood. Eco-friendly and rapidly renewable.',
    hardness: 1380,
    colorRange: 'Natural blonde to carbonized brown',
    grainPattern: 'Linear with characteristic bamboo nodes',
    durability: 4,
    priceCategory: 'Mid-Range',
    origin: 'Asia',
    characteristics: [
      'Highly sustainable',
      'Rapidly renewable',
      'Hard and durable',
      'Unique appearance',
      'Eco-friendly choice'
    ],
    bestFor: ['Green homes', 'Modern interiors', 'Eco-conscious buyers', 'Contemporary spaces'],
    category: 'Bamboo'
  }
];

// Helper functions
export function getSpeciesByCategory(category: string): WoodSpecies[] {
  return woodSpecies.filter(species => species.category === category);
}

export function getSpeciesByPriceCategory(priceCategory: string): WoodSpecies[] {
  return woodSpecies.filter(species => species.priceCategory === priceCategory);
}

export function getAllCategories(): string[] {
  return Array.from(new Set(woodSpecies.map(s => s.category)));
}

export function getAllPriceCategories(): string[] {
  return ['Budget', 'Mid-Range', 'Premium', 'Luxury'];
}
