export interface EpoxyStyle {
  id: string;
  name: string;
  description: string;
  image: string;
  priceCategory: 'Budget' | 'Mid-Range' | 'Premium' | 'Luxury';
  characteristics: string[];
  bestFor: string[];
  applications: string[];
}

export interface EpoxyFinish {
  id: string;
  name: string;
  description: string;
  appearance: string;
  slipResistance: 'Low' | 'Medium' | 'High';
  priceImpact: string;
}

export interface EpoxyColor {
  id: string;
  name: string;
  hexCode: string;
  category: 'Neutral' | 'Bold' | 'Metallic' | 'Custom';
  description: string;
}

export interface EpoxyThickness {
  id: string;
  name: string;
  thickness: string;
  description: string;
  durability: 1 | 2 | 3 | 4 | 5;
  bestFor: string[];
  priceCategory: 'Standard' | 'Premium' | 'Heavy-Duty';
}

export interface EpoxyAdditive {
  id: string;
  name: string;
  description: string;
  visualEffect: string;
  priceImpact: string;
  image: string;
}

export const epoxyStyles: EpoxyStyle[] = [
  {
    id: 'solid-color',
    name: 'Solid Color',
    description: 'Clean, uniform color throughout with a glossy finish. The classic epoxy look.',
    image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=600&q=80',
    priceCategory: 'Budget',
    characteristics: [
      'Uniform color',
      'Seamless finish',
      'Easy to clean',
      'Professional appearance'
    ],
    bestFor: ['Garages', 'Warehouses', 'Simple commercial spaces'],
    applications: ['Residential garages', 'Workshops', 'Storage areas']
  },
  {
    id: 'metallic',
    name: 'Metallic Epoxy',
    description: 'Creates stunning swirls and waves with metallic pigments for a unique, high-end look.',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&q=80',
    priceCategory: 'Premium',
    characteristics: [
      'Unique patterns',
      'Metallic shimmer',
      '3D visual depth',
      'No two floors alike'
    ],
    bestFor: ['Showrooms', 'Retail spaces', 'Modern homes', 'Luxury basements'],
    applications: ['Commercial showrooms', 'Residential living spaces', 'Boutique shops']
  },
  {
    id: 'flake',
    name: 'Decorative Flake',
    description: 'Color chips broadcast into the epoxy base for texture, slip resistance, and visual interest.',
    image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=600&q=80',
    priceCategory: 'Mid-Range',
    characteristics: [
      'Textured surface',
      'Excellent slip resistance',
      'Hides imperfections',
      'Durable finish'
    ],
    bestFor: ['Garages', 'Basements', 'Commercial kitchens', 'Workshops'],
    applications: ['Garage floors', 'Industrial spaces', 'Patios']
  },
  {
    id: 'quartz',
    name: 'Quartz Epoxy',
    description: 'Colored quartz granules mixed into epoxy for maximum durability and texture.',
    image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=600&q=80',
    priceCategory: 'Premium',
    characteristics: [
      'Maximum durability',
      'Heavy texture',
      'Superior slip resistance',
      'Industrial strength'
    ],
    bestFor: ['Commercial kitchens', 'Manufacturing', 'High-traffic areas'],
    applications: ['Food processing', 'Healthcare facilities', 'Industrial floors']
  },
  {
    id: 'terrazzo',
    name: 'Epoxy Terrazzo',
    description: 'Marble or glass chips embedded in epoxy, polished to a smooth finish for a luxurious look.',
    image: 'https://images.unsplash.com/photo-1615876234886-fd9a39fda97f?w=600&q=80',
    priceCategory: 'Luxury',
    characteristics: [
      'Elegant appearance',
      'Custom chip selection',
      'Polished finish',
      'Timeless design'
    ],
    bestFor: ['Lobbies', 'Upscale retail', 'Luxury homes', 'Hotels'],
    applications: ['High-end commercial', 'Luxury residential', 'Museums']
  },
  {
    id: 'marbled',
    name: 'Marbled Effect',
    description: 'Multiple colors swirled together to create a natural marble appearance.',
    image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=600&q=80',
    priceCategory: 'Premium',
    characteristics: [
      'Marble-like patterns',
      'Multi-color design',
      'Elegant appearance',
      'Customizable colors'
    ],
    bestFor: ['Offices', 'Retail spaces', 'Modern homes', 'Showrooms'],
    applications: ['Commercial spaces', 'Residential living areas', 'Lobbies']
  }
];

export const epoxyFinishes: EpoxyFinish[] = [
  {
    id: 'high-gloss',
    name: 'High Gloss',
    description: 'Mirror-like shine that reflects light beautifully. The most popular choice.',
    appearance: 'Very reflective, wet look',
    slipResistance: 'Low',
    priceImpact: 'Standard'
  },
  {
    id: 'semi-gloss',
    name: 'Semi-Gloss (Satin)',
    description: 'Moderate shine with a softer appearance. Balances aesthetics and slip resistance.',
    appearance: 'Subtle shine, less reflective',
    slipResistance: 'Medium',
    priceImpact: 'Standard'
  },
  {
    id: 'matte',
    name: 'Matte',
    description: 'No shine, contemporary look. Best slip resistance.',
    appearance: 'Flat finish, no reflection',
    slipResistance: 'High',
    priceImpact: '+$0.50-$1/sqft'
  },
  {
    id: 'textured',
    name: 'Textured Non-Slip',
    description: 'Added grit for maximum traction. Essential for wet areas.',
    appearance: 'Slightly rough surface',
    slipResistance: 'High',
    priceImpact: '+$1-$2/sqft'
  }
];

export const epoxyColors: EpoxyColor[] = [
  // Neutrals
  { id: 'gray', name: 'Classic Gray', hexCode: '#808080', category: 'Neutral', description: 'Most popular garage color' },
  { id: 'light-gray', name: 'Light Gray', hexCode: '#D3D3D3', category: 'Neutral', description: 'Bright and modern' },
  { id: 'dark-gray', name: 'Dark Gray', hexCode: '#404040', category: 'Neutral', description: 'Sophisticated and sleek' },
  { id: 'beige', name: 'Beige', hexCode: '#C8B88A', category: 'Neutral', description: 'Warm and inviting' },
  { id: 'white', name: 'Bright White', hexCode: '#F5F5F5', category: 'Neutral', description: 'Clean and pristine' },
  { id: 'black', name: 'Black', hexCode: '#1C1C1C', category: 'Neutral', description: 'Bold and dramatic' },
  { id: 'tan', name: 'Tan', hexCode: '#D2B48C', category: 'Neutral', description: 'Natural and warm' },
  
  // Bold Colors
  { id: 'red', name: 'Racing Red', hexCode: '#C41E3A', category: 'Bold', description: 'High energy and bold' },
  { id: 'blue', name: 'Ocean Blue', hexCode: '#0077BE', category: 'Bold', description: 'Cool and calming' },
  { id: 'green', name: 'Forest Green', hexCode: '#228B22', category: 'Bold', description: 'Natural and vibrant' },
  { id: 'yellow', name: 'Safety Yellow', hexCode: '#FFD700', category: 'Bold', description: 'Bright and visible' },
  { id: 'orange', name: 'Tangerine Orange', hexCode: '#FF8C00', category: 'Bold', description: 'Energetic and warm' },
  
  // Metallic
  { id: 'silver', name: 'Silver Metallic', hexCode: '#C0C0C0', category: 'Metallic', description: 'Sleek and modern shimmer' },
  { id: 'gold', name: 'Gold Metallic', hexCode: '#D4AF37', category: 'Metallic', description: 'Luxurious and warm' },
  { id: 'bronze', name: 'Bronze Metallic', hexCode: '#CD7F32', category: 'Metallic', description: 'Rich and elegant' },
  { id: 'copper', name: 'Copper Metallic', hexCode: '#B87333', category: 'Metallic', description: 'Warm industrial look' },
  { id: 'pearl', name: 'Pearl White', hexCode: '#F0EAD6', category: 'Metallic', description: 'Subtle iridescence' },
  
  // Custom
  { id: 'custom', name: 'Custom Color Match', hexCode: '#000000', category: 'Custom', description: 'Match any color you want' }
];

export const epoxyThicknesses: EpoxyThickness[] = [
  {
    id: 'thin-coat',
    name: 'Thin Coat (2-3 mils)',
    thickness: '2-3 mils',
    description: 'Basic protection and aesthetics for light-duty residential use.',
    durability: 2,
    bestFor: ['Light foot traffic', 'Residential basements', 'Low-use areas'],
    priceCategory: 'Standard'
  },
  {
    id: 'standard',
    name: 'Standard (10-15 mils)',
    thickness: '10-15 mils',
    description: 'Most common residential application. Good durability and appearance.',
    durability: 3,
    bestFor: ['Residential garages', 'Home workshops', 'Light commercial'],
    priceCategory: 'Standard'
  },
  {
    id: 'heavy-duty',
    name: 'Heavy-Duty (20-40 mils)',
    thickness: '20-40 mils',
    description: 'Enhanced durability for high-traffic and commercial applications.',
    durability: 4,
    bestFor: ['Commercial garages', 'Warehouses', 'Heavy equipment areas'],
    priceCategory: 'Premium'
  },
  {
    id: 'industrial',
    name: 'Industrial Grade (40+ mils)',
    thickness: '40-125 mils',
    description: 'Maximum protection for the harshest environments and heaviest use.',
    durability: 5,
    bestFor: ['Manufacturing floors', 'Heavy machinery areas', 'Chemical plants'],
    priceCategory: 'Heavy-Duty'
  }
];

export const epoxyAdditives: EpoxyAdditive[] = [
  {
    id: 'no-additive',
    name: 'None',
    description: 'Clean, solid color epoxy without decorative elements.',
    visualEffect: 'Smooth, uniform appearance',
    priceImpact: 'Base price',
    image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=400&q=80'
  },
  {
    id: 'small-flakes',
    name: 'Small Decorative Flakes',
    description: '1/8" color chips for subtle texture and visual interest.',
    visualEffect: 'Speckled appearance, light texture',
    priceImpact: '+$0.50-$1.50/sqft',
    image: 'https://images.unsplash.com/photo-1615875474908-f403090aec24?w=400&q=80'
  },
  {
    id: 'large-flakes',
    name: 'Large Decorative Flakes',
    description: '1/4" color chips for maximum coverage and texture.',
    visualEffect: 'Full broadcast look, moderate texture',
    priceImpact: '+$1-$2/sqft',
    image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=400&q=80'
  },
  {
    id: 'metallic-pigment',
    name: 'Metallic Pigments',
    description: 'Special metallic additives that create flowing, marbled effects.',
    visualEffect: '3D waves and swirls, unique patterns',
    priceImpact: '+$2-$4/sqft',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=400&q=80'
  },
  {
    id: 'quartz-sand',
    name: 'Quartz Sand',
    description: 'Fine quartz particles for slip resistance and durability.',
    visualEffect: 'Subtle texture, slightly rougher surface',
    priceImpact: '+$1.50-$2.50/sqft',
    image: 'https://images.unsplash.com/photo-1615876234886-fd9a39fda97f?w=400&q=80'
  },
  {
    id: 'glitter',
    name: 'Glitter/Sparkle',
    description: 'Reflective glitter particles for a glamorous, eye-catching look.',
    visualEffect: 'Sparkly, reflective surface',
    priceImpact: '+$0.75-$1.50/sqft',
    image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=400&q=80'
  }
];

export const epoxyApplications = [
  'Residential Garage',
  'Commercial Garage/Parking',
  'Basement',
  'Workshop',
  'Warehouse',
  'Retail Store',
  'Showroom',
  'Restaurant Kitchen',
  'Laboratory',
  'Manufacturing Facility',
  'Gym/Fitness Center',
  'Aircraft Hangar',
  'Auto Dealership',
  'Hospital/Healthcare',
  'School/University'
];

export const epoxyBenefits = [
  {
    title: 'Extreme Durability',
    description: 'Withstands heavy impacts, chemicals, and abrasion better than most flooring options.',
    icon: '🛡️'
  },
  {
    title: 'Easy Maintenance',
    description: 'Seamless surface means no grout lines or seams to clean. Just sweep and mop.',
    icon: '🧹'
  },
  {
    title: 'Chemical Resistant',
    description: 'Stands up to oils, gasoline, bleach, transmission fluid, and most household chemicals.',
    icon: '⚗️'
  },
  {
    title: 'Moisture Barrier',
    description: 'Prevents moisture from seeping through concrete, protecting your foundation.',
    icon: '💧'
  },
  {
    title: 'Bright & Reflective',
    description: 'Glossy finish reflects light, making spaces appear larger and brighter.',
    icon: '✨'
  },
  {
    title: 'Long Lasting',
    description: 'With proper installation and care, can last 10-30+ years.',
    icon: '⏳'
  }
];
