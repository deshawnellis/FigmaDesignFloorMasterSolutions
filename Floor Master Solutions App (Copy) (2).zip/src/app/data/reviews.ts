export interface Review {
  id: string;
  contractorId: string;
  customerId: string;
  customerName: string;
  customerInitials: string;
  jobId: string;
  jobTitle: string;
  rating: 1 | 2 | 3 | 4 | 5;
  comment: string;
  date: string;
  verified: boolean;
  postedToGoogle: boolean;
  response?: {
    text: string;
    date: string;
  };
  categories: {
    quality: number;
    punctuality: number;
    professionalism: number;
    cleanliness: number;
    value: number;
  };
}

export const reviews: Review[] = [
  {
    id: '1',
    contractorId: 'contractor-1',
    customerId: 'customer-1',
    customerName: 'Sarah Johnson',
    customerInitials: 'SJ',
    jobId: 'job-15',
    jobTitle: 'Open Concept Living Space Hardwood',
    rating: 5,
    comment: 'Absolutely amazing work! The team was professional, punctual, and the Brazilian cherry hardwood looks stunning. They protected all our furniture and cleaned up perfectly. Highly recommend Premier Flooring!',
    date: '2025-12-16',
    verified: true,
    postedToGoogle: true,
    response: {
      text: 'Thank you so much Sarah! It was a pleasure working on your beautiful home. Enjoy your new floors!',
      date: '2025-12-16'
    },
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 5,
      value: 5
    }
  },
  {
    id: '2',
    contractorId: 'contractor-1',
    customerId: 'customer-2',
    customerName: 'Michael Chen',
    customerInitials: 'MC',
    jobId: 'job-14',
    jobTitle: 'Master Bath Heated Tile Floor',
    rating: 5,
    comment: 'The heated tile floor in our master bathroom is a game changer! The installation was flawless and the team was incredibly knowledgeable about the radiant heating system. Worth every penny.',
    date: '2025-12-14',
    verified: true,
    postedToGoogle: true,
    response: {
      text: 'We appreciate your kind words, Michael! Enjoy those warm mornings!',
      date: '2025-12-14'
    },
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 4,
      value: 5
    }
  },
  {
    id: '3',
    contractorId: 'contractor-1',
    customerId: 'customer-3',
    customerName: 'Emily Rodriguez',
    customerInitials: 'ER',
    jobId: 'job-13',
    jobTitle: 'Kitchen and Hallway LVP Installation',
    rating: 5,
    comment: 'Premier Flooring transformed our kitchen! The luxury vinyl plank looks like real wood and is so easy to maintain. The crew was respectful of our home and completed everything on schedule.',
    date: '2025-12-11',
    verified: true,
    postedToGoogle: true,
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 5,
      value: 4
    }
  },
  {
    id: '4',
    contractorId: 'contractor-1',
    customerId: 'customer-4',
    customerName: 'David Kim',
    customerInitials: 'DK',
    jobId: 'job-12',
    jobTitle: 'Bedroom Suite Carpet Installation',
    rating: 4,
    comment: 'Great quality carpet and installation. The only reason for 4 stars instead of 5 is they were about an hour late on the first day, but they made up for it by staying late to finish. Overall very satisfied!',
    date: '2025-12-09',
    verified: true,
    postedToGoogle: true,
    response: {
      text: "Thank you for your feedback, David. We apologize for the delay on day one and appreciate your understanding. We're glad you love the carpet!",
      date: '2025-12-10'
    },
    categories: {
      quality: 5,
      punctuality: 3,
      professionalism: 4,
      cleanliness: 5,
      value: 4
    }
  },
  {
    id: '5',
    contractorId: 'contractor-1',
    customerId: 'customer-5',
    customerName: 'Jennifer Williams',
    customerInitials: 'JW',
    jobId: 'job-11',
    jobTitle: 'Hardwood Refinishing',
    rating: 5,
    comment: 'They brought our 50-year-old oak floors back to life! The refinishing job is absolutely beautiful. Very happy we chose to restore rather than replace.',
    date: '2025-12-07',
    verified: true,
    postedToGoogle: true,
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 4,
      value: 5
    }
  },
  {
    id: '6',
    contractorId: 'contractor-1',
    customerId: 'customer-6',
    customerName: 'Robert Taylor',
    customerInitials: 'RT',
    jobId: 'job-10',
    jobTitle: 'Basement LVP Installation',
    rating: 5,
    comment: 'Excellent work on our basement renovation. The waterproof vinyl plank was the perfect choice and the installation is perfect. No issues at all!',
    date: '2025-12-05',
    verified: true,
    postedToGoogle: true,
    response: {
      text: 'Thanks Robert! Enjoy your new basement space!',
      date: '2025-12-05'
    },
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 5,
      value: 5
    }
  },
  {
    id: '7',
    contractorId: 'contractor-1',
    customerId: 'customer-7',
    customerName: 'Amanda Martinez',
    customerInitials: 'AM',
    jobId: 'job-9',
    jobTitle: 'Living Room and Dining Room Hardwood',
    rating: 5,
    comment: 'Beautiful craftsmanship! Our white oak floors are stunning and really opened up our space. The team was wonderful to work with.',
    date: '2025-12-03',
    verified: true,
    postedToGoogle: true,
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 5,
      value: 4
    }
  },
  {
    id: '8',
    contractorId: 'contractor-1',
    customerId: 'customer-8',
    customerName: 'Christopher Lee',
    customerInitials: 'CL',
    jobId: 'job-8',
    jobTitle: 'Office Carpet Tiles',
    rating: 4,
    comment: 'Professional installation of carpet tiles in our home office. Looks great and very functional. Appreciated the detailed estimate.',
    date: '2025-12-01',
    verified: true,
    postedToGoogle: true,
    categories: {
      quality: 4,
      punctuality: 4,
      professionalism: 5,
      cleanliness: 4,
      value: 4
    }
  },
  {
    id: '9',
    contractorId: 'contractor-1',
    customerId: 'customer-9',
    customerName: 'Jessica Anderson',
    customerInitials: 'JA',
    jobId: 'job-7',
    jobTitle: 'Nursery Soft Carpet',
    rating: 5,
    comment: 'Perfect for our baby\'s room! Soft, safe, and hypoallergenic just like we requested. The installer was so careful and respectful. Thank you!',
    date: '2025-11-28',
    verified: true,
    postedToGoogle: true,
    response: {
      text: 'Congratulations on your new addition! We\'re so happy we could help create a safe, cozy space.',
      date: '2025-11-28'
    },
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 5,
      value: 5
    }
  },
  {
    id: '10',
    contractorId: 'contractor-1',
    customerId: 'customer-10',
    customerName: 'Thomas Wilson',
    customerInitials: 'TW',
    jobId: 'job-6',
    jobTitle: 'Historic Home Hardwood Restoration',
    rating: 5,
    comment: 'Incredible restoration of our 1920s home original hardwood. They treated our historic home with care and respect. True craftsmen!',
    date: '2025-11-25',
    verified: true,
    postedToGoogle: true,
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 5,
      value: 4
    }
  },
  {
    id: '11',
    contractorId: 'contractor-1',
    customerId: 'customer-11',
    customerName: 'Michelle Davis',
    customerInitials: 'MD',
    jobId: 'job-5',
    jobTitle: 'Kitchen Tile Backsplash and Floor',
    rating: 5,
    comment: 'Gorgeous tile work! The pattern they created is exactly what I envisioned. Clean, professional, and finished on time.',
    date: '2025-11-22',
    verified: true,
    postedToGoogle: true,
    response: {
      text: 'Thank you Michelle! Your design vision really came together beautifully.',
      date: '2025-11-22'
    },
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 5,
      value: 5
    }
  },
  {
    id: '12',
    contractorId: 'contractor-1',
    customerId: 'customer-12',
    customerName: 'Kevin White',
    customerInitials: 'KW',
    jobId: 'job-4',
    jobTitle: 'Garage Epoxy Flooring',
    rating: 4,
    comment: 'Solid epoxy floor installation. Looks professional and should hold up well. Good communication throughout the process.',
    date: '2025-11-19',
    verified: true,
    postedToGoogle: true,
    categories: {
      quality: 4,
      punctuality: 4,
      professionalism: 5,
      cleanliness: 4,
      value: 4
    }
  },
  {
    id: '13',
    contractorId: 'contractor-1',
    customerId: 'customer-13',
    customerName: 'Lisa Thompson',
    customerInitials: 'LT',
    jobId: 'job-3',
    jobTitle: 'Entire First Floor Hardwood',
    rating: 5,
    comment: 'We couldn\'t be happier with our new floors! The entire first floor looks amazing and the team was so easy to work with. Best investment we\'ve made in our home!',
    date: '2025-11-16',
    verified: true,
    postedToGoogle: true,
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 5,
      value: 5
    }
  },
  {
    id: '14',
    contractorId: 'contractor-1',
    customerId: 'customer-14',
    customerName: 'Daniel Garcia',
    customerInitials: 'DG',
    jobId: 'job-2',
    jobTitle: 'Sunroom Tile Installation',
    rating: 5,
    comment: 'Beautiful tile work in our sunroom. Attention to detail was impressive and they worked around our schedule. Highly recommend!',
    date: '2025-11-13',
    verified: true,
    postedToGoogle: true,
    response: {
      text: 'Thanks Daniel! Enjoy your beautiful sunroom!',
      date: '2025-11-13'
    },
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 4,
      value: 5
    }
  },
  {
    id: '15',
    contractorId: 'contractor-1',
    customerId: 'customer-15',
    customerName: 'Patricia Brown',
    customerInitials: 'PB',
    jobId: 'job-1',
    jobTitle: 'Bathroom Remodel Tile',
    rating: 5,
    comment: 'Exceptional tile installation! Our bathroom looks like a luxury spa now. The installers were meticulous and professional.',
    date: '2025-11-10',
    verified: true,
    postedToGoogle: true,
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 5,
      value: 4
    }
  },
  {
    id: '16',
    contractorId: 'contractor-1',
    customerId: 'customer-16',
    customerName: 'Mark Jackson',
    customerInitials: 'MJ',
    jobId: 'job-16',
    jobTitle: 'Staircase Hardwood Installation',
    rating: 5,
    comment: 'The staircase turned out beautifully! Complex job done with precision. Very impressed with the skill and professionalism.',
    date: '2025-11-07',
    verified: true,
    postedToGoogle: true,
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 5,
      value: 4
    }
  },
  {
    id: '17',
    contractorId: 'contractor-1',
    customerId: 'customer-17',
    customerName: 'Angela Robinson',
    customerInitials: 'AR',
    jobId: 'job-17',
    jobTitle: 'Bedroom Suite Plush Carpet',
    rating: 4,
    comment: 'Love the new carpet! Soft and luxurious. Installation went well though they had to reschedule once due to material delay.',
    date: '2025-11-04',
    verified: true,
    postedToGoogle: true,
    response: {
      text: 'Thank you Angela! We apologize for the material delay and appreciate your patience.',
      date: '2025-11-05'
    },
    categories: {
      quality: 5,
      punctuality: 3,
      professionalism: 5,
      cleanliness: 5,
      value: 4
    }
  },
  {
    id: '18',
    contractorId: 'contractor-1',
    customerId: 'customer-18',
    customerName: 'Steven Martinez',
    customerInitials: 'SM',
    jobId: 'job-18',
    jobTitle: 'Dining Room Bamboo Flooring',
    rating: 5,
    comment: 'Eco-friendly bamboo floors look fantastic! Great sustainable option and the installation was perfect. Very happy with our choice.',
    date: '2025-11-01',
    verified: true,
    postedToGoogle: true,
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 5,
      value: 5
    }
  },
  {
    id: '19',
    contractorId: 'contractor-1',
    customerId: 'customer-19',
    customerName: 'Rachel Green',
    customerInitials: 'RG',
    jobId: 'job-19',
    jobTitle: 'Game Room Cork Flooring',
    rating: 5,
    comment: 'Perfect for our game room! The soundproofing is amazing and the kids love it. Unique flooring choice that really works!',
    date: '2025-10-28',
    verified: true,
    postedToGoogle: true,
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 4,
      value: 5
    }
  },
  {
    id: '20',
    contractorId: 'contractor-1',
    customerId: 'customer-20',
    customerName: 'James Miller',
    customerInitials: 'JM',
    jobId: 'job-20',
    jobTitle: 'Commercial Office LVP',
    rating: 5,
    comment: 'Professional installation for our office space. Minimal disruption to business and excellent quality. Would hire again!',
    date: '2025-10-25',
    verified: true,
    postedToGoogle: true,
    response: {
      text: 'Thank you James! We appreciate your business and are glad we could minimize disruption.',
      date: '2025-10-25'
    },
    categories: {
      quality: 5,
      punctuality: 5,
      professionalism: 5,
      cleanliness: 5,
      value: 4
    }
  }
];

export const getAverageRating = (contractorId: string): number => {
  const contractorReviews = reviews.filter(r => r.contractorId === contractorId);
  if (contractorReviews.length === 0) return 0;
  const sum = contractorReviews.reduce((acc, review) => acc + review.rating, 0);
  return sum / contractorReviews.length;
};

export const getRatingDistribution = (contractorId: string) => {
  const contractorReviews = reviews.filter(r => r.contractorId === contractorId);
  return {
    5: contractorReviews.filter(r => r.rating === 5).length,
    4: contractorReviews.filter(r => r.rating === 4).length,
    3: contractorReviews.filter(r => r.rating === 3).length,
    2: contractorReviews.filter(r => r.rating === 2).length,
    1: contractorReviews.filter(r => r.rating === 1).length,
  };
};

export const getCategoryAverages = (contractorId: string) => {
  const contractorReviews = reviews.filter(r => r.contractorId === contractorId);
  if (contractorReviews.length === 0) {
    return {
      quality: 0,
      punctuality: 0,
      professionalism: 0,
      cleanliness: 0,
      value: 0
    };
  }

  const totals = contractorReviews.reduce((acc, review) => {
    return {
      quality: acc.quality + review.categories.quality,
      punctuality: acc.punctuality + review.categories.punctuality,
      professionalism: acc.professionalism + review.categories.professionalism,
      cleanliness: acc.cleanliness + review.categories.cleanliness,
      value: acc.value + review.categories.value
    };
  }, { quality: 0, punctuality: 0, professionalism: 0, cleanliness: 0, value: 0 });

  return {
    quality: totals.quality / contractorReviews.length,
    punctuality: totals.punctuality / contractorReviews.length,
    professionalism: totals.professionalism / contractorReviews.length,
    cleanliness: totals.cleanliness / contractorReviews.length,
    value: totals.value / contractorReviews.length
  };
};