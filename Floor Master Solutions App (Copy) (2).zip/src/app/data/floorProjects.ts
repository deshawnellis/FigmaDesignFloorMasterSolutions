export interface FloorProject {
  id: string;
  userId: string;
  userName: string;
  status: 'designing' | 'visualizing' | 'shared' | 'quoted';
  createdDate: string;
  updatedDate: string;
  
  // Room Information
  roomType: string;
  roomDimensions?: {
    length: number;
    width: number;
    unit: 'ft' | 'm';
  };
  squareFootage?: number;
  
  // Flooring Selection
  flooringType: 'hardwood' | 'carpet' | 'tile' | 'lvp' | 'laminate';
  
  // Hardwood Details
  hardwood?: {
    species: string;
    grade: string;
    width: string;
    finish: string;
    color: string;
    installation: string;
  };
  
  // Carpet Details
  carpet?: {
    style: string;
    fiber: string;
    color: string;
    padding: string;
    texture: string;
  };
  
  // Tile Details
  tile?: {
    material: string;
    size: string;
    color: string;
    finish: string;
    pattern: string;
    groutColor?: string;
  };
  
  // Visual Design
  roomPhoto?: string; // base64 or URL
  visualizedDesign?: string; // base64 or URL of the floor applied to photo
  
  // Contractor Interaction
  sharedWith?: string[]; // contractor IDs
  findingContractors?: boolean;
  quotes?: {
    contractorId: string;
    amount: number;
    message: string;
    date: string;
  }[];
  
  // Additional Notes
  notes?: string;
  budget?: {
    min: number;
    max: number;
  };
}

export const floorProjects: FloorProject[] = [
  {
    id: 'project-1',
    userId: 'user-1',
    userName: 'Sarah Johnson',
    status: 'quoted',
    createdDate: '2025-12-10',
    updatedDate: '2025-12-15',
    roomType: 'Living Room',
    squareFootage: 350,
    flooringType: 'hardwood',
    hardwood: {
      species: 'White Oak',
      grade: 'Select',
      width: '5 inches',
      finish: 'Matte',
      color: 'Natural',
      installation: 'Nail Down'
    },
    roomPhoto: 'data:image/placeholder',
    visualizedDesign: 'data:image/placeholder',
    sharedWith: ['contractor-1'],
    quotes: [
      {
        contractorId: 'contractor-1',
        amount: 4200,
        message: 'Beautiful choice! White oak will look stunning in your living room. Price includes materials, installation, and finishing.',
        date: '2025-12-15'
      }
    ],
    notes: 'Looking for a warm, natural look that complements our modern furniture',
    budget: {
      min: 3500,
      max: 5000
    }
  },
  {
    id: 'project-2',
    userId: 'user-2',
    userName: 'Michael Chen',
    status: 'shared',
    createdDate: '2025-12-14',
    updatedDate: '2025-12-16',
    roomType: 'Kitchen',
    squareFootage: 200,
    flooringType: 'tile',
    tile: {
      material: 'Porcelain',
      size: '12x24 inches',
      color: 'Light Gray',
      finish: 'Matte',
      pattern: 'Herringbone',
      groutColor: 'Warm Gray'
    },
    roomPhoto: 'data:image/placeholder',
    visualizedDesign: 'data:image/placeholder',
    findingContractors: true,
    notes: 'Need waterproof and easy to clean. Kitchen gets a lot of use!',
    budget: {
      min: 2000,
      max: 3500
    }
  },
  {
    id: 'project-3',
    userId: 'user-3',
    userName: 'Emily Rodriguez',
    status: 'visualizing',
    createdDate: '2025-12-16',
    updatedDate: '2025-12-17',
    roomType: 'Bedroom',
    squareFootage: 280,
    flooringType: 'carpet',
    carpet: {
      style: 'Plush',
      fiber: 'Nylon',
      color: 'Soft Beige',
      padding: '8lb Rebond',
      texture: 'Soft & Luxurious'
    },
    roomPhoto: 'data:image/placeholder',
    notes: 'Want something cozy and comfortable underfoot',
    budget: {
      min: 1500,
      max: 2500
    }
  },
  {
    id: 'project-4',
    userId: 'user-1',
    userName: 'Sarah Johnson',
    status: 'designing',
    createdDate: '2025-12-17',
    updatedDate: '2025-12-17',
    roomType: 'Master Bedroom',
    squareFootage: 320,
    flooringType: 'hardwood',
    hardwood: {
      species: 'Brazilian Cherry',
      grade: 'Clear',
      width: '3.5 inches',
      finish: 'Semi-Gloss',
      color: 'Rich Brown',
      installation: 'Glue Down'
    },
    notes: 'Want rich, elegant look to match our furniture',
    budget: {
      min: 4000,
      max: 6000
    }
  }
];

export const getProjectsByUser = (userId: string) => {
  return floorProjects.filter(p => p.userId === userId);
};

export const getProjectsSharedWithContractor = (contractorId: string) => {
  return floorProjects.filter(p => p.sharedWith?.includes(contractorId));
};

export const getProjectsLookingForContractors = () => {
  return floorProjects.filter(p => p.findingContractors);
};
