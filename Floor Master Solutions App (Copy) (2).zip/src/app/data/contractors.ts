export interface Contractor {
  id: string;
  name: string;
  businessName: string;
  rating: number;
  reviewCount: number;
  yearsExperience: number;
  serviceArea: string[];
  specialties: string[];
  image: string;
  verified: boolean;
  responseTime: string;
  completedProjects: number;
}

export const contractors: Contractor[] = [
  {
    id: '1',
    name: 'Mike Johnson',
    businessName: 'Premier Flooring Solutions',
    rating: 4.9,
    reviewCount: 127,
    yearsExperience: 15,
    serviceArea: ['San Francisco', 'Oakland', 'San Jose'],
    specialties: ['Hardwood', 'LVP', 'Tile'],
    image: 'https://images.unsplash.com/photo-1751054571128-30d45eccbe42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb250cmFjdG9yJTIwY29uc3RydWN0aW9uJTIwd29ya2VyfGVufDF8fHx8MTc2NTk3OTc3N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    verified: true,
    responseTime: 'Within 2 hours',
    completedProjects: 340
  },
  {
    id: '2',
    name: 'Sarah Martinez',
    businessName: 'Elite Floors & Design',
    rating: 4.8,
    reviewCount: 94,
    yearsExperience: 12,
    serviceArea: ['San Francisco', 'Daly City', 'Pacifica'],
    specialties: ['Hardwood', 'Engineered Wood', 'Laminate'],
    image: 'https://images.unsplash.com/photo-1751054571128-30d45eccbe42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb250cmFjdG9yJTIwY29uc3RydWN0aW9uJTIwd29ya2VyfGVufDF8fHx8MTc2NTk3OTc3N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    verified: true,
    responseTime: 'Within 4 hours',
    completedProjects: 215
  },
  {
    id: '3',
    name: 'David Chen',
    businessName: 'Bay Area Tile & Flooring',
    rating: 4.7,
    reviewCount: 86,
    yearsExperience: 18,
    serviceArea: ['Oakland', 'Berkeley', 'Alameda'],
    specialties: ['Tile', 'LVP', 'Carpet'],
    image: 'https://images.unsplash.com/photo-1751054571128-30d45eccbe42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb250cmFjdG9yJTIwY29uc3RydWN0aW9uJTIwd29ya2VyfGVufDF8fHx8MTc2NTk3OTc3N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    verified: true,
    responseTime: 'Within 3 hours',
    completedProjects: 402
  },
  {
    id: '4',
    name: 'Jennifer Williams',
    businessName: 'Classic Hardwood Specialists',
    rating: 5.0,
    reviewCount: 63,
    yearsExperience: 10,
    serviceArea: ['San Jose', 'Santa Clara', 'Sunnyvale'],
    specialties: ['Hardwood', 'Engineered Wood', 'Refinishing'],
    image: 'https://images.unsplash.com/photo-1751054571128-30d45eccbe42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb250cmFjdG9yJTIwY29uc3RydWN0aW9uJTIwd29ya2VyfGVufDF8fHx8MTc2NTk3OTc3N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    verified: true,
    responseTime: 'Within 1 hour',
    completedProjects: 178
  },
  {
    id: '5',
    name: 'Robert Thompson',
    businessName: 'All Floors Pro',
    rating: 4.6,
    reviewCount: 112,
    yearsExperience: 20,
    serviceArea: ['San Francisco', 'Oakland', 'Berkeley', 'San Jose'],
    specialties: ['All Flooring Types'],
    image: 'https://images.unsplash.com/photo-1751054571128-30d45eccbe42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb250cmFjdG9yJTIwY29uc3RydWN0aW9uJTIwd29ya2VyfGVufDF8fHx8MTc2NTk3OTc3N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    verified: true,
    responseTime: 'Within 6 hours',
    completedProjects: 521
  }
];
