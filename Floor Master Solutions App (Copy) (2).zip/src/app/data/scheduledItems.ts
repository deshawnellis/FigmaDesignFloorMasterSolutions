export interface ScheduledItem {
  id: string;
  type: 'estimate' | 'job' | 'consultation';
  title: string;
  client: string;
  date: string;
  time: string;
  status: 'scheduled' | 'in-progress' | 'completed' | 'cancelled';
  location: string;
  notes?: string;
  value?: string;
}

export const scheduledItems: ScheduledItem[] = [
  // Today's appointments
  {
    id: '1',
    type: 'estimate',
    title: 'Kitchen Hardwood Estimate',
    client: 'Sarah Johnson',
    date: '2025-12-18',
    time: '10:00',
    status: 'scheduled',
    location: '1234 Oak Street, San Francisco, CA 94102',
    notes: 'Client wants oak hardwood, approximately 300 sq ft',
    value: '$4,500'
  },
  {
    id: '2',
    type: 'job',
    title: 'Living Room Carpet Installation',
    client: 'Michael Chen',
    date: '2025-12-18',
    time: '14:00',
    status: 'in-progress',
    location: '5678 Pine Avenue, San Francisco, CA 94103',
    notes: 'Premium plush carpet, 450 sq ft, remove old carpet first',
    value: '$3,200'
  },

  // Tomorrow
  {
    id: '3',
    type: 'consultation',
    title: 'Whole House Flooring Consultation',
    client: 'Emily Rodriguez',
    date: '2025-12-19',
    time: '09:00',
    status: 'scheduled',
    location: '9012 Maple Drive, Oakland, CA 94601',
    notes: 'Looking at options for entire 2,000 sq ft home',
    value: '$15,000'
  },
  {
    id: '4',
    type: 'job',
    title: 'Bathroom Tile Installation',
    client: 'David Kim',
    date: '2025-12-19',
    time: '11:30',
    status: 'scheduled',
    location: '3456 Elm Court, Berkeley, CA 94704',
    notes: 'Porcelain tile, heated floor system installation',
    value: '$6,800'
  },

  // This week
  {
    id: '5',
    type: 'estimate',
    title: 'Office Vinyl Flooring Estimate',
    client: 'Tech Startup Inc.',
    date: '2025-12-20',
    time: '10:00',
    status: 'scheduled',
    location: '2000 Market Street, San Francisco, CA 94114',
    notes: 'Commercial space, 1,500 sq ft, waterproof vinyl plank',
    value: '$7,500'
  },
  {
    id: '6',
    type: 'job',
    title: 'Master Bedroom Hardwood Refinishing',
    client: 'Jennifer Williams',
    date: '2025-12-20',
    time: '13:00',
    status: 'scheduled',
    location: '7890 Birch Lane, San Mateo, CA 94401',
    notes: 'Sand and refinish existing oak hardwood, 400 sq ft',
    value: '$2,800'
  },
  {
    id: '7',
    type: 'estimate',
    title: 'Restaurant Kitchen Tile Estimate',
    client: 'Bella Italia Restaurant',
    date: '2025-12-21',
    time: '08:00',
    status: 'scheduled',
    location: '1500 Columbus Avenue, San Francisco, CA 94133',
    notes: 'Non-slip commercial grade tile, 800 sq ft',
    value: '$9,200'
  },
  {
    id: '8',
    type: 'consultation',
    title: 'Basement Finishing Consultation',
    client: 'Robert Taylor',
    date: '2025-12-21',
    time: '15:00',
    status: 'scheduled',
    location: '4321 Cedar Street, Palo Alto, CA 94301',
    notes: 'Converting basement to living space, moisture considerations',
    value: '$8,500'
  },

  // Next week
  {
    id: '9',
    type: 'job',
    title: 'Hallway Laminate Installation',
    client: 'Amanda Martinez',
    date: '2025-12-23',
    time: '09:30',
    status: 'scheduled',
    location: '6543 Redwood Road, San Jose, CA 95123',
    notes: 'Wood-look laminate, 200 sq ft hallway and entryway',
    value: '$1,800'
  },
  {
    id: '10',
    type: 'estimate',
    title: 'Staircase Hardwood Estimate',
    client: 'Christopher Lee',
    date: '2025-12-23',
    time: '14:00',
    status: 'scheduled',
    location: '8765 Willow Way, Fremont, CA 94536',
    notes: 'Hardwood stairs with custom railing, 14 steps',
    value: '$5,200'
  },
  {
    id: '11',
    type: 'job',
    title: 'Nursery Carpet Installation',
    client: 'Jessica & Brian Anderson',
    date: '2025-12-24',
    time: '10:00',
    status: 'scheduled',
    location: '2468 Spruce Avenue, Mountain View, CA 94040',
    notes: 'Soft, hypoallergenic carpet for baby room, 250 sq ft',
    value: '$2,200'
  },
  {
    id: '12',
    type: 'consultation',
    title: 'Multi-Unit Property Flooring',
    client: 'Bay Area Properties LLC',
    date: '2025-12-26',
    time: '11:00',
    status: 'scheduled',
    location: '5000 Mission Street, San Francisco, CA 94112',
    notes: 'Flooring for 6 rental units, budget options needed',
    value: '$25,000'
  },
  {
    id: '13',
    type: 'estimate',
    title: 'Sunroom Tile Estimate',
    client: 'Patricia Brown',
    date: '2025-12-27',
    time: '09:00',
    status: 'scheduled',
    location: '1357 Cypress Circle, Daly City, CA 94015',
    notes: 'Large format porcelain tile, radiant heat compatible',
    value: '$4,800'
  },
  {
    id: '14',
    type: 'job',
    title: 'Kitchen & Dining Luxury Vinyl Plank',
    client: 'Daniel Garcia',
    date: '2025-12-27',
    time: '13:30',
    status: 'scheduled',
    location: '9753 Aspen Street, Redwood City, CA 94063',
    notes: 'Waterproof LVP, 600 sq ft, remove old linoleum',
    value: '$4,200'
  },

  // Completed jobs
  {
    id: '15',
    type: 'job',
    title: 'Open Concept Living Space Hardwood',
    client: 'Lisa Thompson',
    date: '2025-12-15',
    time: '08:00',
    status: 'completed',
    location: '3692 Magnolia Drive, Sunnyvale, CA 94086',
    notes: 'Brazilian cherry hardwood, 850 sq ft',
    value: '$9,500'
  },
  {
    id: '16',
    type: 'estimate',
    title: 'Home Office Carpet Estimate',
    client: 'Kevin White',
    date: '2025-12-14',
    time: '14:00',
    status: 'completed',
    location: '7412 Juniper Lane, Santa Clara, CA 95050',
    notes: 'Low-pile commercial grade carpet for home office',
    value: '$1,600'
  },
  {
    id: '17',
    type: 'job',
    title: 'Master Bath Heated Tile Floor',
    client: 'Michelle Davis',
    date: '2025-12-13',
    time: '10:00',
    status: 'completed',
    location: '8520 Sycamore Street, Cupertino, CA 95014',
    notes: 'Marble tile with electric radiant heat system',
    value: '$7,200'
  },
  {
    id: '18',
    type: 'consultation',
    title: 'Historic Home Flooring Assessment',
    client: 'Thomas Wilson',
    date: '2025-12-12',
    time: '11:00',
    status: 'completed',
    location: '1890 Victorian Avenue, Alameda, CA 94501',
    notes: 'Original hardwood restoration throughout 1920s home',
    value: '$12,000'
  },

  // Cancelled
  {
    id: '19',
    type: 'estimate',
    title: 'Patio Outdoor Tile Estimate',
    client: 'Nancy Moore',
    date: '2025-12-16',
    time: '15:00',
    status: 'cancelled',
    location: '4567 Palm Court, Hayward, CA 94541',
    notes: 'Client postponed due to budget constraints',
    value: '$6,000'
  },

  // Future appointments
  {
    id: '20',
    type: 'job',
    title: 'Entire First Floor LVP Installation',
    client: 'Mark & Susan Jackson',
    date: '2025-12-30',
    time: '08:00',
    status: 'scheduled',
    location: '9876 Hickory Drive, Pleasanton, CA 94566',
    notes: 'Wood-look luxury vinyl plank, 1,200 sq ft',
    value: '$8,400'
  },
  {
    id: '21',
    type: 'estimate',
    title: 'Bedroom Suite Carpet Estimate',
    client: 'Angela Robinson',
    date: '2025-12-31',
    time: '10:00',
    status: 'scheduled',
    location: '6543 Chestnut Avenue, Walnut Creek, CA 94596',
    notes: 'Three bedrooms plus hallway, plush carpet',
    value: '$5,500'
  },
  {
    id: '22',
    type: 'consultation',
    title: 'Commercial Office Renovation',
    client: 'Global Tech Solutions',
    date: '2026-01-02',
    time: '09:00',
    status: 'scheduled',
    location: '3000 Sand Hill Road, Menlo Park, CA 94025',
    notes: '5,000 sq ft office space, eco-friendly materials preferred',
    value: '$35,000'
  },
  {
    id: '23',
    type: 'job',
    title: 'Dining Room Bamboo Flooring',
    client: 'Steven Martinez',
    date: '2026-01-03',
    time: '11:00',
    status: 'scheduled',
    location: '2345 Poplar Street, Los Gatos, CA 95030',
    notes: 'Sustainable bamboo flooring, 350 sq ft',
    value: '$3,800'
  },
  {
    id: '24',
    type: 'estimate',
    title: 'Retail Store Flooring Estimate',
    client: 'Boutique Fashion Co.',
    date: '2026-01-05',
    time: '14:00',
    status: 'scheduled',
    location: '1200 Union Street, San Francisco, CA 94109',
    notes: 'High-traffic commercial flooring, modern aesthetic',
    value: '$11,500'
  },
  {
    id: '25',
    type: 'job',
    title: 'Game Room Cork Flooring',
    client: 'Rachel Green',
    date: '2026-01-06',
    time: '09:30',
    status: 'scheduled',
    location: '7890 Ash Lane, Campbell, CA 95008',
    notes: 'Soundproof cork flooring, 500 sq ft basement',
    value: '$4,500'
  }
];
