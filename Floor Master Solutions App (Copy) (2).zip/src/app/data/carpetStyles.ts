export interface CarpetStyle {
  id: string;
  name: string;
  image: string;
  description: string;
  pileType: 'Cut Pile' | 'Loop Pile' | 'Cut and Loop' | 'Natural Fiber';
  durability: 1 | 2 | 3 | 4 | 5;
  comfort: 1 | 2 | 3 | 4 | 5;
  maintenance: 'Low' | 'Medium' | 'High';
  priceCategory: 'Budget' | 'Mid-Range' | 'Premium' | 'Luxury';
  bestFor: string[];
  characteristics: string[];
  traffic: 'Low' | 'Medium' | 'High' | 'Commercial';
}

export const carpetStyles: CarpetStyle[] = [
  {
    id: 'plush',
    name: 'Plush/Velvet',
    image: 'https://images.unsplash.com/photo-1671624760774-b2777e7742d2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwbHVzaCUyMGNhcnBldCUyMHRleHR1cmV8ZW58MXx8fHwxNzY2MDE0MjQyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Smooth, even surface with a luxurious, formal appearance. Shows footprints and vacuum marks.',
    pileType: 'Cut Pile',
    durability: 2,
    comfort: 5,
    maintenance: 'High',
    priceCategory: 'Mid-Range',
    bestFor: ['Formal living rooms', 'Master bedrooms', 'Low-traffic areas', 'Elegant spaces'],
    characteristics: [
      'Soft and luxurious feel',
      'Formal appearance',
      'Shows footprints and marks',
      'Dense, even pile',
      'Best for low traffic'
    ],
    traffic: 'Low'
  },
  {
    id: 'textured',
    name: 'Textured/Saxony',
    image: 'https://images.unsplash.com/photo-1671624760774-b2777e7742d2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwbHVzaCUyMGNhcnBldCUyMHRleHR1cmV8ZW58MXx8fHwxNzY2MDE0MjQyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Twisted fibers create a textured appearance that hides footprints. Very popular for homes.',
    pileType: 'Cut Pile',
    durability: 4,
    comfort: 4,
    maintenance: 'Low',
    priceCategory: 'Mid-Range',
    bestFor: ['Living rooms', 'Bedrooms', 'Family rooms', 'Most residential spaces'],
    characteristics: [
      'Hides footprints well',
      'Durable and resilient',
      'Casual to formal look',
      'Easy maintenance',
      'Most popular residential style'
    ],
    traffic: 'Medium'
  },
  {
    id: 'frieze',
    name: 'Frieze/Shag',
    image: 'https://images.unsplash.com/photo-1687398209712-de4252610814?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmllemUlMjBjYXJwZXQlMjBzaGFnfGVufDF8fHx8MTc2NjAxNDI0Mnww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Long, twisted fibers create a casual, informal look. Excellent at hiding dirt and footprints.',
    pileType: 'Cut Pile',
    durability: 4,
    comfort: 5,
    maintenance: 'Low',
    priceCategory: 'Mid-Range',
    bestFor: ['Family rooms', 'Casual living areas', 'Bedrooms', 'High-traffic areas'],
    characteristics: [
      'Highly twisted fibers',
      'Casual, relaxed look',
      'Hides dirt and wear',
      'Very durable',
      'Easy to maintain'
    ],
    traffic: 'High'
  },
  {
    id: 'berber-loop',
    name: 'Berber/Level Loop',
    image: 'https://images.unsplash.com/photo-1677053199368-6d6360d3cc9d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZXJiZXIlMjBjYXJwZXQlMjBsb29wfGVufDF8fHx8MTc2NjAxNDI0Mnww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Uncut loops of even height. Extremely durable and great for high-traffic areas.',
    pileType: 'Loop Pile',
    durability: 5,
    comfort: 3,
    maintenance: 'Low',
    priceCategory: 'Budget',
    bestFor: ['High-traffic areas', 'Hallways', 'Basements', 'Commercial spaces'],
    characteristics: [
      'Extremely durable',
      'Hides dirt well',
      'Low maintenance',
      'Casual appearance',
      'Good for heavy traffic'
    ],
    traffic: 'Commercial'
  },
  {
    id: 'patterned-loop',
    name: 'Patterned Loop',
    image: 'https://images.unsplash.com/photo-1700606376099-554ae7685391?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXR0ZXJuJTIwY2FycGV0JTIwZGVzaWdufGVufDF8fHx8MTc2NjAxNDI0M3ww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Multi-level loops create patterns and textures. Adds visual interest while being durable.',
    pileType: 'Loop Pile',
    durability: 4,
    comfort: 3,
    maintenance: 'Low',
    priceCategory: 'Mid-Range',
    bestFor: ['Family rooms', 'Offices', 'Casual spaces', 'Areas needing texture'],
    characteristics: [
      'Creates visual patterns',
      'Very durable',
      'Hides wear and soil',
      'Interesting texture',
      'Good for high traffic'
    ],
    traffic: 'High'
  },
  {
    id: 'cut-and-loop',
    name: 'Cut and Loop',
    image: 'https://images.unsplash.com/photo-1700606376099-554ae7685391?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXR0ZXJuJTIwY2FycGV0JTIwZGVzaWdufGVufDF8fHx8MTc2NjAxNDI0M3ww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Combination of cut and looped fibers creates sculptured patterns and designs.',
    pileType: 'Cut and Loop',
    durability: 4,
    comfort: 4,
    maintenance: 'Medium',
    priceCategory: 'Mid-Range',
    bestFor: ['Living rooms', 'Bedrooms', 'Dining rooms', 'Decorative spaces'],
    characteristics: [
      'Creates sculptured patterns',
      'Interesting visual appeal',
      'Good durability',
      'Comfortable feel',
      'Versatile style'
    ],
    traffic: 'Medium'
  },
  {
    id: 'sisal',
    name: 'Sisal/Natural Fiber',
    image: 'https://images.unsplash.com/photo-1712569130048-17ffc3fe587d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaXNhbCUyMG5hdHVyYWwlMjBjYXJwZXR8ZW58MXx8fHwxNzY2MDE0MjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Made from natural plant fibers. Eco-friendly with an organic, textured look.',
    pileType: 'Natural Fiber',
    durability: 3,
    comfort: 2,
    maintenance: 'High',
    priceCategory: 'Premium',
    bestFor: ['Eco-conscious homes', 'Coastal style', 'Modern organic', 'Low-traffic areas'],
    characteristics: [
      'Eco-friendly natural fibers',
      'Unique organic texture',
      'Not stain resistant',
      'Contemporary look',
      'Sustainable choice'
    ],
    traffic: 'Low'
  },
  {
    id: 'carpet-tiles',
    name: 'Carpet Tiles',
    image: 'https://images.unsplash.com/photo-1693267438856-c090133a8878?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJwZXQlMjB0aWxlcyUyMGNvbW1lcmNpYWx8ZW58MXx8fHwxNzY2MDE0MjQzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Modular carpet squares. Easy to install, replace, and create custom patterns.',
    pileType: 'Cut Pile',
    durability: 4,
    comfort: 3,
    maintenance: 'Low',
    priceCategory: 'Mid-Range',
    bestFor: ['Offices', 'Basements', 'DIY projects', 'Commercial spaces'],
    characteristics: [
      'Easy DIY installation',
      'Individual tiles replaceable',
      'Create custom patterns',
      'Versatile and practical',
      'Commercial grade available'
    ],
    traffic: 'Commercial'
  }
];

// Fiber types available
export const fiberTypes = [
  {
    id: 'nylon',
    name: 'Nylon',
    description: 'Most popular and durable fiber',
    durability: 5,
    stainResistance: 4,
    softness: 4,
    priceRange: 'Mid-Range to Premium',
    characteristics: [
      'Most durable fiber',
      'Excellent resilience',
      'Good stain resistance',
      'Wide color range',
      'Best overall performance'
    ]
  },
  {
    id: 'polyester',
    name: 'Polyester (PET)',
    description: 'Soft and stain-resistant',
    durability: 3,
    stainResistance: 5,
    softness: 5,
    priceRange: 'Budget to Mid-Range',
    characteristics: [
      'Very soft feel',
      'Excellent stain resistance',
      'Good color retention',
      'Often made from recycled materials',
      'Less resilient than nylon'
    ]
  },
  {
    id: 'triexta',
    name: 'Triexta (SmartStrand)',
    description: 'Soft and very stain-resistant',
    durability: 4,
    stainResistance: 5,
    softness: 5,
    priceRange: 'Mid-Range to Premium',
    characteristics: [
      'Built-in stain resistance',
      'Very soft',
      'Good durability',
      'Partially plant-based',
      'Easy to clean'
    ]
  },
  {
    id: 'olefin',
    name: 'Olefin/Polypropylene',
    description: 'Budget-friendly and moisture-resistant',
    durability: 3,
    stainResistance: 4,
    softness: 2,
    priceRange: 'Budget',
    characteristics: [
      'Moisture resistant',
      'Good for basements',
      'Budget-friendly',
      'Resists mold and mildew',
      'Less soft than other fibers'
    ]
  },
  {
    id: 'wool',
    name: 'Wool',
    description: 'Natural, luxurious, and eco-friendly',
    durability: 4,
    stainResistance: 2,
    softness: 5,
    priceRange: 'Luxury',
    characteristics: [
      'Natural and renewable',
      'Luxurious feel',
      'Naturally flame resistant',
      'Requires professional cleaning',
      'Premium investment'
    ]
  }
];

export function getStylesByTraffic(traffic: string): CarpetStyle[] {
  return carpetStyles.filter(style => style.traffic === traffic);
}

export function getStylesByPileType(pileType: string): CarpetStyle[] {
  return carpetStyles.filter(style => style.pileType === pileType);
}
