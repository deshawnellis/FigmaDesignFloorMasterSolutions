export interface HardwoodProduct {
  id: string;
  name: string;
  type: 'unfinished' | 'prefinished' | 'engineered' | 'lvp';
  species: string;
  color: string;
  size: string; // plank width
  thickness: string;
  length: string;
  installMethod: string; // how it's laid
  image: string;
  pricePerSqFt: number;
  description: string;
  finish?: string;
  features: string[];
}

export const hardwoodProducts: HardwoodProduct[] = [
  // Unfinished Hardwood
  {
    id: 'uf-oak-natural-3',
    name: 'Red Oak Natural 3-inch',
    type: 'unfinished',
    species: 'Red Oak',
    color: 'Natural',
    size: '3 inch',
    thickness: '3/4 inch',
    length: 'Random (1-7 ft)',
    installMethod: 'Nail Down',
    image: 'https://images.unsplash.com/photo-1711915442858-2a5bb7ba67d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvYWslMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE1OXww&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 8.99,
    description: 'Classic red oak with natural grain pattern. Sand and finish on-site for custom color.',
    features: ['Solid 3/4" thickness', 'Can be refinished 5-7 times', 'Traditional nail down install', 'Custom stain options']
  },
  {
    id: 'uf-oak-natural-5',
    name: 'White Oak Natural 5-inch',
    type: 'unfinished',
    species: 'White Oak',
    color: 'Natural',
    size: '5 inch',
    thickness: '3/4 inch',
    length: 'Random (2-8 ft)',
    installMethod: 'Nail Down',
    image: 'https://images.unsplash.com/photo-1711915442858-2a5bb7ba67d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvYWslMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE1OXww&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 11.49,
    description: 'Premium white oak with tighter grain. Perfect for modern or traditional styles.',
    features: ['Wide 5" planks', 'Less grain variation than red oak', 'Harder and more durable', 'Takes stain beautifully']
  },
  {
    id: 'uf-maple-natural-4',
    name: 'Hard Maple Natural 4-inch',
    type: 'unfinished',
    species: 'Maple',
    color: 'Light',
    size: '4 inch',
    thickness: '3/4 inch',
    length: 'Random (1-6 ft)',
    installMethod: 'Nail Down',
    image: 'https://images.unsplash.com/photo-1677912997249-ad4bfbc3f1e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXBsZSUyMGhhcmR3b29kJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDEzMTU5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 10.99,
    description: 'Light-colored maple with subtle grain. Extremely hard and durable.',
    features: ['Very hard surface', 'Light natural color', 'Smooth, fine grain', 'Resistant to wear']
  },

  // Prefinished Hardwood
  {
    id: 'pf-oak-honey-5',
    name: 'Red Oak Honey 5-inch Prefinished',
    type: 'prefinished',
    species: 'Red Oak',
    color: 'Honey',
    size: '5 inch',
    thickness: '3/4 inch',
    length: 'Random (1-7 ft)',
    installMethod: 'Nail Down',
    image: 'https://images.unsplash.com/photo-1711915442858-2a5bb7ba67d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvYWslMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE1OXww&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 12.99,
    finish: 'Satin Polyurethane',
    description: 'Warm honey-toned oak with durable factory finish. Ready to use immediately.',
    features: ['Factory UV-cured finish', 'No sanding/finishing required', 'Walk on immediately', 'Consistent color']
  },
  {
    id: 'pf-oak-espresso-5',
    name: 'White Oak Espresso 5-inch Prefinished',
    type: 'prefinished',
    species: 'White Oak',
    color: 'Dark Brown',
    size: '5 inch',
    thickness: '3/4 inch',
    length: 'Random (2-8 ft)',
    installMethod: 'Nail Down',
    image: 'https://images.unsplash.com/photo-1642935264339-694e0fb27b0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YWxudXQlMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 14.99,
    finish: 'Matte Aluminum Oxide',
    description: 'Rich espresso stain with scratch-resistant finish. Modern and sophisticated.',
    features: ['Extra durable finish', 'Wire-brushed texture', 'Contemporary dark color', 'Low sheen matte']
  },
  {
    id: 'pf-hickory-natural-6',
    name: 'Hickory Natural 6-inch Prefinished',
    type: 'prefinished',
    species: 'Hickory',
    color: 'Natural Multi-tone',
    size: '6 inch',
    thickness: '3/4 inch',
    length: 'Random (2-8 ft)',
    installMethod: 'Nail Down',
    image: 'https://images.unsplash.com/photo-1617262869522-6740e6450f27?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWNrb3J5JTIwaGFyZHdvb2QlMjBmbG9vcnxlbnwxfHx8fDE3NjYwMTMxNjB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 13.99,
    finish: 'Satin Urethane',
    description: 'Dramatic color variation from light sapwood to dark heartwood. Very hard.',
    features: ['Hardest domestic wood', 'Wide 6" planks', 'Natural color variation', 'Rustic character']
  },
  {
    id: 'pf-walnut-natural-5',
    name: 'American Walnut 5-inch Prefinished',
    type: 'prefinished',
    species: 'Walnut',
    color: 'Rich Brown',
    size: '5 inch',
    thickness: '3/4 inch',
    length: 'Random (2-7 ft)',
    installMethod: 'Nail Down',
    image: 'https://images.unsplash.com/photo-1642935264339-694e0fb27b0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YWxudXQlMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 16.99,
    finish: 'Natural Oil',
    description: 'Luxurious dark walnut with natural oil finish. Premium choice for upscale homes.',
    features: ['Natural oil finish', 'Rich chocolate tones', 'Premium species', 'Hand-scraped option']
  },

  // Engineered Hardwood
  {
    id: 'eng-oak-grey-7',
    name: 'Engineered Oak Grey 7-inch',
    type: 'engineered',
    species: 'White Oak',
    color: 'Grey',
    size: '7 inch',
    thickness: '1/2 inch',
    length: '48 inch',
    installMethod: 'Click-Lock Floating',
    image: 'https://images.unsplash.com/photo-1608702529091-f3b4fab4b97e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2glMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 7.99,
    finish: 'Matte Lacquer',
    description: 'Modern grey-toned engineered oak with easy click-lock installation.',
    features: ['Click-lock floating install', 'Wire-brushed texture', 'Can install over concrete', 'Wide 7" planks']
  },
  {
    id: 'eng-maple-natural-5',
    name: 'Engineered Maple Natural 5-inch',
    type: 'engineered',
    species: 'Maple',
    color: 'Natural',
    size: '5 inch',
    thickness: '3/8 inch',
    length: '48 inch',
    installMethod: 'Glue Down',
    image: 'https://images.unsplash.com/photo-1677912997249-ad4bfbc3f1e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXBsZSUyMGhhcmR3b29kJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDEzMTU5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 6.99,
    finish: 'Satin UV Cure',
    description: 'Light engineered maple perfect for glue-down installation over radiant heat.',
    features: ['Thin 3/8" profile', 'Compatible with radiant heat', 'Glue down method', 'Stable construction']
  },
  {
    id: 'eng-oak-charcoal-9',
    name: 'Engineered Oak Charcoal 9-inch',
    type: 'engineered',
    species: 'White Oak',
    color: 'Charcoal',
    size: '9 inch',
    thickness: '5/8 inch',
    length: '72 inch',
    installMethod: 'Click-Lock Floating',
    image: 'https://images.unsplash.com/photo-1642935264339-694e0fb27b0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YWxudXQlMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 9.99,
    finish: 'Hand-Scraped Matte',
    description: 'Extra-wide charcoal oak planks with hand-scraped texture for dramatic appeal.',
    features: ['Extra-wide 9" planks', 'Long 72" boards', 'Hand-scraped texture', 'Contemporary dark finish']
  },
  {
    id: 'eng-hickory-golden-6',
    name: 'Engineered Hickory Golden 6-inch',
    type: 'engineered',
    species: 'Hickory',
    color: 'Golden',
    size: '6 inch',
    thickness: '1/2 inch',
    length: '48 inch',
    installMethod: 'Nail Down or Glue',
    image: 'https://images.unsplash.com/photo-1617262869522-6740e6450f27?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWNrb3J5JTIwaGFyZHdvb2QlMjBmbG9vcnxlbnwxfHx8fDE3NjYwMTMxNjB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 8.49,
    finish: 'Satin Polyurethane',
    description: 'Engineered hickory with warm golden tones and natural character marks.',
    features: ['Dual install options', 'Natural color variation', 'Very durable hickory', 'Rustic character']
  },
  {
    id: 'eng-cherry-amber-5',
    name: 'Engineered Cherry Amber 5-inch',
    type: 'engineered',
    species: 'Cherry',
    color: 'Amber',
    size: '5 inch',
    thickness: '1/2 inch',
    length: '48 inch',
    installMethod: 'Click-Lock Floating',
    image: 'https://images.unsplash.com/photo-1607683647175-62bfc63a8cbe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVycnklMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 10.99,
    finish: 'Smooth Satin',
    description: 'Elegant cherry with rich amber tones. Smooth finish for formal spaces.',
    features: ['Smooth finish', 'Rich amber color', 'Easy floating install', 'Premium cherry veneer']
  },

  // LVP (Luxury Vinyl Plank)
  {
    id: 'lvp-oak-blonde-7',
    name: 'Waterproof Oak Blonde LVP 7-inch',
    type: 'lvp',
    species: 'Oak Look',
    color: 'Blonde',
    size: '7 inch',
    thickness: '5mm',
    length: '48 inch',
    installMethod: 'Click-Lock Floating',
    image: 'https://images.unsplash.com/photo-1678799021566-2e2a748e9dd6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB2aW55bCUyMHBsYW5rfGVufDF8fHx8MTc2NTk5MTU4N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 4.99,
    description: 'Light blonde oak look with 100% waterproof core. Perfect for any room.',
    features: ['100% waterproof', 'Easy DIY installation', 'Attached underlayment', 'Pet-friendly']
  },
  {
    id: 'lvp-walnut-espresso-9',
    name: 'Waterproof Walnut Espresso LVP 9-inch',
    type: 'lvp',
    species: 'Walnut Look',
    color: 'Dark Brown',
    size: '9 inch',
    thickness: '6mm',
    length: '48 inch',
    installMethod: 'Click-Lock Floating',
    image: 'https://images.unsplash.com/photo-1642935264339-694e0fb27b0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YWxudXQlMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 5.99,
    description: 'Extra-wide dark espresso LVP with realistic embossed texture.',
    features: ['Extra-wide 9" planks', 'Embossed in register texture', 'Scratch resistant wear layer', 'Quiet underfoot']
  },
  {
    id: 'lvp-oak-grey-7',
    name: 'Waterproof Oak Grey LVP 7-inch',
    type: 'lvp',
    species: 'Oak Look',
    color: 'Grey',
    size: '7 inch',
    thickness: '5mm',
    length: '48 inch',
    installMethod: 'Click-Lock Floating',
    image: 'https://images.unsplash.com/photo-1608702529091-f3b4fab4b97e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2glMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 4.49,
    description: 'Modern grey oak-look LVP with wire-brushed visual. Great for contemporary spaces.',
    features: ['Modern grey tone', 'Wire-brushed visual', 'Easy maintenance', 'Basement-friendly']
  },
  {
    id: 'lvp-hickory-natural-6',
    name: 'Waterproof Hickory Natural LVP 6-inch',
    type: 'lvp',
    species: 'Hickory Look',
    color: 'Natural Multi-tone',
    size: '6 inch',
    thickness: '6.5mm',
    length: '48 inch',
    installMethod: 'Click-Lock Floating',
    image: 'https://images.unsplash.com/photo-1617262869522-6740e6450f27?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWNrb3J5JTIwaGFyZHdvb2QlMjBmbG9vcnxlbnwxfHx8fDE3NjYwMTMxNjB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 5.49,
    description: 'Realistic hickory with natural color variation. Heavy-duty wear layer.',
    features: ['20 mil wear layer', 'Realistic color variation', 'High traffic rated', 'Lifetime residential warranty']
  },
  {
    id: 'lvp-maple-natural-5',
    name: 'Waterproof Maple Natural LVP 5-inch',
    type: 'lvp',
    species: 'Maple Look',
    color: 'Light',
    size: '5 inch',
    thickness: '4mm',
    length: '36 inch',
    installMethod: 'Peel and Stick',
    image: 'https://images.unsplash.com/photo-1677912997249-ad4bfbc3f1e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXBsZSUyMGhhcmR3b29kJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDEzMTU5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 3.99,
    description: 'Light maple-look with easy peel-and-stick installation. Budget-friendly.',
    features: ['Peel and stick install', 'No tools required', 'Budget-friendly', 'DIY friendly']
  },
  {
    id: 'lvp-oak-honey-8',
    name: 'Waterproof Oak Honey LVP 8-inch',
    type: 'lvp',
    species: 'Oak Look',
    color: 'Honey',
    size: '8 inch',
    thickness: '7mm',
    length: '72 inch',
    installMethod: 'Click-Lock Floating',
    image: 'https://images.unsplash.com/photo-1711915442858-2a5bb7ba67d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvYWslMjBoYXJkd29vZCUyMGZsb29yfGVufDF8fHx8MTc2NjAxMzE1OXww&ixlib=rb-4.1.0&q=80&w=1080',
    pricePerSqFt: 6.49,
    description: 'Premium extra-long honey oak planks with rigid core construction.',
    features: ['Extra-long 72" planks', 'Rigid SPC core', 'Commercial rated', 'Warm honey tones']
  }
];

// Helper function to get products by type
export function getProductsByType(type: string): HardwoodProduct[] {
  return hardwoodProducts.filter(product => product.type === type);
}

// Get unique filter values
export function getUniqueColors(type: string): string[] {
  const products = getProductsByType(type);
  return Array.from(new Set(products.map(p => p.color)));
}

export function getUniqueSizes(type: string): string[] {
  const products = getProductsByType(type);
  return Array.from(new Set(products.map(p => p.size)));
}

export function getUniqueInstallMethods(type: string): string[] {
  const products = getProductsByType(type);
  return Array.from(new Set(products.map(p => p.installMethod)));
}

export function getUniqueSpecies(type: string): string[] {
  const products = getProductsByType(type);
  return Array.from(new Set(products.map(p => p.species)));
}
