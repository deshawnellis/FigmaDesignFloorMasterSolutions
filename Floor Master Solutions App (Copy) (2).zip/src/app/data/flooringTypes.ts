export interface FlooringType {
  id: string;
  name: string;
  image: string;
  description: string;
  priceRange: string;
  durability: number; // 1-5
  maintenance: 'Low' | 'Medium' | 'High';
  pros: string[];
  cons: string[];
  bestFor: string[];
  lifespan: string;
}

export const flooringTypes: FlooringType[] = [
  {
    id: 'hardwood',
    name: 'Hardwood Flooring',
    image: 'https://images.unsplash.com/photo-1631669394390-baf737ef47de?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBoYXJkd29vZCUyMGZsb29yaW5nfGVufDF8fHx8MTc2NTk5MTM1OXww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Classic, timeless flooring made from solid wood planks. Adds warmth and value to any home.',
    priceRange: '$8-$15 per sq ft',
    durability: 4,
    maintenance: 'Medium',
    pros: [
      'Timeless aesthetic appeal',
      'Can be refinished multiple times',
      'Increases home value',
      'Long lifespan with proper care',
      'Natural and eco-friendly'
    ],
    cons: [
      'Higher upfront cost',
      'Susceptible to water damage',
      'Can scratch and dent',
      'Requires regular maintenance',
      'Not ideal for high-moisture areas'
    ],
    bestFor: ['Living rooms', 'Bedrooms', 'Dining rooms', 'Hallways'],
    lifespan: '30-100+ years'
  },
  {
    id: 'lvp',
    name: 'Luxury Vinyl Plank (LVP)',
    image: 'https://images.unsplash.com/photo-1604410880766-737427d11b70?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW55bCUyMHBsYW5rJTIwZmxvb3Jpbmd8ZW58MXx8fHwxNzY1OTkxMzU5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Waterproof synthetic flooring that mimics the look of wood or stone at a fraction of the cost.',
    priceRange: '$3-$8 per sq ft',
    durability: 4,
    maintenance: 'Low',
    pros: [
      'Waterproof and moisture resistant',
      'Very affordable',
      'Easy to install (click-lock system)',
      'Realistic wood or stone appearance',
      'Low maintenance',
      'Durable and scratch resistant'
    ],
    cons: [
      'Cannot be refinished',
      'Can fade in direct sunlight',
      'Less "authentic" feel than real wood',
      'May dent under heavy furniture',
      'Can emit VOCs initially'
    ],
    bestFor: ['Kitchens', 'Bathrooms', 'Basements', 'Laundry rooms'],
    lifespan: '10-25 years'
  },
  {
    id: 'tile',
    name: 'Tile Flooring',
    image: 'https://images.unsplash.com/photo-1719782758766-f0a4a3808afe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB0aWxlJTIwZmxvb3Jpbmd8ZW58MXx8fHwxNzY1OTczNjExfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Ceramic or porcelain tiles that offer exceptional durability and water resistance.',
    priceRange: '$5-$20 per sq ft',
    durability: 5,
    maintenance: 'Low',
    pros: [
      'Extremely durable',
      'Completely waterproof',
      'Easy to clean',
      'Wide variety of styles and colors',
      'Excellent for high-traffic areas',
      'Long lifespan'
    ],
    cons: [
      'Cold and hard underfoot',
      'Can be slippery when wet',
      'Grout requires maintenance',
      'Difficult to install',
      'Can crack under impact'
    ],
    bestFor: ['Bathrooms', 'Kitchens', 'Entryways', 'Laundry rooms'],
    lifespan: '50-100+ years'
  },
  {
    id: 'carpet',
    name: 'Carpet',
    image: 'https://images.unsplash.com/photo-1759742268946-8a145d543ac4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJwZXQlMjBmbG9vcmluZyUyMGhvbWV8ZW58MXx8fHwxNzY1OTkxMzYwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Soft, comfortable flooring that provides warmth and noise reduction.',
    priceRange: '$2-$10 per sq ft',
    durability: 2,
    maintenance: 'High',
    pros: [
      'Soft and comfortable',
      'Excellent insulation',
      'Reduces noise',
      'Affordable',
      'Wide variety of colors and textures',
      'Easy to install'
    ],
    cons: [
      'Stains easily',
      'Requires regular vacuuming',
      'Can trap allergens and dust',
      'Not water resistant',
      'Shorter lifespan',
      'Can show wear patterns'
    ],
    bestFor: ['Bedrooms', 'Living rooms', 'Stairs', 'Home offices'],
    lifespan: '5-15 years'
  },
  {
    id: 'laminate',
    name: 'Laminate Flooring',
    image: 'https://images.unsplash.com/photo-1681490443016-30ae75a1647b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYW1pbmF0ZSUyMHdvb2QlMjBmbG9vcmluZ3xlbnwxfHx8fDE3NjU5OTE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Budget-friendly flooring that mimics wood or stone with a photographic layer.',
    priceRange: '$2-$6 per sq ft',
    durability: 3,
    maintenance: 'Low',
    pros: [
      'Very affordable',
      'Easy to install',
      'Scratch resistant',
      'Low maintenance',
      'Realistic wood appearance',
      'Good for DIY projects'
    ],
    cons: [
      'Not waterproof',
      'Cannot be refinished',
      'Can sound hollow underfoot',
      'Susceptible to moisture damage',
      'Lower resale value',
      'Can chip at edges'
    ],
    bestFor: ['Living rooms', 'Bedrooms', 'Hallways', 'Home offices'],
    lifespan: '10-25 years'
  },
  {
    id: 'engineered',
    name: 'Engineered Wood',
    image: 'https://images.unsplash.com/photo-1693948568453-a3564f179a84?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbmdpbmVlcmVkJTIwd29vZCUyMGZsb29yaW5nfGVufDF8fHx8MTc2NTk5MTQzMXww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Multi-layer wood flooring with a real wood veneer top layer, more stable than solid hardwood.',
    priceRange: '$5-$12 per sq ft',
    durability: 4,
    maintenance: 'Medium',
    pros: [
      'Real wood appearance',
      'More stable than solid hardwood',
      'Can be installed over concrete',
      'Better moisture resistance than hardwood',
      'Can be refinished (limited)',
      'Good value for the price'
    ],
    cons: [
      'Limited refinishing options',
      'Lower quality can delaminate',
      'Not as long-lasting as solid hardwood',
      'Still susceptible to water damage',
      'Quality varies widely'
    ],
    bestFor: ['Kitchens', 'Basements', 'Living rooms', 'Dining rooms'],
    lifespan: '20-40 years'
  },
  {
    id: 'epoxy',
    name: 'Epoxy Flooring',
    image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlcG94eSUyMGZsb29yfGVufDF8fHx8MTczNjk5MTQzMXww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'High-performance coating system creating a seamless, glossy finish that\'s incredibly durable and customizable.',
    priceRange: '$3-$12 per sq ft',
    durability: 5,
    maintenance: 'Low',
    pros: [
      'Extremely durable and impact resistant',
      'Seamless, non-porous surface',
      'Chemical and stain resistant',
      'Easy to clean and maintain',
      'Highly customizable colors and finishes',
      'Moisture and water resistant',
      'Long-lasting with proper installation'
    ],
    cons: [
      'Complex installation process',
      'Requires professional installation',
      'Can be slippery when wet',
      'Long curing time (3-7 days)',
      'Strong odor during application',
      'Difficult to remove once installed',
      'Can yellow with UV exposure'
    ],
    bestFor: ['Garages', 'Basements', 'Workshops', 'Commercial spaces', 'Warehouses', 'Laundry rooms'],
    lifespan: '10-30+ years'
  }
];