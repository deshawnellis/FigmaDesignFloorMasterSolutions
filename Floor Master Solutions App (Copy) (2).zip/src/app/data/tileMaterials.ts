export interface TileMaterial {
  id: string;
  name: string;
  image: string;
  description: string;
  type: 'Ceramic' | 'Porcelain' | 'Natural Stone' | 'Glass' | 'Wood-Look';
  durability: 1 | 2 | 3 | 4 | 5;
  waterResistance: 1 | 2 | 3 | 4 | 5;
  maintenance: 'Low' | 'Medium' | 'High';
  priceCategory: 'Budget' | 'Mid-Range' | 'Premium' | 'Luxury';
  bestFor: string[];
  characteristics: string[];
  porosity: 'Non-Vitreous' | 'Semi-Vitreous' | 'Vitreous' | 'Impervious';
}

export const tileMaterials: TileMaterial[] = [
  {
    id: 'ceramic-standard',
    name: 'Standard Ceramic',
    image: 'https://images.unsplash.com/photo-1709962701974-5ac5ccb4718b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjZXJhbWljJTIwdGlsZSUyMGJhdGhyb29tfGVufDF8fHx8MTc2NjAxNDQxM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Classic ceramic tile, affordable and versatile. Ideal for walls and light-traffic floors.',
    type: 'Ceramic',
    durability: 3,
    waterResistance: 4,
    maintenance: 'Low',
    priceCategory: 'Budget',
    bestFor: ['Bathroom walls', 'Kitchen backsplash', 'Light-traffic areas', 'Budget projects'],
    characteristics: [
      'Affordable and accessible',
      'Wide variety of colors',
      'Easy to cut and install',
      'Good for walls',
      'Glazed surface options'
    ],
    porosity: 'Semi-Vitreous'
  },
  {
    id: 'porcelain-standard',
    name: 'Standard Porcelain',
    image: 'https://images.unsplash.com/photo-1642678751244-296d18c4cab3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3JjZWxhaW4lMjB0aWxlJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDE0NDEyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Dense, durable porcelain. Excellent for high-traffic areas and moisture-prone spaces.',
    type: 'Porcelain',
    durability: 5,
    waterResistance: 5,
    maintenance: 'Low',
    priceCategory: 'Mid-Range',
    bestFor: ['High-traffic floors', 'Kitchens', 'Bathrooms', 'Commercial spaces'],
    characteristics: [
      'Very dense and durable',
      'Extremely water resistant',
      'Through-body color',
      'Indoor and outdoor use',
      'Minimal maintenance'
    ],
    porosity: 'Impervious'
  },
  {
    id: 'porcelain-rectified',
    name: 'Rectified Porcelain',
    image: 'https://images.unsplash.com/photo-1642678751244-296d18c4cab3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3JjZWxhaW4lMjB0aWxlJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDE0NDEyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Precision-cut edges for minimal grout lines and a seamless contemporary look.',
    type: 'Porcelain',
    durability: 5,
    waterResistance: 5,
    maintenance: 'Low',
    priceCategory: 'Premium',
    bestFor: ['Modern interiors', 'Large format tiles', 'Seamless look', 'Contemporary homes'],
    characteristics: [
      'Precise, sharp edges',
      'Minimal grout lines possible',
      'Modern aesthetic',
      'Perfect for large tiles',
      'Premium finish'
    ],
    porosity: 'Impervious'
  },
  {
    id: 'wood-look-porcelain',
    name: 'Wood-Look Porcelain',
    image: 'https://images.unsplash.com/photo-1655475019270-418f6854b883?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b29kJTIwbG9vayUyMHRpbGV8ZW58MXx8fHwxNzY2MDE0NDE0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Porcelain tiles that mimic hardwood. Combines wood aesthetics with tile durability.',
    type: 'Wood-Look',
    durability: 5,
    waterResistance: 5,
    maintenance: 'Low',
    priceCategory: 'Premium',
    bestFor: ['Bathrooms', 'Basements', 'Kitchens', 'High-moisture areas'],
    characteristics: [
      'Looks like real wood',
      'Waterproof',
      'No warping or rot',
      'Durable surface',
      'Easy maintenance'
    ],
    porosity: 'Impervious'
  },
  {
    id: 'marble',
    name: 'Marble',
    image: 'https://images.unsplash.com/photo-1669643219984-2ff3eea887a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJibGUlMjB0aWxlJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDE0NDEzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Luxurious natural stone with elegant veining. Classic beauty and timeless appeal.',
    type: 'Natural Stone',
    durability: 3,
    waterResistance: 3,
    maintenance: 'High',
    priceCategory: 'Luxury',
    bestFor: ['Luxury bathrooms', 'Foyers', 'Accent walls', 'High-end homes'],
    characteristics: [
      'Natural beauty',
      'Unique veining',
      'Luxurious appearance',
      'Cool to touch',
      'Requires sealing'
    ],
    porosity: 'Vitreous'
  },
  {
    id: 'granite',
    name: 'Granite',
    image: 'https://images.unsplash.com/photo-1669643219984-2ff3eea887a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJibGUlMjB0aWxlJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDE0NDEzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Extremely hard natural stone. Highly durable with speckled appearance.',
    type: 'Natural Stone',
    durability: 5,
    waterResistance: 4,
    maintenance: 'Medium',
    priceCategory: 'Premium',
    bestFor: ['High-traffic areas', 'Commercial spaces', 'Outdoor areas', 'Durable flooring'],
    characteristics: [
      'Extremely hard',
      'Scratch resistant',
      'Unique patterns',
      'Natural stone beauty',
      'Long-lasting'
    ],
    porosity: 'Vitreous'
  },
  {
    id: 'travertine',
    name: 'Travertine',
    image: 'https://images.unsplash.com/photo-1669643219984-2ff3eea887a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJibGUlMjB0aWxlJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDE0NDEzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Porous limestone with natural pits and textures. Warm, rustic Mediterranean style.',
    type: 'Natural Stone',
    durability: 3,
    waterResistance: 2,
    maintenance: 'High',
    priceCategory: 'Premium',
    bestFor: ['Mediterranean style', 'Patios', 'Rustic interiors', 'Warm aesthetics'],
    characteristics: [
      'Natural texture',
      'Warm earth tones',
      'Porous surface',
      'Mediterranean look',
      'Requires sealing'
    ],
    porosity: 'Semi-Vitreous'
  },
  {
    id: 'slate',
    name: 'Slate',
    image: 'https://images.unsplash.com/photo-1642678751244-296d18c4cab3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3JjZWxhaW4lMjB0aWxlJTIwZmxvb3J8ZW58MXx8fHwxNzY2MDE0NDEyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Textured natural stone with natural cleft surface. Rustic and slip-resistant.',
    type: 'Natural Stone',
    durability: 4,
    waterResistance: 4,
    maintenance: 'Medium',
    priceCategory: 'Mid-Range',
    bestFor: ['Entryways', 'Outdoor spaces', 'Rustic homes', 'Slip resistance needed'],
    characteristics: [
      'Natural texture',
      'Slip resistant',
      'Varied colors',
      'Rustic appeal',
      'Indoor/outdoor'
    ],
    porosity: 'Vitreous'
  },
  {
    id: 'glass-tile',
    name: 'Glass Tile',
    image: 'https://images.unsplash.com/photo-1731045521151-07a0fe502009?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3NhaWMlMjB0aWxlJTIwZGVzaWdufGVufDF8fHx8MTc2NjAxNDQxM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Translucent glass tiles for backsplashes and accent areas. Reflective and modern.',
    type: 'Glass',
    durability: 3,
    waterResistance: 5,
    maintenance: 'Medium',
    priceCategory: 'Premium',
    bestFor: ['Kitchen backsplash', 'Bathroom accents', 'Modern designs', 'Decorative walls'],
    characteristics: [
      'Reflective surface',
      'Vibrant colors',
      'Modern aesthetic',
      'Easy to clean',
      'Not for floors'
    ],
    porosity: 'Impervious'
  },
  {
    id: 'mosaic-ceramic',
    name: 'Mosaic Ceramic',
    image: 'https://images.unsplash.com/photo-1731045521151-07a0fe502009?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3NhaWMlMjB0aWxlJTIwZGVzaWdufGVufDF8fHx8MTc2NjAxNDQxM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Small ceramic tiles on mesh sheets. Perfect for creating intricate patterns and designs.',
    type: 'Ceramic',
    durability: 3,
    waterResistance: 4,
    maintenance: 'Medium',
    priceCategory: 'Mid-Range',
    bestFor: ['Backsplashes', 'Accent walls', 'Shower floors', 'Decorative borders'],
    characteristics: [
      'Intricate patterns',
      'Easy to install on mesh',
      'Slip resistant (small tiles)',
      'Decorative appeal',
      'Versatile designs'
    ],
    porosity: 'Semi-Vitreous'
  }
];

export interface TileSize {
  id: string;
  dimensions: string;
  description: string;
  bestFor: string[];
  category: 'Small' | 'Medium' | 'Large' | 'Extra Large' | 'Plank';
}

export const tileSizes: TileSize[] = [
  { id: '1x1-mosaic', dimensions: '1" x 1" (Mosaic)', description: 'Tiny tiles, often on mesh sheets', bestFor: ['Shower floors', 'Accent patterns', 'Decorative borders'], category: 'Small' },
  { id: '2x2', dimensions: '2" x 2"', description: 'Small square tiles', bestFor: ['Mosaic patterns', 'Small bathrooms'], category: 'Small' },
  { id: '3x6-subway', dimensions: '3" x 6" (Subway)', description: 'Classic subway tile', bestFor: ['Backsplashes', 'Shower walls', 'Traditional style'], category: 'Small' },
  { id: '4x4', dimensions: '4" x 4"', description: 'Classic small square', bestFor: ['Bathrooms', 'Budget projects'], category: 'Small' },
  { id: '6x6', dimensions: '6" x 6"', description: 'Standard small tile', bestFor: ['Floors', 'Walls', 'Versatile use'], category: 'Small' },
  { id: '8x8', dimensions: '8" x 8"', description: 'Common floor tile', bestFor: ['Small rooms', 'Traditional floors'], category: 'Medium' },
  { id: '12x12', dimensions: '12" x 12"', description: 'Most popular size', bestFor: ['Most floors', 'Walls', 'General use'], category: 'Medium' },
  { id: '12x24', dimensions: '12" x 24"', description: 'Rectangular format', bestFor: ['Modern floors', 'Larger spaces', 'Contemporary'], category: 'Medium' },
  { id: '16x16', dimensions: '16" x 16"', description: 'Large square', bestFor: ['Open spaces', 'Fewer grout lines'], category: 'Large' },
  { id: '18x18', dimensions: '18" x 18"', description: 'Popular large format', bestFor: ['Large rooms', 'Modern look'], category: 'Large' },
  { id: '24x24', dimensions: '24" x 24"', description: 'Extra large square', bestFor: ['Grand spaces', 'Seamless look'], category: 'Extra Large' },
  { id: '24x48', dimensions: '24" x 48"', description: 'Large plank format', bestFor: ['Modern floors', 'Wood-look tiles'], category: 'Extra Large' },
  { id: '6x36-plank', dimensions: '6" x 36" (Plank)', description: 'Wood plank size', bestFor: ['Wood-look tiles', 'Planked look'], category: 'Plank' },
  { id: '6x48-plank', dimensions: '6" x 48" (Plank)', description: 'Long wood plank', bestFor: ['Wood-look tiles', 'Modern floors'], category: 'Plank' },
  { id: '8x48-plank', dimensions: '8" x 48" (Plank)', description: 'Wide wood plank', bestFor: ['Contemporary wood-look', 'Wide planks'], category: 'Plank' }
];

export function getMaterialsByType(type: string): TileMaterial[] {
  return tileMaterials.filter(material => material.type === type);
}

export function getSizesByCategory(category: string): TileSize[] {
  return tileSizes.filter(size => size.category === category);
}
