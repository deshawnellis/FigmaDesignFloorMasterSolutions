import { useState } from 'react';
import { Welcome } from './components/auth/Welcome';
import { UserTypeSelection } from './components/auth/UserTypeSelection';
import { LoginSignup } from './components/auth/LoginSignup';
import { HomeownerDashboard } from './components/homeowner/HomeownerDashboard';
import { ContractorDashboard } from './components/contractor/ContractorDashboard';

type AuthStep = 'welcome' | 'userType' | 'login' | 'authenticated';
type UserType = 'homeowner' | 'contractor' | null;

export default function App() {
  const [authStep, setAuthStep] = useState<AuthStep>('welcome');
  const [userType, setUserType] = useState<UserType>(null);

  const handleGetStarted = () => {
    setAuthStep('userType');
  };

  const handleSelectUserType = (type: 'homeowner' | 'contractor') => {
    setUserType(type);
    setAuthStep('login');
  };

  const handleAuthComplete = () => {
    setAuthStep('authenticated');
  };

  const handleBackToWelcome = () => {
    setAuthStep('welcome');
    setUserType(null);
  };

  const handleBackToUserType = () => {
    setAuthStep('userType');
  };

  const handleLogout = () => {
    setAuthStep('welcome');
    setUserType(null);
  };

  // Render based on authentication step
  if (authStep === 'welcome') {
    return <Welcome onGetStarted={handleGetStarted} />;
  }

  if (authStep === 'userType') {
    return <UserTypeSelection onSelectType={handleSelectUserType} onBack={handleBackToWelcome} />;
  }

  if (authStep === 'login' && userType) {
    return <LoginSignup userType={userType} onComplete={handleAuthComplete} onBack={handleBackToUserType} />;
  }

  if (authStep === 'authenticated') {
    if (userType === 'homeowner') {
      return <HomeownerDashboard onLogout={handleLogout} />;
    }
    
    if (userType === 'contractor') {
      return <ContractorDashboard onLogout={handleLogout} />;
    }
  }

  // Fallback
  return <Welcome onGetStarted={handleGetStarted} />;
}
